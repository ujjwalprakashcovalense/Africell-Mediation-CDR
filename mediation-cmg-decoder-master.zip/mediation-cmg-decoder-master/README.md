# mediation-cmg-decoder

CMG cdr binary file to ASCII conversions.