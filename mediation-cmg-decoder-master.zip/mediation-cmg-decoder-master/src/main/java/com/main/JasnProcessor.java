package com.main;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.UnknownHostException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cds.jasn1.africell.cdrf.gprs.ChangeOfCharCondition;
import com.cds.jasn1.africell.cdrf.gprs.ChangeOfServiceCondition;
import com.cds.jasn1.africell.cdrf.gprs.GPRSRecord;
import com.cds.jasn1.africell.cdrf.gprs.GSNAddress;
import com.cds.jasn1.africell.cdrf.gprs.PGWRecord;
import com.cds.jasn1.africell.cdrf.gprs.SGWRecord;
import com.util.OutputConverter;
import com.util.ZippingUtility;

public class JasnProcessor {
	private final static Logger logger = LoggerFactory.getLogger(Jasn1Africell.class.getName());
	private String servedIMSI;

	/**
	 * Method will decode the binary file to ascii.
	 * 
	 * @param properties
	 * @throws IOException
	 */
	public void converter(Properties properties) {

		File file_process = new File(properties.getProperty("processDir"));
		file_process.mkdir();

		File file_done = new File(properties.getProperty("doneDir"));
		file_done.mkdir();

		File file_output = new File(properties.getProperty("outputDir"));
		file_output.mkdir();
		List<File> files = null;
		if (Boolean.parseBoolean(properties.getProperty("unzipBeforeProcessing")) == true) {

			try {
				ZippingUtility.unZip(properties.getProperty("inputDir"), properties.getProperty("processDir"));

				Files.walk(Paths.get(properties.getProperty("inputDir"))).map(Path::toFile).forEach(File::delete);

				// filtering binary files
				files = Files.list(Paths.get(properties.getProperty("inputDir")))
						// .filter(path -> path.getFileName().toString().startsWith(inputFilePrefix))
						// .filter(path -> path.toString().endsWith(inputFileExtension))
						.limit(Integer.parseInt(properties.getProperty("cdr.batchsize"))).map(Path::toFile)
						.collect(Collectors.toList());
			} catch (Exception e) {
				logger.error("Could not process files from Input Folder" + e.getMessage());
			}

		} else {
			// files = new File(properties.getProperty("inputDir")).listFiles();

			// filtering binary files
			try {
				files = Files.list(Paths.get(properties.getProperty("inputDir")))
						// .filter(path -> path.getFileName().toString().startsWith(inputFilePrefix))
						// .filter(path -> path.toString().endsWith(inputFileExtension))
						.limit(Integer.parseInt(properties.getProperty("cdr.batchsize"))).map(Path::toFile)
						.collect(Collectors.toList());
			} catch (Exception e) {
				logger.error("Could not process files from Input Folder" + e.getMessage());
			}

			for (File file : files) {

				PrintWriter printWriter = null;
				PrintWriter containerPw = null;
				PrintWriter printWritersgw = null;
				PrintWriter containerPwsgw = null;

				try {
					logger.info("File has been proccessing : " + file.getName());
					byte[] bFile = readBytesFromFile(file.toString());

					ByteArrayInputStream is = new ByteArrayInputStream(bFile);
					GPRSRecord callerInfo_decode = new GPRSRecord();

					String outputDir = properties.getProperty("outputDir");
					String inputFileName = file.getName().toString();

					String outputFile = properties.getProperty("outputDir") + "/" + file.getName().toString();

					printWriter = new PrintWriter(outputFile + "_Main.csv"); // main csv
					containerPw = new PrintWriter(outputFile + "_container.csv"); // for container data csv

					StringBuilder outputFileSgw = new StringBuilder(inputFileName);
					int index = 2;
					char ch = 'S';
					outputFileSgw.setCharAt(index, ch);
					String outputFileSg = properties.getProperty("outputDir") + "/" + outputFileSgw;

					printWritersgw = new PrintWriter(outputFileSg + "_Main.csv");
					containerPwsgw = new PrintWriter(outputFileSg + "_container.csv");

//					if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == false) {
//						PrintStream o = new PrintStream(new File(
//								properties.getProperty("outputDir") + "/" + file.getName().toString() + ".csv"));
//						//System.setOut(o);
//					}

					if (Boolean.parseBoolean(properties.getProperty("needHeaderInOutput")) == true) {
						// logger.info("Header : " + getHeader() );
						printWriter.println(getHeader());
						containerPw.println(getContainerHeader());
						printWritersgw.println(getHeaderSgw());
						containerPwsgw.println(getContainerHeaderSgw());
						// logger.info("Header : " + Jasn1Africell.getHeader() );
					}
					// is.skip(40);
					is.skip(Long.parseLong(properties.getProperty("skipHeader")));

					while (is.available() != 0) {

						StringBuilder sb = new StringBuilder();

						callerInfo_decode.decode(is);
						if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == false) {
							if (callerInfo_decode.getPGWRecord() != null
									&& callerInfo_decode.getPGWRecord().getRecordType().longValue() == 85) {
								toFormat(sb, containerPw, callerInfo_decode.getPGWRecord(), outputDir, inputFileName);
								printWriter.println(sb.toString());

								if (!this.servedIMSI.startsWith("63105")) {

									PrintWriter writeInbound;
									Path path = null;
									// creating sub directories i.e, /offline/output/cmg_cdr/inbound/data
									path = Files.createDirectories(Paths.get(outputDir + "/" + "inbound/data"));

									String outFile = path + "/" + inputFileName + "_Main_inbound.csv";

									File f = new File(outFile);

									if (f.exists() && !f.isDirectory()) {
										writeInbound = new PrintWriter(new FileOutputStream(f, true));
										// write values only
										writeInbound.println(sb.toString());
									} else {
										// new file
										writeInbound = new PrintWriter(outFile);
										// write heading on first line
										writeInbound.println(getHeader());
										// write values
										writeInbound.println(sb.toString());
									}
									writeInbound.close(); // closing the output file writer

								} // End of inbound if

							}
						} // End of if
							// System.err.println(Integer.toHexString(is.read()));
							// is.skip(8);
						is.skip(Long.parseLong(properties.getProperty("skipDelimiter")));
						if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == true) {
							printWriter.println(callerInfo_decode);
						}
					} // end of while loop
					StringBuilder sbsgw = new StringBuilder();
					if (callerInfo_decode.getSGWRecord() != null
							&& callerInfo_decode.getSGWRecord().getRecordType().longValue() == 84) {
						toFormatsgw(sbsgw, containerPwsgw, callerInfo_decode.getSGWRecord(), outputDir, inputFileName);
						printWritersgw.println(sbsgw.toString());

						if (!this.servedIMSI.startsWith("63105")) {

							PrintWriter printWriter2;

							Path path4 = null;
							try {
								// creating sub directories i.e, /offline/output/cmg_cdr/inbound/data
								path4 = Files.createDirectories(Paths.get(outputDir + "/" + "inbound/data"));
								StringBuilder inputFileSgw = new StringBuilder(inputFileName);
								int indexInboundMain = 2;
								char ch1 = 'S';
								inputFileSgw.setCharAt(indexInboundMain, ch1);

								String outputFile4 = path4 + "/" + inputFileSgw + "_Main_INBOUND_DWH.csv";

								File file4 = new File(outputFile4);

								if (file4.exists() && !file4.isDirectory()) {
									printWriter2 = new PrintWriter(new FileOutputStream(file4, true));
									// write values only
									printWriter2.println(sbsgw.toString());
								} else {
									// new file
									printWriter2 = new PrintWriter(outputFile4);
									// write heading on first line
									printWriter2.println(getHeaderSgw());
									// write values
									printWriter2.println(sbsgw.toString());
								}
								printWriter2.close(); // closing the output file writer
							} catch (Exception e) {
								e.printStackTrace();
							}

						}

					}

					logger.info("ASN1 conversion completed successfully!");

					try {

						Files.move(Paths.get(file.toString()),
								Paths.get(properties.getProperty("doneDir") + "/" + file.getName() + ".Done"),
								StandardCopyOption.REPLACE_EXISTING);
						logger.info("Input file moved to archive path");

					} catch (FileAlreadyExistsException e) {
						logger.warn("Exception occured when moving files from input to done directory");

					}
				} catch (Exception ex) {
					logger.warn("Error occured while proccessing the file: " + file.getName() + ex.getMessage());
					// input file moving to failed path
					try {
						Files.move(Paths.get(file.toString()),
								Paths.get(properties.getProperty("doneDir") + "/" + file.getName() + ".Failed"),
								StandardCopyOption.REPLACE_EXISTING);
						logger.info("Input file moved to archive path");
					} catch (IOException e) {
						//
					}

				} finally {
					printWriter.close();
					containerPw.close();
					printWritersgw.close();
					containerPwsgw.close();
				}

			} // for loop end

			if (files.isEmpty()) {
				logger.info("Waiting for input file - " + properties.getProperty("cdr.wait.time") + " sec");
			}

		} // else end
	} // end of converter

	/**
	 * Method will set the header for main data file for PGW.
	 * 
	 * @return string
	 */
	private static String getHeader() {
		// // TODO Auto-generated method stub
		//
		StringBuilder sb = new StringBuilder();
		sb.append(
				"recordType,servedIMSI,pGWAddress,chargingID,servingNodeAddress,accessPointNameNI,pdpPDNType,servedPDPPDNAddress,dynamicAddressFlag,recordOpeningTime,duration,causeForRecClosing,diagnostics,recordSequenceNumber,nodeID,recordExtensions,localSequenceNumber,apnSelectionMode,servedMSISDN,chargingCharacteristics,chChSelectionMode,iMSsignalingContext,externalChargingID,servingNodePLMNIdentifier,pSFurnishChargingInformation,servedIMEISV,rATType,mSTimeZone,userLocationInformation,cAMELChargingInformation,"
						+ "servingNodeType,servedMNNAI,pGWPLMNIdentifier,startTime,stopTime,served3gpp2MEID,pDNConnectionChargingID,iMSIunauthenticatedFlag,userCSGInformation,threeGPP2UserLocationInformation,servedPDPPDNAddressExt,lowPriorityIndicator,dynamicAddressFlagExt,servingNodeiPv6Address,pGWiPv6AddressUsed,tWANUserLocationInformation,retransmission,userLocationInfoTime,cNOperatorSelectionEnt,ePCQoSInformation,presenceReportingAreaInfo,lastUserLocationInformation,lastMSTimeZone,enhancedDiagnostics,uWANUserLocationInformation,sGiPtPTunnellingMethod,uNIPDUCPOnlyFlag,pDPPDNTypeExtension,mOExceptionDataCounter,listOfRANSecondaryRATUsageReports");
		// System.out.println(sb);
		return sb.toString();
	}

	/**
	 * Method will set the header for main data file for SGW.
	 * 
	 * @return string
	 */
	private static String getHeaderSgw() {
		StringBuilder sb = new StringBuilder();
		sb.append(
				"recordType,servedIMSI,sGWAddress,chargingID,servingNodeAddress,accessPointNameNI,pdpPDNType,servedPDPPDNAddress,dynamicAddressFlag,recordOpeningTime,duration,causeForRecClosing,diagnostics,recordSequenceNumber,nodeID,recordExtensions,localSequenceNumber,apnSelectionMode,servedMSISDN,chargingCharacteristics,chChSelectionMode,iMSsignalingContext,servingNodePLMNIdentifier,servedIMEISV,rATType,mSTimeZone,userLocationInformation,sGWChange,servingNodeType,pGWAddressUsed,pGWPLMNIdentifier,startTime,stopTime,pDNConnectionChargingID,iMSIunauthenticatedFlag,userCSGInformation,servedPDPPDNAddressExt,lowPriorityIndicator,dynamicAddressFlagExt,sGWiPv6Address,servingNodeiPv6Address,pGWiPv6AddressUsed,retransmission,userLocationInfoTime,cNOperatorSelectionEnt,presenceReportingAreaInfo,lastUserLocationInformation,lastMSTimeZone,enhancedDiagnostics,cPCIoTEPSOptimisationIndicator,uNIPDUCPOnlyFlag,servingPLMNRateControl,pDPPDNTypeExtension,mOExceptionDataCounter,listOfRANSecondaryRATUsageReports");
		// System.out.println(sb);
		return sb.toString();
	}

	/**
	 * Method will set the header for container data file for PGW.
	 * 
	 * @return string
	 */
	private static String getContainerHeader() {

		String containerStr = "localSequenceNumber,ratingGroup,chargingRuleBaseName,resultCode,Container_localSequenceNumber,timeOfFirstUsage,timeOfLastUsage,timeUsage,serviceConditionChange,qoSInformationNeg_qci,qoSInformationNeg_arp,qoSInformationNeg_aggregateMaxBitrateUL,qoSInformationNeg_aggregateMaxBitrateDL,servingNodeAddress,datavolumeFBCUplink,datavolumeFBCDownlink,timeOfReport,failureHandlingContinue,serviceIdentifier,pSFurnishChargingInformation,aFRecordInformation,userLocationInformation,eventBasedChargingInformation,timeQuotaMechanism,serviceSpecificInfo,threeGPP2UserLocationInformation,sponsorIdentity,applicationServiceProviderIdentity,aDCRuleBaseName,presenceReportingAreaStatus,userCSGInformation,uWANUserLocationInformation,servingPLMNRateControl,aPNRateControl";
		return containerStr;
	}

	/**
	 * Method will set the header for container data file for SGW.
	 * 
	 * @return string
	 */

	private static String getContainerHeaderSgw() {
		String containerStrSgw = "localSequenceNumber,qosRequested,qosNegotiated,dataVolumeGPRSUplink,dataVolumeGPRSDownlink,changeCondition,changeTime,failureHandlingContinue,userLocationInformation,qCI,aRP,aPNAggregateMaxBitrateUL,aPNAggregateMaxBitrateDL,chargingID,presenceReportingAreaStatus,userCSGInformation,diagnostics,enhancedDiagnostics,rATType,accessAvailabilityChangeReason,uWANUserLocationInformation,relatedChangeOfCharCondition,cPCIoTEPSOptimisationIndicator,servingPLMNRateControl";
		return containerStrSgw;
	}

	private static byte[] readBytesFromFile(String filePath) {
		// TODO Auto-generated method stub
		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;

		try {

			File file = new File(filePath);
			bytesArray = new byte[(int) file.length()];

			// read file into bytes[]
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;
	}

	// To get ASCII Values
	public void toFormat(StringBuilder sb, PrintWriter containerPw, PGWRecord pGWRecord, String outputDir,
			String inputFileName) throws UnknownHostException, ClassNotFoundException {

		// recordType
		if (pGWRecord.getRecordType() != null) {
			sb.append(OutputConverter.convertRecordType(Integer.parseInt(pGWRecord.getRecordType().toString())))
					.append(",");
		} else {
			sb.append(",");
		}
		if (pGWRecord.getServedIMSI() != null) {

			String s = OutputConverter.convertServedIMSI(pGWRecord.getServedIMSI().toString());
			this.servedIMSI = s;

			sb.append(s).append(",");

		} else {
			sb.append(",");
		}

		if (pGWRecord.getPGWAddress() != null) {
			String s = OutputConverter
					.convertIp(pGWRecord.getPGWAddress().getIPBinaryAddress().getIPBinV4Address().toString());
			sb.append(s).append(",");
		} else {
			sb.append(",");
		}

		if (pGWRecord.getChargingID() != null) {
			sb.append(pGWRecord.getChargingID()).append(",");
		} else
			sb.append(",");
		// if (pGWRecord.getServingNodeAddress() != null) {
		// sb.append(pGWRecord.getServingNodeAddress()).append(",");
		// } else
		// sb.append(",");

		/////////// ArrayList ///////////////
		if (pGWRecord.getServingNodeAddress() != null) {
			if (pGWRecord.getServingNodeAddress().getGSNAddress() != null) {

				sb.append("{");
				List<GSNAddress> cosc = pGWRecord.getServingNodeAddress().getGSNAddress();

				for (GSNAddress list : cosc) {

					if (list.getIPBinaryAddress() != null) {

						sb.append(OutputConverter.convertIp(list.getIPBinaryAddress().getIPBinV4Address().toString()));
						// .append(",");
					} else
						sb.append(",");
				}
				sb.append("},");
			} else
				sb.append("{},");
		}
		///////////////////////////////////////////

		if (pGWRecord.getAccessPointNameNI() != null) {
			sb.append(pGWRecord.getAccessPointNameNI()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getPdpPDNType() != null) {
			sb.append(OutputConverter.convertPdpPdnType(pGWRecord.getPdpPDNType().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getServedPDPPDNAddress() != null) {
			sb.append(OutputConverter.convertIp(pGWRecord.getServedPDPPDNAddress().getIPAddress().getIPBinaryAddress()
					.getIPBinV4Address().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getDynamicAddressFlag() != null) {
			sb.append(pGWRecord.getDynamicAddressFlag()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getRecordOpeningTime() != null) {
			sb.append(OutputConverter.convertTime(pGWRecord.getRecordOpeningTime().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getDuration() != null) {
			sb.append(pGWRecord.getDuration()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getCauseForRecClosing() != null) {
			sb.append(pGWRecord.getCauseForRecClosing()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getDiagnostics() != null) {
			sb.append(pGWRecord.getDiagnostics().getManufacturerSpecificCause()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getRecordSequenceNumber() != null) {
			sb.append(pGWRecord.getRecordSequenceNumber()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getNodeID() != null) {
			sb.append(pGWRecord.getNodeID()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getRecordExtensions() != null) {
			sb.append(pGWRecord.getRecordExtensions().getManagementExtension()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getLocalSequenceNumber() != null) {
			sb.append(pGWRecord.getLocalSequenceNumber()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getApnSelectionMode() != null) {
			sb.append(pGWRecord.getApnSelectionMode()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getServedMSISDN() != null) {
			sb.append(OutputConverter.convertServedMSISDN(pGWRecord.getServedMSISDN().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getChargingCharacteristics() != null) {
			sb.append(pGWRecord.getChargingCharacteristics()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getChChSelectionMode() != null) {
			sb.append(pGWRecord.getChChSelectionMode()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getIMSsignalingContext() != null) {
			sb.append(pGWRecord.getIMSsignalingContext()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getExternalChargingID() != null) {
			sb.append(pGWRecord.getExternalChargingID()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getServingNodePLMNIdentifier() != null) {
			sb.append(OutputConverter.convertPLMN(pGWRecord.getServingNodePLMNIdentifier().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getPSFurnishChargingInformation() != null) {
			sb.append(pGWRecord.getPSFurnishChargingInformation()).append(",");
		} else
			sb.append(",");

		if (pGWRecord.getServedIMEISV() != null) {
			sb.append(pGWRecord.getServedIMEISV()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getRATType() != null) {
			sb.append(pGWRecord.getRATType()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getMSTimeZone() != null) {
			sb.append(pGWRecord.getMSTimeZone()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getUserLocationInformation() != null) {
			sb.append(pGWRecord.getUserLocationInformation()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getCAMELChargingInformation() != null) {
			sb.append(pGWRecord.getCAMELChargingInformation()).append(",");
		} else
			sb.append(",");

		/////////// ArrayList ///////////////
		if (pGWRecord.getListOfServiceData() != null
				&& pGWRecord.getListOfServiceData().getChangeOfServiceCondition() != null) {

			List<ChangeOfServiceCondition> cosc = pGWRecord.getListOfServiceData().getChangeOfServiceCondition();

			cosc.stream().forEach(a -> {

				if (pGWRecord.getLocalSequenceNumber() != null) {

					StringBuilder containerStr = new StringBuilder();
					// add LocalSequenceNumber
					containerStr.append(pGWRecord.getLocalSequenceNumber()).append(",");

					if (a.getRatingGroup() != null) {
						containerStr.append(a.getRatingGroup() + ",");
					} else
						containerStr.append(",");
					if (a.getChargingRuleBaseName() != null) {
						containerStr.append(a.getChargingRuleBaseName() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getResultCode() != null) {
						containerStr.append(a.getResultCode() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getLocalSequenceNumber() != null) {
						containerStr.append(a.getLocalSequenceNumber() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getTimeOfFirstUsage() != null) {
						containerStr.append(OutputConverter.convertTime(a.getTimeOfFirstUsage().toString()) + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getTimeOfLastUsage() != null) {
						containerStr.append(OutputConverter.convertTime(a.getTimeOfLastUsage().toString()) + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getTimeUsage() != null) {
						containerStr.append(a.getTimeUsage() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getServiceConditionChange() != null) {
						containerStr.append(a.getServiceConditionChange() + ",");
					} else {
						containerStr.append(",");
					}
					/////////////// QOS Information ////////////////
					if (a.getQoSInformationNeg() != null) {
						containerStr.append(a.getQoSInformationNeg().getQCI() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getQoSInformationNeg() != null) {
						containerStr.append(a.getQoSInformationNeg().getARP() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getQoSInformationNeg() != null) {
						containerStr.append(a.getQoSInformationNeg().getAPNAggregateMaxBitrateUL() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getQoSInformationNeg() != null) {
						containerStr.append(a.getQoSInformationNeg().getAPNAggregateMaxBitrateDL() + ",");
					} else {
						containerStr.append(",");
					}
					/***************************************/

					if (a.getServingNodeAddress() != null) {
						try {
							containerStr.append(OutputConverter.convertIp(
									a.getServingNodeAddress().getIPBinaryAddress().getIPBinV4Address().toString())
									+ ",");
						} catch (UnknownHostException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						containerStr.append(",");
					}
					if (a.getDatavolumeFBCUplink() != null) {
						containerStr.append(a.getDatavolumeFBCUplink() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getDatavolumeFBCUplink() != null) {
						containerStr.append(a.getDatavolumeFBCDownlink() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getTimeOfReport() != null) {
						containerStr.append(OutputConverter.convertTime(a.getTimeOfReport().toString()) + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getFailureHandlingContinue() != null) {
						containerStr.append(a.getFailureHandlingContinue() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getServiceIdentifier() != null) {
						containerStr.append(a.getServiceIdentifier() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getPSFurnishChargingInformation() != null) {
						containerStr.append(a.getPSFurnishChargingInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getAFRecordInformation() != null) {
						containerStr.append(a.getAFRecordInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getUserLocationInformation() != null) {
						containerStr.append(a.getUserLocationInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getEventBasedChargingInformation() != null) {
						containerStr.append(a.getEventBasedChargingInformation() + ",");
					} else {
						containerStr.append(",");
					}

					if (a.getTimeQuotaMechanism() != null) {
						containerStr.append(a.getTimeQuotaMechanism() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getServiceSpecificInfo() != null) {
						containerStr.append(a.getServiceSpecificInfo() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getServiceSpecificInfo() != null) {
						containerStr.append(a.getThreeGPP2UserLocationInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getSponsorIdentity() != null) {
						containerStr.append(a.getSponsorIdentity() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getApplicationServiceProviderIdentity() != null) {
						containerStr.append(a.getApplicationServiceProviderIdentity() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getADCRuleBaseName() != null) {
						containerStr.append(a.getADCRuleBaseName() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getPresenceReportingAreaStatus() != null) {
						containerStr.append(a.getPresenceReportingAreaStatus() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getUserCSGInformation() != null) {
						containerStr.append(a.getUserCSGInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getUWANUserLocationInformation() != null) {
						containerStr.append(a.getUWANUserLocationInformation() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getServingPLMNRateControl() != null) {
						containerStr.append(a.getServingPLMNRateControl() + ",");
					} else {
						containerStr.append(",");
					}
					if (a.getAPNRateControl() != null) {
						containerStr.append(a.getAPNRateControl() + ",");
					} else {
						containerStr.append(",");
					}

					// printing to container file
					containerPw.println(containerStr.toString());

					// print values to inbound file
					if (!this.servedIMSI.startsWith("63105")) {

						PrintWriter printWriter;

						Path path = null;
						try {
							// creating sub directories i.e, /offline/output/cmg_cdr/inbound/data
							path = Files.createDirectories(Paths.get(outputDir + "/" + "inbound/data"));

							String outputFile = path + "/" + inputFileName + "_container_inbound.csv";

							File file = new File(outputFile);

							if (file.exists() && !file.isDirectory()) {
								printWriter = new PrintWriter(new FileOutputStream(file, true));
								// write values only
								printWriter.println(containerStr.toString());
							} else {
								// new file
								printWriter = new PrintWriter(outputFile);
								// write heading on first line
								printWriter.println(getContainerHeader());
								// write values
								printWriter.println(containerStr.toString());
							}
							printWriter.close(); // closing the output file writer
						} catch (Exception e) {
							e.printStackTrace();
						}
					} // End of inbound if

				} // end of if
			}); // end of foreach loop

			/*******************************/
		} // end of getListOfServiceData

		/////////////// ServingNodeType ///////////////
		if (pGWRecord.getServingNodeType() != null) {
			sb.append(pGWRecord.getServingNodeType().getServingNodeType().get(0)).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getServedMNNAI() != null) {
			sb.append(pGWRecord.getServedMNNAI()).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getPGWPLMNIdentifier() != null) {
			sb.append(OutputConverter.convertPLMN(pGWRecord.getPGWPLMNIdentifier().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getStartTime() != null) {
			sb.append(OutputConverter.convertTime(pGWRecord.getStartTime().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getStopTime() != null) {
			sb.append(OutputConverter.convertTime(pGWRecord.getStopTime().toString())).append(",");
		} else
			sb.append(",");
		if (pGWRecord.getServed3gpp2MEID() != null) {
			sb.append(pGWRecord.getServed3gpp2MEID());
		} else
			sb.append(",");
		if (pGWRecord.getPDNConnectionChargingID() != null) {
			sb.append(pGWRecord.getPDNConnectionChargingID());
		} else
			sb.append(",");
		if (pGWRecord.getIMSIunauthenticatedFlag() != null) {
			sb.append(pGWRecord.getIMSIunauthenticatedFlag());
		} else
			sb.append(",");
		if (pGWRecord.getUserCSGInformation() != null) {
			sb.append(pGWRecord.getUserCSGInformation());
		} else
			sb.append(",");
		if (pGWRecord.getThreeGPP2UserLocationInformation() != null) {
			sb.append(pGWRecord.getThreeGPP2UserLocationInformation());
		} else
			sb.append(",");
		if (pGWRecord.getServedPDPPDNAddressExt() != null) {
			sb.append(pGWRecord.getServedPDPPDNAddressExt());
		} else
			sb.append(",");
		if (pGWRecord.getLowPriorityIndicator() != null) {
			sb.append(pGWRecord.getLowPriorityIndicator());
		} else
			sb.append(",");
		if (pGWRecord.getDynamicAddressFlagExt() != null) {
			sb.append(pGWRecord.getDynamicAddressFlagExt());
		} else
			sb.append(",");
		if (pGWRecord.getServingNodeiPv6Address() != null) {
			sb.append(pGWRecord.getServingNodeiPv6Address());
		} else
			sb.append(",");
		if (pGWRecord.getPGWiPv6AddressUsed() != null) {
			sb.append(pGWRecord.getPGWiPv6AddressUsed());
		} else
			sb.append(",");
		if (pGWRecord.getTWANUserLocationInformation() != null) {
			sb.append(pGWRecord.getTWANUserLocationInformation());
		} else
			sb.append(",");
		if (pGWRecord.getRetransmission() != null) {
			sb.append(pGWRecord.getRetransmission());
		} else
			sb.append(",");
		if (pGWRecord.getUserLocationInfoTime() != null) {
			sb.append(pGWRecord.getUserLocationInfoTime());
		} else
			sb.append(",");
		if (pGWRecord.getCNOperatorSelectionEnt() != null) {
			sb.append(pGWRecord.getCNOperatorSelectionEnt());
		} else
			sb.append(",");
		if (pGWRecord.getEPCQoSInformation() != null) {
			sb.append(pGWRecord.getEPCQoSInformation());
		} else
			sb.append(",");
		if (pGWRecord.getPresenceReportingAreaInfo() != null) {
			sb.append(pGWRecord.getPresenceReportingAreaInfo());
		} else
			sb.append(",");
		if (pGWRecord.getLastUserLocationInformation() != null) {
			sb.append(pGWRecord.getLastUserLocationInformation());
		} else
			sb.append(",");
		if (pGWRecord.getLastMSTimeZone() != null) {
			sb.append(pGWRecord.getLastMSTimeZone());
		} else
			sb.append(",");
		if (pGWRecord.getEnhancedDiagnostics() != null) {
			sb.append(pGWRecord.getEnhancedDiagnostics());
		} else
			sb.append(",");
		if (pGWRecord.getUWANUserLocationInformation() != null) {
			sb.append(pGWRecord.getUWANUserLocationInformation());
		} else
			sb.append(",");
		if (pGWRecord.getSGiPtPTunnellingMethod() != null) {
			sb.append(pGWRecord.getSGiPtPTunnellingMethod());
		} else
			sb.append(",");
		if (pGWRecord.getUNIPDUCPOnlyFlag() != null) {
			sb.append(pGWRecord.getUNIPDUCPOnlyFlag());
		} else
			sb.append(",");
		if (pGWRecord.getServingPLMNRateControl() != null) {
			sb.append(pGWRecord.getServingPLMNRateControl());
		} else
			sb.append(",");
		if (pGWRecord.getAPNRateControl() != null) {
			sb.append(pGWRecord.getAPNRateControl());
		} else
			sb.append(",");
		if (pGWRecord.getPDPPDNTypeExtension() != null) {
			sb.append(pGWRecord.getPDPPDNTypeExtension());
		} else
			sb.append(",");
		if (pGWRecord.getMOExceptionDataCounter() != null) {
			sb.append(pGWRecord.getMOExceptionDataCounter());
		} else
			sb.append(",");
		if (pGWRecord.getListOfRANSecondaryRATUsageReports() != null) {
			sb.append(pGWRecord.getListOfRANSecondaryRATUsageReports());
		} else
			sb.append(",");
	}

	// recordType
	public void toFormatsgw(StringBuilder sbsgw, PrintWriter containerPwsgw, SGWRecord sgwRecord, String outputDir,
			String inputFileName) throws UnknownHostException, ClassNotFoundException {
		if (sgwRecord.getRecordType() != null) {
			sbsgw.append(OutputConverter.convertRecordType(Integer.parseInt(sgwRecord.getRecordType().toString())))
					.append(",");
		} else {
			sbsgw.append(",");
		}
		if (sgwRecord.getServedIMSI() != null) {

			String s = OutputConverter.convertServedIMSI(sgwRecord.getServedIMSI().toString());
			this.servedIMSI = s;

			sbsgw.append(s).append(",");

		} else {
			sbsgw.append(",");
		}

		if (sgwRecord.getSGWAddress() != null) {
			String s = OutputConverter
					.convertIp(sgwRecord.getSGWAddress().getIPBinaryAddress().getIPBinV4Address().toString());
			sbsgw.append(s).append(",");
		} else {
			sbsgw.append(",");
		}

		if (sgwRecord.getChargingID() != null) {
			sbsgw.append(sgwRecord.getChargingID()).append(",");
		} else
			sbsgw.append(",");
		// if (pGWRecord.getServingNodeAddress() != null) {
		// sb.append(pGWRecord.getServingNodeAddress()).append(",");
		// } else
		// sb.append(",");

		/////////// ArrayList ///////////////
		if (sgwRecord.getServingNodeAddress() != null) {
			if (sgwRecord.getServingNodeAddress().getGSNAddress() != null) {

				sbsgw.append("{");
				List<GSNAddress> cosc = sgwRecord.getServingNodeAddress().getGSNAddress();

				for (GSNAddress list : cosc) {

					if (list.getIPBinaryAddress() != null) {

						sbsgw.append(
								OutputConverter.convertIp(list.getIPBinaryAddress().getIPBinV4Address().toString()));
						// .append(",");
					} else
						sbsgw.append(",");
				}
				sbsgw.append("},");
			} else
				sbsgw.append("{},");
		}
		///////////////////////////////////////////

		if (sgwRecord.getAccessPointNameNI() != null) {
			sbsgw.append(sgwRecord.getAccessPointNameNI()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getPdpPDNType() != null) {
			sbsgw.append(OutputConverter.convertPdpPdnType(sgwRecord.getPdpPDNType().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getServedPDPPDNAddress() != null) {
			sbsgw.append(OutputConverter.convertIp(sgwRecord.getServedPDPPDNAddress().getIPAddress()
					.getIPBinaryAddress().getIPBinV4Address().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getDynamicAddressFlag() != null) {
			sbsgw.append(sgwRecord.getDynamicAddressFlag()).append(",");
		} else
			sbsgw.append(",");

		if (sgwRecord.getListOfTrafficVolumes() != null
				&& sgwRecord.getListOfTrafficVolumes().getChangeOfCharCondition() != null) {

			// List<ChangeOfCharCondition> cosc = sgwRecord.getSGWChange().value;
			List<ChangeOfCharCondition> sinc = sgwRecord.getListOfTrafficVolumes().getChangeOfCharCondition();

			sinc.stream().forEach(ch -> {

				if (sgwRecord.getLocalSequenceNumber() != null) {
					StringBuilder containerStrSgw = new StringBuilder();
					containerStrSgw.append(sgwRecord.getLocalSequenceNumber()).append(",");
					// add LocalSequenceNumber

					if (ch.getQosRequested() != null) {
						containerStrSgw.append(ch.getQosRequested() + ",");
					} else
						containerStrSgw.append(",");
					if (ch.getQosNegotiated() != null) {
						containerStrSgw.append(ch.getQosNegotiated() + ",");
					} else
						containerStrSgw.append(",");
					if (ch.getDataVolumeGPRSUplink() != null) {
						containerStrSgw.append(ch.getDataVolumeGPRSUplink() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getDataVolumeGPRSDownlink() != null) {
						containerStrSgw.append(ch.getDataVolumeGPRSDownlink() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getChangeCondition() != null) {
						containerStrSgw.append((ch.getChangeCondition().toString()) + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getChangeTime() != null) {
						containerStrSgw.append(OutputConverter.convertTime(ch.getChangeTime().toString()) + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getFailureHandlingContinue() != null) {
						containerStrSgw.append(ch.getFailureHandlingContinue() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getUserLocationInformation() != null) {
						containerStrSgw.append(ch.getUserLocationInformation() + ",");
					} else {
						containerStrSgw.append(",");
					}
					/////////////// QOS Information ////////////////
					if (ch.getEPCQoSInformation() != null) {
						containerStrSgw.append(ch.getEPCQoSInformation().getQCI() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getEPCQoSInformation() != null) {
						containerStrSgw.append(ch.getEPCQoSInformation().getARP() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getEPCQoSInformation() != null) {
						containerStrSgw.append(ch.getEPCQoSInformation().getAPNAggregateMaxBitrateUL() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getEPCQoSInformation() != null) {
						containerStrSgw.append(ch.getEPCQoSInformation().getAPNAggregateMaxBitrateDL() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getChargingID() != null) {
						containerStrSgw.append(ch.getChargingID() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getPresenceReportingAreaStatus() != null) {
						containerStrSgw.append(ch.getPresenceReportingAreaStatus() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getUserCSGInformation() != null) {
						containerStrSgw.append(ch.getUserCSGInformation() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getDiagnostics() != null) {
						containerStrSgw.append(ch.getDiagnostics() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getEnhancedDiagnostics() != null) {
						containerStrSgw.append(ch.getEnhancedDiagnostics() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getRATType() != null) {
						containerStrSgw.append(OutputConverter.convertTime(ch.getRATType().toString()) + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getAccessAvailabilityChangeReason() != null) {
						containerStrSgw.append(ch.getAccessAvailabilityChangeReason() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getUWANUserLocationInformation() != null) {
						containerStrSgw.append(ch.getUWANUserLocationInformation() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getRelatedChangeOfCharCondition() != null) {
						containerStrSgw.append(ch.getRelatedChangeOfCharCondition() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getCPCIoTEPSOptimisationIndicator() != null) {
						containerStrSgw.append(ch.getCPCIoTEPSOptimisationIndicator() + ",");
					} else {
						containerStrSgw.append(",");
					}
					if (ch.getServingPLMNRateControl() != null) {
						containerStrSgw.append(ch.getServingPLMNRateControl() + ",");
					} else {
						containerStrSgw.append(",");
					}

					// printing to container file

					containerPwsgw.println(containerStrSgw.toString());

					if (!this.servedIMSI.startsWith("63105")) {

						PrintWriter printWriter3;

						Path path4 = null;
						try {
							// creating sub directories i.e, /offline/output/cmg_cdr/inbound/data
							path4 = Files.createDirectories(Paths.get(outputDir + "/" + "inbound/data"));
							StringBuilder inputFileSgwinbound = new StringBuilder(inputFileName);
							int indexInboundContainer = 2;
							char ch2 = 'S';
							inputFileSgwinbound.setCharAt(indexInboundContainer, ch2);

							String outputFile4 = path4 + "/" + inputFileSgwinbound + "_container_INBOUND_DWH.csv";

							File file4 = new File(outputFile4);

							if (file4.exists() && !file4.isDirectory()) {
								printWriter3 = new PrintWriter(new FileOutputStream(file4, true));
								// write values only
								printWriter3.println(containerStrSgw.toString());
							} else {
								// new file
								printWriter3 = new PrintWriter(outputFile4);
								// write heading on first line
								printWriter3.println(getContainerHeaderSgw());
								// write values
								printWriter3.println(containerStrSgw.toString());
							}
							printWriter3.close(); // closing the output file writer
						} catch (Exception e) {
							e.printStackTrace();
						}

					}

				}

			});
		}

		if (sgwRecord.getRecordOpeningTime() != null) {
			sbsgw.append(OutputConverter.convertTime(sgwRecord.getRecordOpeningTime().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getDuration() != null) {
			sbsgw.append(sgwRecord.getDuration()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getCauseForRecClosing() != null) {
			sbsgw.append(sgwRecord.getCauseForRecClosing()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getDiagnostics() != null) {
			sbsgw.append(sgwRecord.getDiagnostics().getManufacturerSpecificCause()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getRecordSequenceNumber() != null) {
			sbsgw.append(sgwRecord.getRecordSequenceNumber()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getNodeID() != null) {
			sbsgw.append(sgwRecord.getNodeID()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getRecordExtensions() != null) {
			sbsgw.append(sgwRecord.getRecordExtensions().getManagementExtension()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getLocalSequenceNumber() != null) {
			sbsgw.append(sgwRecord.getLocalSequenceNumber()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getApnSelectionMode() != null) {
			sbsgw.append(sgwRecord.getApnSelectionMode()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getServedMSISDN() != null) {
			sbsgw.append(sgwRecord.getServedMSISDN()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getChargingCharacteristics() != null) {
			sbsgw.append(sgwRecord.getChargingCharacteristics()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getChChSelectionMode() != null) {
			sbsgw.append(sgwRecord.getChChSelectionMode()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getIMSsignalingContext() != null) {
			sbsgw.append(sgwRecord.getIMSsignalingContext()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getServingNodePLMNIdentifier() != null) {
			sbsgw.append((sgwRecord.getServingNodePLMNIdentifier().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getServedIMEISV() != null) {
			sbsgw.append(sgwRecord.getServedIMEISV()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getRATType() != null) {
			sbsgw.append(sgwRecord.getRATType()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getMSTimeZone() != null) {
			sbsgw.append(sgwRecord.getMSTimeZone()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getUserLocationInformation() != null) {
			sbsgw.append(sgwRecord.getUserLocationInformation()).append(",");
		} else
			sbsgw.append(",");
		/////////// ArrayList ///////////////
		if (sgwRecord.getSGWChange() != null) {
			sbsgw.append(sgwRecord.getSGWChange()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getServingNodeType() != null) {
			sbsgw.append(sgwRecord.getServingNodeType().getServingNodeType().get(0)).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getPGWAddressUsed() != null) {
			sbsgw.append(sgwRecord.getPGWAddressUsed().toString()).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getPGWPLMNIdentifier() != null) {
			sbsgw.append(OutputConverter.convertPLMN(sgwRecord.getPGWPLMNIdentifier().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getStartTime() != null) {
			sbsgw.append(OutputConverter.convertTime(sgwRecord.getStartTime().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getStopTime() != null) {
			sbsgw.append(OutputConverter.convertTime(sgwRecord.getStopTime().toString())).append(",");
		} else
			sbsgw.append(",");
		if (sgwRecord.getPDNConnectionChargingID() != null) {
			sbsgw.append(sgwRecord.getPDNConnectionChargingID());
		} else
			sbsgw.append(",");
		if (sgwRecord.getIMSIunauthenticatedFlag() != null) {
			sbsgw.append(sgwRecord.getIMSIunauthenticatedFlag());
		} else
			sbsgw.append(",");
		if (sgwRecord.getUserCSGInformation() != null) {
			sbsgw.append(sgwRecord.getUserCSGInformation());
		} else
			sbsgw.append(",");
		if (sgwRecord.getServedPDPPDNAddressExt() != null) {
			sbsgw.append(sgwRecord.getServedPDPPDNAddressExt());
		} else
			sbsgw.append(",");
		if (sgwRecord.getLowPriorityIndicator() != null) {
			sbsgw.append(sgwRecord.getLowPriorityIndicator());
		} else
			sbsgw.append(",");
		if (sgwRecord.getDynamicAddressFlagExt() != null) {
			sbsgw.append(sgwRecord.getDynamicAddressFlagExt());
		} else
			sbsgw.append(",");
		if (sgwRecord.getSGWiPv6Address() != null) {
			sbsgw.append(sgwRecord.getSGWiPv6Address());
		} else
			sbsgw.append(",");
		if (sgwRecord.getServingNodeiPv6Address() != null) {
			sbsgw.append(sgwRecord.getServingNodeiPv6Address());
		} else
			sbsgw.append(",");
		if (sgwRecord.getPGWiPv6AddressUsed() != null) {
			sbsgw.append(sgwRecord.getPGWiPv6AddressUsed());
		} else
			sbsgw.append(",");
		if (sgwRecord.getRetransmission() != null) {
			sbsgw.append(sgwRecord.getRetransmission());
		} else
			sbsgw.append(",");
		if (sgwRecord.getUserLocationInfoTime() != null) {
			sbsgw.append(sgwRecord.getUserLocationInfoTime());
		} else
			sbsgw.append(",");
		if (sgwRecord.getCNOperatorSelectionEnt() != null) {
			sbsgw.append(sgwRecord.getCNOperatorSelectionEnt());
		} else
			sbsgw.append(",");
		if (sgwRecord.getPresenceReportingAreaInfo() != null) {
			sbsgw.append(sgwRecord.getPresenceReportingAreaInfo());
		} else
			sbsgw.append(",");
		if (sgwRecord.getLastUserLocationInformation() != null) {
			sbsgw.append(sgwRecord.getLastUserLocationInformation());
		} else
			sbsgw.append(",");
		if (sgwRecord.getLastMSTimeZone() != null) {
			sbsgw.append(sgwRecord.getLastMSTimeZone());
		} else
			sbsgw.append(",");
		if (sgwRecord.getEnhancedDiagnostics() != null) {
			sbsgw.append(sgwRecord.getEnhancedDiagnostics());
		} else
			sbsgw.append(",");
		if (sgwRecord.getCPCIoTEPSOptimisationIndicator() != null) {
			sbsgw.append(sgwRecord.getCPCIoTEPSOptimisationIndicator());
		} else
			sbsgw.append(",");
		if (sgwRecord.getUNIPDUCPOnlyFlag() != null) {
			sbsgw.append(sgwRecord.getUNIPDUCPOnlyFlag());
		} else
			sbsgw.append(",");
		if (sgwRecord.getServingPLMNRateControl() != null) {
			sbsgw.append(sgwRecord.getServingPLMNRateControl());
		} else
			sbsgw.append(",");
		if (sgwRecord.getPDPPDNTypeExtension() != null) {
			sbsgw.append(sgwRecord.getPDPPDNTypeExtension());
		} else
			sbsgw.append(",");
		if (sgwRecord.getMOExceptionDataCounter() != null) {
			sbsgw.append(sgwRecord.getMOExceptionDataCounter());
		} else
			sbsgw.append(",");
		if (sgwRecord.getListOfRANSecondaryRATUsageReports() != null) {
			sbsgw.append(sgwRecord.getListOfRANSecondaryRATUsageReports());
		} else
			sbsgw.append(",");

	}
}// end of class