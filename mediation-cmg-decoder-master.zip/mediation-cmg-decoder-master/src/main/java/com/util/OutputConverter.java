package com.util;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.xml.bind.DatatypeConverter;

import com.beanit.jasn1.ber.types.BerOctetString;

public class OutputConverter {

		 /** public static void main(String[] args) throws UnknownHostException {
			
		//String time="0AF0EAE1";
			String str="F18D";
			//System.out.println(convertTime(time));
			//System.out.println(convertIp(time));
			
			System.out.println(convertPdpPdnType(str));
		} **/
		


	//Converts byte to TBCD
	public static String hexOp(byte[] num) {


		StringBuffer sbf = new StringBuffer();
		for (int i : num) {

			int j=(i & 0xF);
			int k=((i-j)&(0xf0));
			sbf.append(j).append((k>>4));

		}
		return sbf.toString().substring(0, sbf.length()-2);

	}

	//Converts ip to string
	public static String convertIp(String ipaddress) throws UnknownHostException {

		//System.err.println(ipaddress);
		InetAddress ipadd = InetAddress.getByAddress(DatatypeConverter.parseHexBinary(ipaddress.toString()));
		return ipadd.toString().substring(1,ipadd.toString().length());
		
	}
	
	  public static String convertRecordType(Integer recordType) {
	  
	  if(recordType==85) { 
		  return "PGWRecord";
		  } 
	  if(recordType==69) {
		  return
	   "aTSRecord"; 
		  } 
	  else if(recordType == 84) {
		  return "SGWRecord";
	  }
	  else return "undefined";
	  
	  }
	
	public static String convertTime(String time) {

		//2001182359282B0055
		//2020-01-18 23:55:31 +00:55

		return "20"+time.substring(0,2)+"-"+time.substring(2,4)+"-"+time.substring(4,6)+" "+
		time.substring(6,8)+":"+time.substring(8,10)+":"+time.substring(10,12)+" "+(char)(Integer.parseInt(time.substring(12,14),16))+
		time.substring(14,16)+":"+time.substring(16,18);
	}

	public static String convertPLMN(String plmn) {

		StringBuilder sb1= new StringBuilder();
		StringBuilder sb2= new StringBuilder();
		StringBuilder sb3= new StringBuilder();

		sb1.append(plmn.substring(0,2)).reverse();
		sb2.append(plmn.substring(2,4)).reverse();
		sb2.deleteCharAt(sb2.length()-1);
		sb3.append(plmn.substring(4,6)).reverse();
		return sb1.append(sb2).append(sb3).toString();

	}
	
	public static String convertServedIMSI(String imsi) {

		StringBuilder sb1= new StringBuilder();
		StringBuilder sb2= new StringBuilder();
		StringBuilder sb3= new StringBuilder();
		StringBuilder sb4= new StringBuilder();
		StringBuilder sb5= new StringBuilder();
		StringBuilder sb6= new StringBuilder();
		StringBuilder sb7= new StringBuilder();
		StringBuilder sb8= new StringBuilder();

		sb1.append(imsi.substring(0,2)).reverse();
		sb2.append(imsi.substring(2,4)).reverse();
		sb3.append(imsi.substring(4,6)).reverse();
		sb4.append(imsi.substring(6,8)).reverse();
		sb5.append(imsi.substring(8,10)).reverse();
		sb6.append(imsi.substring(10,12)).reverse();
		sb7.append(imsi.substring(12,14)).reverse();
		sb8.append(imsi.substring(14,16)).reverse();
		sb8.deleteCharAt(sb8.length()-1);
		
		return sb1.append(sb2).append(sb3).append(sb4).append(sb5).append(sb6).append(sb7).append(sb8).toString();
	}

	public static String convertServedMSISDN(String msisdn) {

		
		StringBuilder sb1= new StringBuilder();
		StringBuilder sb2= new StringBuilder();
		StringBuilder sb3= new StringBuilder();
		StringBuilder sb4= new StringBuilder();
		StringBuilder sb5= new StringBuilder();
		StringBuilder sb6= new StringBuilder();
		StringBuilder sb7= new StringBuilder();
		StringBuilder sb8= new StringBuilder();

		sb1.append(msisdn.substring(0,2));
		sb2.append(msisdn.substring(2,4)).reverse();
		sb3.append(msisdn.substring(4,6)).reverse();
		sb4.append(msisdn.substring(6,8)).reverse();
		sb5.append(msisdn.substring(8,10)).reverse();
		sb6.append(msisdn.substring(10,12)).reverse();
		sb7.append(msisdn.substring(12,14)).reverse();
		
		return sb1.append(sb2).append(sb3).append(sb4).append(sb5).append(sb6).append(sb7).toString();
	}
	
	public static String convertLocation(String location) {

		//1826F1425DD726F142002B2B02
		//012345 67 89 10 11 12 13 14 15  16 17 89212345
		//MCC:621 MNC:24 TAC:0x5DD7 MCC:621 MNC:24 ECI:0x02B2B02 

		//long a=System.currentTimeMillis();

		//System.out.println(a);
		StringBuilder sb1= new StringBuilder();
		String mcc=location.substring(2,6);
		sb1.append("MCC:").append(mcc.charAt(1)).append(mcc.charAt(0)).append(mcc.charAt(3));
		String mnc=location.substring(6,8);
		sb1.append(" MNC:").append(mnc.charAt(1)).append(mnc.charAt(0));

		String tac=location.substring(8,12);
		sb1.append(" TAC:0x").append(tac);

		sb1.append(" MCC:").append(mcc.charAt(1)).append(mcc.charAt(0)).append(mcc.charAt(3));

		sb1.append(" MNC:").append(mnc.charAt(1)).append(mnc.charAt(0));

		String eci=location.substring(19,26);
		sb1.append(" ECI:0x").append(eci);
		
		//long diff=System.currentTimeMillis();
		//System.out.println(diff);

		return sb1.toString();
	}

	public static final String convertURl(String hex)
	{
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < hex.length(); i+=2) {
			String str = hex.substring(i, i+2);
			output.append((char)Integer.parseInt(str, 16));
		}
		return output.toString().trim();
	}
	
	public static final String convertHexToString(String hex)
	{
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < hex.length(); i+=2) {
			String str = hex.substring(i, i+2);
			output.append((char)Integer.parseInt(str, 16));
		}
	return output.toString().trim();
	}
	
	 public static String convertPdpPdnType(String pdppdn) {
		 
		 StringBuilder pdp1 = new StringBuilder();
		 StringBuilder pdp2 = new StringBuilder();
		 
		 //Integer str1 = Integer.parseInt(pdppdn.substring(1, 2));
		 //Integer str2 = Integer.parseInt(pdppdn.substring(2, pdppdn.length()));
		 
		 String str1 = pdppdn.substring(1, 2);
		 String str2 = pdppdn.substring(2, pdppdn.length());
		 
		 if(str1.equals("0")) {
			 pdp1.append("Organisation:ETSI;"); 
		 }
		 if(str1.equals("1")) {
			 pdp1.append("Organisation:IETF;");
		 }
		 
		 if(str2.equals("1")) {
			 pdp2.append("Value:PPP");
		 }
		 if(str2.equals("21")) {
			 pdp2.append("Value:IPv4");
		 }
		 if(str2.equals("57")) {
			 pdp2.append("Value:IPv6");
		 }
		 if(str2.equals("8D")) {
			 pdp2.append("Value:IPv4v6");
		 }
		 return pdp1.append(pdp2).toString();
	}
	 
	 
	 /**public static String convertDiagnostics(String diagnostics) {


	} **/

}