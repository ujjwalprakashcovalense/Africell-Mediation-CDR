package com.main;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

public class Jasn1Africell {

	public static void main(String[] args)
			throws IOException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException {

		Properties properties = new Properties();
		FileReader fr = new FileReader(new File(args[0]));
		properties.load(fr);

		int waitTime = Integer.parseInt(properties.getProperty("cdr.wait.time"));

		JasnProcessor processor = new JasnProcessor();

		// calling scheduling the process
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				processor.converter(properties);
			}
		}, 0, waitTime); // calling each waitTime eg: 10 sec
	}
}