package com.main;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.UnknownHostException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.util.OutputConverter;
import com.util.ZippingUtility;

import aa3gpp0.ChangeOfCharCondition3gpp;
import aa3gpp0.ManagementExtension;
import aa3gpp1.CDR3gpp;
import aa3gpp1.SGSNPDPRecord3gpp;

public class JasnProcessor {
	private final static Logger logger = LoggerFactory.getLogger(Jasn1Africell.class.getName());
	private String servedIMSI;
	/**
	 * Method will decode the binary file to ascii.
	 * 
	 * @param properties
	 * @throws IOException
	 */
	public void converter(Properties properties) {

		File file_process = new File(properties.getProperty("processDir"));
		file_process.mkdir();

		File file_done = new File(properties.getProperty("doneDir"));
		file_done.mkdir();

		File file_output = new File(properties.getProperty("outputDir"));
		file_output.mkdir();
		List<File> files = null;
		if (Boolean.parseBoolean(properties.getProperty("unzipBeforeProcessing")) == true) {

			try {
				ZippingUtility.unZip(properties.getProperty("inputDir"), properties.getProperty("processDir"));

//				Files.walk(Paths.get(properties.getProperty("inputDir"))).map(Path::toFile).forEach(File::delete);

				// filtering binary files
				files = Files.list(Paths.get(properties.getProperty("inputDir")))
						// .filter(path -> path.getFileName().toString().startsWith(inputFilePrefix))
						// .filter(path -> path.toString().endsWith(inputFileExtension))
						.limit(Integer.parseInt(properties.getProperty("cdr.batchsize"))).map(Path::toFile)
						.collect(Collectors.toList());
			} catch (Exception e) {
				logger.error("Could not process files from Input Folder" + e.getMessage());
			}

		} else {
			// files = new File(properties.getProperty("inputDir")).listFiles();

			// filtering binary files
			try(Stream<File> stream = Files.list(Paths.get(properties.getProperty("inputDir")))
										// .filter(path -> path.getFileName().toString().startsWith(inputFilePrefix))
										// .filter(path -> path.toString().endsWith(inputFileExtension))
										.limit(Integer.parseInt(properties.getProperty("cdr.batchsize"))).map(Path::toFile)
										 ) {
				files = stream.collect(Collectors.toList());
			} catch (Exception e) {
				logger.error("Could not process files from Input Folder" + e.getMessage());
			}

			for (File file : files) {
				PrintWriter printWriter = null;

				try {
					logger.info("File has been proccessing : " + file.getName());
					byte[] bFile = readBytesFromFile(file.toString());

					ByteArrayInputStream is = new ByteArrayInputStream(bFile);
					CDR3gpp callerInfo_decode = new CDR3gpp();
					
					String outputDir = properties.getProperty("outputDir");
					String inputFile = file.getName().substring(0, file.getName().lastIndexOf(".")); // trim upto before DAT
					//CF00009_20220404022921_DWH.csv
					String outputFile = properties.getProperty("outputDir") + "/" + inputFile +"_DWH"  + ".csv";
					
					if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == true) {
						String outputFileJ = properties.getProperty("outputDir") + "/" + inputFile + ".json";
						
						printWriter = new PrintWriter(outputFileJ);
						// System.setOut(o);
					}else {
						printWriter = new PrintWriter(outputFile);
					}
					if (Boolean.parseBoolean(properties.getProperty("needHeaderInOutput")) == true)
						printWriter.println(getHeader());
					// logger.info("Header : " + Jasn1Africell.getHeader() );

					// is.skip(40);
//					is.skip(Long.parseLong(properties.getProperty("skipHeader")));

					while (is.available() != 0) {

						StringBuilder sb = new StringBuilder();

						callerInfo_decode.decode(is);
						if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == false) {
							toFormat(sb, callerInfo_decode.getSGSNPDPRecord3gpp());
							printWriter.println(sb.toString());
							//print values to inbound  file
							 if (!this.servedIMSI.startsWith("63105")) {

								PrintWriter writeInbound;
								Path path = null;
									// creating sub directories i.e, /offline/output/cmm_cdr/inbound/data
									path = Files.createDirectories(Paths.get(outputDir + "/" + "inbound/data"));

									//CF00081_202207211654_inbound_DWH.csv
									String outFile = path + "/" + inputFile + "_INBOUND_DWH"  + ".csv"; // 

									File f = new File(outFile);

									if (f.exists() && !f.isDirectory()) {
										writeInbound = new PrintWriter(new FileOutputStream(f, true));
										// write values only
										writeInbound.println(sb.toString());
									} else {
										// new file
										writeInbound = new PrintWriter(outFile);
										// write heading on first line
										writeInbound.println(getHeader());
										// write values
										writeInbound.println(sb.toString());
									}
									writeInbound.close(); // closing the output file writer
							
						     } // End of inbound if
						}
						// System.err.println(Integer.toHexString(is.read()));
						// is.skip(8);
//						is.skip(Long.parseLong(properties.getProperty("skipDelimiter")));
						if (Boolean.parseBoolean(properties.getProperty("needJsonOutput")) == true) {
							printWriter.println(callerInfo_decode);

						}
					}

					logger.info("ASN1 conversion completed successfully!");

					try {

						Files.move(Paths.get(file.toString()),
								Paths.get(properties.getProperty("doneDir") + "/" + file.getName() + ".DONE"),
								StandardCopyOption.REPLACE_EXISTING);
						logger.info("Input file moved to archive path");

					} catch (FileAlreadyExistsException e) {
						logger.warn("Exception occured when moving files from input to done directory");

					}
				} catch (Exception ex) {
					logger.warn("Error occured while proccessing the file: " + file.getName() + ex.getMessage());
					// input file moving to failed path
					ex.printStackTrace();
					try {
						Files.move(Paths.get(file.toString()),
								Paths.get(properties.getProperty("doneDir") + "/" + file.getName() + ".Failed"),
								StandardCopyOption.REPLACE_EXISTING);
						logger.info("Input file moved to archive path");
					} catch (IOException e) {
						//
					}

				} finally {
					printWriter.close();
				}

			} // for loop end

			if (files.isEmpty()) {
				logger.info("Waiting for input file - " + properties.getProperty("cdr.wait.time") + " sec");
			}

		} // else end
	} // end of converter

	private static String getHeader() {
		// // TODO Auto-generated method stub
		//
		StringBuilder sb = new StringBuilder();
		sb.append(
				//"recordType,servedIMSI,servedIMEI,sgsnAddress,msNetworkCapability,routingAreaCode,locationAreaCode,cellIdentifier,chargingID,ggsnAddressUsed,accessPointNameNI,pDPType,servedPDPAddress,listOfTrafficVolumes{qosRequested,qosNegotiated,dataVolumeGPRSUplink,dataVolumeGPRSDownlink,changeCondition,changeTime},recordOpeningTime,duration,causeForRecClosing,diagnostics{identifier,information},nodeId,recordExtensions{identifier,information},localSequenceNumber,aPNSelectionMode,accessPointNameOI,servedMSISDN,chargingCharacteristics,rATType,chChSelectionMode,dynamicAddressFlag");
	            "recordType,servedIMSI,servedIMEI,sgsnAddress,msNetworkCapability,routingAreaCode,locationAreaCode,cellIdentifier,chargingID,ggsnAddressUsed,accessPointNameNI,pDPType,servedPDPAddress,listOfTrafficVolumes{qosRequested;qosNegotiated;dataVolumeGPRSUplink;dataVolumeGPRSDownlink;changeCondition;changeTime},recordOpeningTime,duration,causeForRecClosing,diagnostics{identifier;information},nodeId,recordExtensions{identifier;information},localSequenceNumber,aPNSelectionMode,accessPointNameOI,servedMSISDN,chargingCharacteristics,rATType,chChSelectionMode,dynamicAddressFlag");
	
		return sb.toString();
	}

	private static byte[] readBytesFromFile(String filePath) {
		// TODO Auto-generated method stub
		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;

		try {

			File file = new File(filePath);
			bytesArray = new byte[(int) file.length()];

			// read file into bytes[]
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;
	}

	// To get ASCII Values
	public  void toFormat(StringBuilder sb, SGSNPDPRecord3gpp sgsnpdpRecord3gpp)
			throws UnknownHostException, ClassNotFoundException {

		// recordType
		if (sgsnpdpRecord3gpp.getRecordType() != null) {
			sb.append(OutputConverter.convertRecordType(Integer.parseInt(sgsnpdpRecord3gpp.getRecordType().toString())))
					.append(",");
		} else {
			sb.append(",");
		}
		if (sgsnpdpRecord3gpp.getServedIMSI() != null) {

			String s = OutputConverter.convertServedIMSI(sgsnpdpRecord3gpp.getServedIMSI().toString());
			this.servedIMSI = s;
			sb.append(s).append(",");

		} else {
			sb.append(",");
		}

		if (sgsnpdpRecord3gpp.getServedIMEI() != null) {
			sb.append(sgsnpdpRecord3gpp.getServedIMEI()).append(",");
		} else
			sb.append(",");  // For Confirmation

		if (sgsnpdpRecord3gpp.getSgsnAddress() != null) {
			String s = OutputConverter
					.convertIp(sgsnpdpRecord3gpp.getSgsnAddress().getIPBinaryAddress().getIPBinV4Address().toString());
			sb.append(s).append(",");
		} else {
			sb.append(",");
		}

		if (sgsnpdpRecord3gpp.getMsNetworkCapability() != null) {
			sb.append(sgsnpdpRecord3gpp.getMsNetworkCapability()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getRoutingAreaCode() != null) {
			sb.append(sgsnpdpRecord3gpp.getRoutingAreaCode()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getLocationAreaCode() != null) {
			sb.append(sgsnpdpRecord3gpp.getLocationAreaCode()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getCellIdentifier() != null) {
			sb.append(sgsnpdpRecord3gpp.getCellIdentifier()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getChargingID() != null) {
			sb.append(sgsnpdpRecord3gpp.getChargingID()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getGgsnAddressUsed().getIPBinaryAddress().getIPBinV4Address() != null ) {
			String s = OutputConverter.convertIp(
					sgsnpdpRecord3gpp.getGgsnAddressUsed().getIPBinaryAddress().getIPBinV4Address().toString());
			sb.append(s).append(",");
		
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getAccessPointNameNI() != null) {
			sb.append(sgsnpdpRecord3gpp.getAccessPointNameNI()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getPDPType() != null) {
			sb.append(sgsnpdpRecord3gpp.getPDPType()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getServedPDPAddress() != null) {
			String s = OutputConverter.convertIp(sgsnpdpRecord3gpp.getServedPDPAddress().getIPAddress()
					.getIPBinaryAddress().getIPBinV4Address().toString());
			sb.append(s).append(",");
		} else {
			sb.append(",");
		}

		/////////// ArrayList ///////////////

		if (sgsnpdpRecord3gpp.getListOfTrafficVolumes() != null) {
			if (sgsnpdpRecord3gpp.getListOfTrafficVolumes().getChangeOfCharCondition3gpp() != null) {
				sb.append("{");
				List<ChangeOfCharCondition3gpp> cocc = sgsnpdpRecord3gpp.getListOfTrafficVolumes()
						.getChangeOfCharCondition3gpp();
				for (ChangeOfCharCondition3gpp list : cocc) {
					if (list.getQosRequested() != null) {
						sb.append(list.getQosRequested()).append(";");
					} else
						sb.append(";");
					if (list.getQosNegotiated() != null) {
						sb.append(list.getQosNegotiated()).append(";");
					} else
						sb.append(";");
					if (list.getDataVolumeGPRSUplink() != null) {
						sb.append(list.getDataVolumeGPRSUplink()).append(";");
					} else
						sb.append(";");
					if (list.getDataVolumeGPRSDownlink() != null) {
						sb.append(list.getDataVolumeGPRSDownlink()).append(";");
					} else
						sb.append(";");
					if (list.getChangeCondition() != null) {
						sb.append(list.getChangeCondition()).append(";");
					} else
						sb.append(";");
					if (list.getChangeTime() != null) {
						sb.append(OutputConverter.convertTime(list.getChangeTime().toString())).append("},");
					} else
						sb.append("},");
				}
//				sb.append("},");
			} else
				sb.append("{},");
		} // end of getListOfTrafficVolumes

//		///////////////////////////////////////////

		if (sgsnpdpRecord3gpp.getRecordOpeningTime() != null) {
			sb.append(OutputConverter.convertTime(sgsnpdpRecord3gpp.getRecordOpeningTime().toString())).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getDuration() != null) {
			sb.append(sgsnpdpRecord3gpp.getDuration()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getCauseForRecClosing() != null) {
			sb.append(sgsnpdpRecord3gpp.getCauseForRecClosing()).append(",");
		} else
			sb.append(",");

		// Diagnostics array list
		if (sgsnpdpRecord3gpp.getDiagnostics() != null) {
			if (sgsnpdpRecord3gpp.getDiagnostics().getManufacturerSpecificCause() != null) {
				if (sgsnpdpRecord3gpp.getRecordExtensions() != null) {
					sb.append("{");
					List<ManagementExtension> me = sgsnpdpRecord3gpp.getRecordExtensions().getManagementExtension();
					for (ManagementExtension list : me) {
						if (list.getIdentifier() != null) {
							sb.append(list.getIdentifier()).append(";");
						} else
							sb.append(";");
						if (list.getInformation() != null) {
							sb.append(list.getInformation()).append("},");
						} else
							sb.append("},");
					}
//            	  sb.append("},");
				} else
					sb.append("{},");
			}
		} else
			sb.append("{},");
		// end of Diagnostics

		if (sgsnpdpRecord3gpp.getNodeId() != null) {
			sb.append(sgsnpdpRecord3gpp.getNodeId()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getRecordExtensions() != null) {
			if (sgsnpdpRecord3gpp.getRecordExtensions().getManagementExtension() != null) {
				sb.append("{");
				List<ManagementExtension> me = sgsnpdpRecord3gpp.getRecordExtensions().getManagementExtension();
				for (ManagementExtension list : me) {
					if (list.getIdentifier() != null) {
						sb.append(list.getIdentifier()).append(";");
					} else
						sb.append(";");
					if (list.getInformation() != null) {
						sb.append(list.getInformation()).append("},");
					} else
						sb.append("},");
				}
//		       sb.append("},");
			} else
				sb.append("{},");
		} else
			sb.append("{},");

		if (sgsnpdpRecord3gpp.getLocalSequenceNumber() != null) {
			sb.append(sgsnpdpRecord3gpp.getLocalSequenceNumber()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getAPNSelectionMode() != null) {
			sb.append(sgsnpdpRecord3gpp.getAPNSelectionMode()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getAccessPointNameOI() != null) {
			sb.append(sgsnpdpRecord3gpp.getAccessPointNameOI()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getServedMSISDN() != null) {
			sb.append(OutputConverter.convertServedMSISDN(sgsnpdpRecord3gpp.getServedMSISDN().toString())).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getChargingCharacteristics() != null) {
			sb.append(sgsnpdpRecord3gpp.getChargingCharacteristics()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getRATType() != null) {
			sb.append(sgsnpdpRecord3gpp.getRATType()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getChChSelectionMode() != null) {
			sb.append(sgsnpdpRecord3gpp.getChChSelectionMode()).append(",");
		} else
			sb.append(",");

		if (sgsnpdpRecord3gpp.getDynamicAddressFlag() != null) {
			sb.append(sgsnpdpRecord3gpp.getDynamicAddressFlag());
		} 
//		else
//			sb.append(",");

	}
}// end of class
