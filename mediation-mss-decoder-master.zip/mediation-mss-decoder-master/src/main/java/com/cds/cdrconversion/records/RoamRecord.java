/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the ROAM record decoding.
 * 
 * @author robin.varghese
 *
 */
public class RoamRecord {

  /**
   * Method to convert the ROAM record to decoded value string.
   * 
   * @param parseData  - ROAM record from 3rd byte to 159 byte, total 159-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseROAM(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final String roamMczDuration;
    final String roamMczTariffClass;
    final String roamMczPulses;
    final String roamMczDurationTenMs;
    final CommonFields roamFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = roamFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(roamFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = roamFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(roamFields.getNumberOfSsRecords());

    // CallingNumber
    offset = roamFields.setCallingNumber(parseData, offset);
    resultList.add(roamFields.getCallingNumber());

    // CalledImsi
    offset = roamFields.setCalledImsi(parseData, offset);
    resultList.add(roamFields.getCalledImsi());

    // CalledNumber
    offset = roamFields.setCalledNumber(parseData, offset);
    resultList.add(roamFields.getCalledNumber());

    // CalledMsrn
    offset = roamFields.setCalledMsrn(parseData, offset);
    resultList.add(roamFields.getCalledMsrn());

    // InCircuitGroup
    offset = roamFields.setInCircuitGroup(parseData, offset);
    resultList.add(roamFields.getInCircuitGroup());

    // InCircuit
    offset = roamFields.setInCircuit(parseData, offset);
    resultList.add(roamFields.getInCircuit());

    // OutCircuitGroup
    offset = roamFields.setOutCircuitGroup(parseData, offset);
    resultList.add(roamFields.getOutCircuitGroup());

    // OutCircuit
    offset = roamFields.setOutCircuit(parseData, offset);
    resultList.add(roamFields.getOutCircuit());

    // basicServiceType
    resultList.add(parseData[offset++]);

    // basicServiceCode
    resultList.add(parseData[offset++]);

    // FacilityUsage
    offset = roamFields.setFacilityUsage(parseData, offset);
    resultList.add(roamFields.getFacilityUsage());

    // InChannelAllocatedTime
    offset = roamFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(roamFields.getInChannelAllocatedTime());

    // ChargingStartTime
    offset = roamFields.setChargingStartTime(parseData, offset);
    resultList.add(roamFields.getChargingStartTime());

    // ChargingEndTime
    offset = roamFields.setChargingEndTime(parseData, offset);
    resultList.add(roamFields.getChargingEndTime());

    // CauseForTermination
    offset = roamFields.setCauseForTermination(parseData, offset);
    resultList.add(roamFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // RoamMczChrgType
    resultList.add(parseData[offset++]);

    // RoamMczDuration , Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    roamMczDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(roamMczDuration);
    offset += tempStr.length;

    // roamMczTariffClass, Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    roamMczTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(roamMczTariffClass);
    offset += tempStr.length;

    // roamMczPulses, Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    roamMczPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(roamMczPulses);
    offset += tempStr.length;

    // CalledMsrnTon
    resultList.add(parseData[offset++]);

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // IntermediateChrgeCause
    offset = roamFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(roamFields.getIntermediateChrgeCause());

    // LegCallReference
    offset = roamFields.setLegCallReference(parseData, offset);
    resultList.add(roamFields.getLegCallReference());

    // OutChannelAllocatedTime
    offset = roamFields.setOutChannelAllocatedTime(parseData, offset);
    resultList.add(roamFields.getOutChannelAllocatedTime());

    // CallReferenceTime
    offset = roamFields.setCallReferenceTime(parseData, offset);
    resultList.add(roamFields.getCallReferenceTime());

    // CamelCallReference
    offset = roamFields.setCamelCallReference(parseData, offset);
    resultList.add(roamFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = roamFields.setCamelExchangeId(parseData, offset);
    resultList.add(roamFields.getCamelExchangeId());

    // NumberOfAllInRecords
    offset = roamFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(roamFields.getNumberOfAllInRecords());

    // CugInterlock
    offset = roamFields.setCugInterlock(parseData, offset);
    resultList.add(roamFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // SelectedCodec
    resultList.add(parseData[offset++]);

    // inBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideUserPlaneIndex
    offset = roamFields.setOutsideUserPlaneIndex(parseData, offset);
    resultList.add(roamFields.getOutsideUserPlaneIndex());

    // InsideControlPlaneIndex
    offset = roamFields.setInsideControlPlaneIndex(parseData, offset);
    resultList.add(roamFields.getInsideControlPlaneIndex());

    // InsideUserPlaneIndex
    offset = roamFields.setInsideUserPlaneIndex(parseData, offset);
    resultList.add(roamFields.getInsideUserPlaneIndex());

    // OutBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideControlPlaneIndex
    offset = roamFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(roamFields.getOutsideControlPlaneIndex());

    // GlobalCallReference
    offset = roamFields.setGlobalCallReference(parseData, offset);
    resultList.add(roamFields.getGlobalCallReference());

    // OptimalRoutingIndicator
    resultList.add(parseData[offset++]);

    // NbrOfTermCapInRecs
    offset = roamFields.setNbrOfTermCapInRecs(parseData, offset);
    resultList.add(roamFields.getNbrOfTermCapInRecs());

    // NumberOfInAnnouncements
    offset = roamFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(roamFields.getNumberOfInAnnouncements());

    // RoutingCategory
    resultList.add(parseData[offset++]);

    // AddRoutingCategory
    offset = roamFields.setAddRoutingCategory(parseData, offset);
    resultList.add(roamFields.getAddRoutingCategory());

    // ScpConnection
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = roamFields.setNumberOfInRecords(parseData, offset);
    resultList.add(roamFields.getNumberOfInRecords());

    // RoamMczChangePercent
    resultList.add(parseData[offset++]);

    // RoamMczChangeDirection
    resultList.add(parseData[offset++]);

    // InCircuitGroupName
    offset = roamFields.setInCircuitGroupName(parseData, offset);
    resultList.add(roamFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = roamFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(roamFields.getOutCircuitGroupName());

    // roamMczDurationTenMs, Read 4bytes , 4 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    roamMczDurationTenMs = CommonDecoderUtils.getBcdByteRightToLeft(tempStr);
    resultList.add(roamMczDurationTenMs);
    offset += tempStr.length;

    // DialledDigitsTon
    resultList.add(parseData[offset++]);

    // DialledDigits
    offset = roamFields.setDialledDigits(parseData, offset);
    resultList.add(roamFields.getDialledDigits());

    // CtThirdPartyNumber
    offset = roamFields.setCtThirdPartyNumber(parseData, offset);
    resultList.add(roamFields.getCtThirdPartyNumber());

    // CtThirdPartyNumberTon
    resultList.add(parseData[offset++]);

    // EmlppLevel
    resultList.add(parseData[offset++]);

    // ServedNumber
    offset = roamFields.setServedNumber(parseData, offset);
    resultList.add(roamFields.getServedNumber());

    // ServedNumberTon
    resultList.add(parseData[offset++]);

    // HotBillingRecordNumber
    offset = roamFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(roamFields.getHotBillingRecordNumber());
    
    return resultList;
  } // End of parseROAM

} // End of class
