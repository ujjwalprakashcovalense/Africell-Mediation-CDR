/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the FORW record decoding.
 * 
 * @author robin.varghese
 *
 */
public class ForwRecord {

  /**
   * Method to convert the FORW record to decoded value string.
   * 
   * @param parseData  - FORW record from 3rd byte to 413 byte, total 413-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseFORW(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final String forwardingImsi;
    final String forwardingNumber;
    final String forwardedToImsi;
    final String forwardedToImei;
    final String forwardedToNumber;
    final String origCalledNumber;
    final String forwMczDuration;
    final String forwMczTariffClass;
    final String forwMczPulses;
    final String forwardedToMsrn;
    final String forwardingFirstMcc;
    final String forwardingFirstMnc;
    final String forwardingLastMcc;
    final String forwardingLastMnc;
    final String forwardedToLastMcc;
    final String forwardedToLastMnc;
    final String forwardingImeisv;
    final String forwardedToImeisv;
    final String forwardingMsrn;
    final String forwMczDurationTenMs;
    final String forwardingImei;
    final String servedNumber;
    final CommonFields forwFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = forwFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(forwFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = forwFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(forwFields.getNumberOfSsRecords());

    // CauseForForwarding
    resultList.add(parseData[offset++]);

    // ForwardingImsi , Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardingImsi = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingImsi);
    offset += tempStr.length;

    // forwardingNumber,Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    forwardingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingNumber);
    offset += tempStr.length;

    // ForwardedToImsi , Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardedToImsi = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToImsi);
    offset += tempStr.length;

    // ForwardedToImei , Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardedToImei = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToImei);
    offset += tempStr.length;

    // forwardedToNumber,Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    forwardedToNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToNumber);
    offset += tempStr.length;

    // forwardedToMsClassmark
    resultList.add(parseData[offset++]);

    // OrigCalledNumber,Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    origCalledNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(origCalledNumber);
    offset += tempStr.length;

    // InCircuitGroup
    offset = forwFields.setInCircuitGroup(parseData, offset);
    resultList.add(forwFields.getInCircuitGroup());

    // InCircuit
    offset = forwFields.setInCircuit(parseData, offset);
    resultList.add(forwFields.getInCircuit());

    // OutCircuitGroup
    offset = forwFields.setOutCircuitGroup(parseData, offset);
    resultList.add(forwFields.getOutCircuitGroup());

    // OutCircuit
    offset = forwFields.setOutCircuit(parseData, offset);
    resultList.add(forwFields.getOutCircuit());

    // basicServiceType
    resultList.add(parseData[offset++]);

    // basicServiceCode
    resultList.add(parseData[offset++]);

    // FacilityUsage
    offset = forwFields.setFacilityUsage(parseData, offset);
    resultList.add(forwFields.getFacilityUsage());

    // NonTransparencyIndicator
    resultList.add(parseData[offset++]);

    // ChannelRateIndicator
    resultList.add(parseData[offset++]);

    // InChannelAllocatedTime
    offset = forwFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(forwFields.getInChannelAllocatedTime());

    // ChargingStartTime
    offset = forwFields.setChargingStartTime(parseData, offset);
    resultList.add(forwFields.getChargingStartTime());

    // ChargingEndTime
    offset = forwFields.setChargingEndTime(parseData, offset);
    resultList.add(forwFields.getChargingEndTime());

    // CauseForTermination
    offset = forwFields.setCauseForTermination(parseData, offset);
    resultList.add(forwFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // ForwardedToNumberTon
    resultList.add(parseData[offset++]);

    // ForwMczChrgType
    resultList.add(parseData[offset++]);

    // ForwMczDuration , Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    forwMczDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(forwMczDuration);
    offset += tempStr.length;

    // ForwMczTariffClass, Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    forwMczTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(forwMczTariffClass);
    offset += tempStr.length;

    // ForwMczPulses, Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwMczPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(forwMczPulses);
    offset += tempStr.length;

    // ForwardedToMsrnTon
    resultList.add(parseData[offset++]);

    // ForwardedToMsrn,Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    forwardedToMsrn = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToMsrn);
    offset += tempStr.length;

    // ForwardingNumberTon
    resultList.add(parseData[offset++]);

    // OrigCalledNumberTon
    resultList.add(parseData[offset++]);

    // IntermediateChrgeCause
    offset = forwFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(forwFields.getIntermediateChrgeCause());

    // OrigDiallingClass
    offset = forwFields.setOrigDiallingClass(parseData, offset);
    resultList.add(forwFields.getOrigDiallingClass());

    // LegCallReference
    offset = forwFields.setLegCallReference(parseData, offset);
    resultList.add(forwFields.getLegCallReference());

    // CallReferenceTime
    offset = forwFields.setCallReferenceTime(parseData, offset);
    resultList.add(forwFields.getCallReferenceTime());

    // SpeechVersion
    resultList.add(parseData[offset++]);

    // LocRoutingNumber
    offset = forwFields.setLocRoutingNumber(parseData, offset);
    resultList.add(forwFields.getLocRoutingNumber());

    // NpdbQueryVtatus
    resultList.add(parseData[offset++]);

    // LocRoutingNumberTon
    resultList.add(parseData[offset++]);

    // CamelCallReference
    offset = forwFields.setCamelCallReference(parseData, offset);
    resultList.add(forwFields.getCamelCallReference());

    // CamelExchangeId
    offset = forwFields.setCamelExchangeId(parseData, offset);
    resultList.add(forwFields.getCamelExchangeId());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // NumberOfAllInRecords
    offset = forwFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(forwFields.getNumberOfAllInRecords());

    // CugInformation
    resultList.add(parseData[offset++]);

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInterlock
    offset = forwFields.setCugInterlock(parseData, offset);
    resultList.add(forwFields.getCugInterlock());

    // ForwardingFirstMcc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardingFirstMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingFirstMcc);
    offset += tempStr.length;

    // ForwardingFirstMnc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardingFirstMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingFirstMnc);
    offset += tempStr.length;

    // ForwardingLastMcc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardingLastMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingLastMcc);
    offset += tempStr.length;

    // ForwardingLastMnc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardingLastMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingLastMnc);
    offset += tempStr.length;

    // ForwardedToLastMcc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardedToLastMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToLastMcc);
    offset += tempStr.length;

    // forwardedToLastMnc, Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    forwardedToLastMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToLastMnc);
    offset += tempStr.length;

    // ForwardingLastExIdTon
    resultList.add(parseData[offset++]);

    // ForwardedToLastExIdTon
    resultList.add(parseData[offset++]);

    // RadioNetworkType
    resultList.add(parseData[offset++]);

    // Pni
    offset = forwFields.setPni(parseData, offset);
    resultList.add(forwFields.getPni());

    // InBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideControlPlaneIndex
    offset = forwFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(forwFields.getOutsideControlPlaneIndex());

    // OutsideUserPlaneIndex
    offset = forwFields.setOutsideUserPlaneIndex(parseData, offset);
    resultList.add(forwFields.getOutsideUserPlaneIndex());

    // OutBncConnectionType
    resultList.add(parseData[offset++]);

    // InsideControlPlaneIndex
    offset = forwFields.setInsideControlPlaneIndex(parseData, offset);
    resultList.add(forwFields.getInsideControlPlaneIndex());

    // InsideUserPlaneIndex
    offset = forwFields.setInsideUserPlaneIndex(parseData, offset);
    resultList.add(forwFields.getInsideUserPlaneIndex());

    // GlobalCallReference
    offset = forwFields.setGlobalCallReference(parseData, offset);
    resultList.add(forwFields.getGlobalCallReference());

    // HotBillingRecordNumber
    offset = forwFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(forwFields.getHotBillingRecordNumber());

    // forwardingImeisv , Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardingImeisv = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingImeisv);
    offset += tempStr.length;

    // forwardedToImeisv , Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardedToImeisv = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardedToImeisv);
    offset += tempStr.length;

    // VirtualMscIdTon
    resultList.add(parseData[offset++]);

    // VirtualMscId
    offset = forwFields.setVirtualMscId(parseData, offset);
    resultList.add(forwFields.getVirtualMscId());

    // NumberOfInAnnouncements
    offset = forwFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(forwFields.getNumberOfInAnnouncements());

    // NbrOfTermCapInRecs
    offset = forwFields.setNbrOfTermCapInRecs(parseData, offset);
    resultList.add(forwFields.getNbrOfTermCapInRecs());

    // NbrOfOrigCapInRecs
    offset = forwFields.setNbrOfOrigCapInRecs(parseData, offset);
    resultList.add(forwFields.getNbrOfOrigCapInRecs());

    // ConnectedToNumberTon
    resultList.add(parseData[offset++]);

    // ConnectedToNumber
    offset = forwFields.setConnectedToNumber(parseData, offset);
    resultList.add(forwFields.getConnectedToNumber());

    // RoutingCategory
    resultList.add(parseData[offset++]);

    // AddRoutingCategory
    offset = forwFields.setAddRoutingCategory(parseData, offset);
    resultList.add(forwFields.getAddRoutingCategory());

    // ForwardingMsrnTon
    resultList.add(parseData[offset++]);

    // forwardingMsrn , Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    forwardingMsrn = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingMsrn);
    offset += tempStr.length;

    // OptimalRoutingIndicator
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = forwFields.setNumberOfInRecords(parseData, offset);
    resultList.add(forwFields.getNumberOfInRecords());

    // ScpConnection
    resultList.add(parseData[offset++]);

    // ForwMczChangePercent
    resultList.add(parseData[offset++]);

    // ForwMczChangeDirection
    resultList.add(parseData[offset++]);

    // OutCircuitGroupName
    offset = forwFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(forwFields.getOutCircuitGroupName());

    // InCircuitGroupName
    offset = forwFields.setInCircuitGroupName(parseData, offset);
    resultList.add(forwFields.getInCircuitGroupName());

    // MsClassmark3
    resultList.add(parseData[offset++]);

    // ForwardingCellBand
    resultList.add(parseData[offset++]);

    // ForwMczDurationTenMs, Read 4bytes , 4 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    forwMczDurationTenMs = CommonDecoderUtils.getBcdByteRightToLeft(tempStr);
    resultList.add(forwMczDurationTenMs);
    offset += tempStr.length;

    // ForwardingImei, Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    forwardingImei = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(forwardingImei);
    offset += tempStr.length;

    // DialledDigitsTon
    resultList.add(parseData[offset++]);

    // DialledDigits
    offset = forwFields.setDialledDigits(parseData, offset);
    resultList.add(forwFields.getDialledDigits());

    // DirectoryNumberTon
    resultList.add(parseData[offset++]);

    // directory_number
    offset = forwFields.setDirectoryNumber(parseData, offset);
    resultList.add(forwFields.getDirectoryNumber());

    // ServedNumberTon
    resultList.add(parseData[offset++]);

    // ServedNumber, Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    servedNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(servedNumber);
    offset += tempStr.length;

    // EmlppLevel
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseFORW

} // End of class
