/*
 * Copyright (C) 2022 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ConversionProcessor {

  private DataInputStream dis = null;

  private Properties properties;
  private ConversionService conversionService = new ConversionService();
  private String inputFileExtension;
  private String inputFilePrefix;
  private final static Logger logger = LoggerFactory.getLogger(ConversionProcessor.class.getName());

  public ConversionProcessor() throws FileNotFoundException, IOException {
    //loading the properties
    properties = new Properties();
    properties.load(new FileInputStream("application.properties"));
    inputFileExtension = properties.getProperty("cdr.infile.extension");
    inputFilePrefix = properties.getProperty("cdr.infile.prefix");
  }
  
  /**
   * Method to process binary file to respective decoding format and 
   * store to specified output file.
   * 
   * @return - success/failure message.
   * @throws Exception  - Exception
   */
  public void cdrFileConverter() {

    try(Stream<File> stream = Files.list(Paths.get(properties.getProperty("cdr.input.directory")))
                              .filter(path -> new File(path.toString()).isDirectory() &&
                                  new File(path.toString()).list().length > 0) 
                              .map(Path::toFile)) {
      
      // fetching the all  list of non empty sub directories from base path 
      List<File> subDirList = stream.collect(Collectors.toList());
      
      // looping throught all sub directories 
      subDirList.forEach(subDir -> { 
        
        // filtering binary files from sub directories
        List<File> files = null;
        try(Stream<File> fStream = Files.list(Paths.get(subDir.getAbsolutePath()))
                                  .filter(path -> path.getFileName().toString().startsWith(inputFilePrefix)) 
                                  .filter(path -> path.toString().endsWith(inputFileExtension))
                                  .limit(Integer.parseInt(properties.getProperty("cdr.batchsize")))
                                  .map(Path::toFile)) {
          
          files = fStream.collect(Collectors.toList());
          
        } catch (NumberFormatException | IOException e1) {
                      logger.warn("Error occured while filtering binary files from sub directories: " 
                       +subDir.getAbsolutePath() + e1.getMessage());
        }
      

        // looping throught all input file
        files.forEach(paths -> { 
        try {
          logger.info("File has been proccessing : " + paths.getAbsolutePath());
          dis = new DataInputStream(new FileInputStream(paths.getAbsolutePath()));
          
          BufferedInputStream bf = new BufferedInputStream(dis);
          // call parseCDR with input stream
          boolean output = conversionService.parseCDR(bf, paths.getName() , subDir.getName());
          dis.close();
          bf.close();
          
          //rename file filename.dat to filename.dat.done move to archive location
          Path source = Paths.get(paths.getAbsolutePath());
          Path newDir = Paths.get(properties.getProperty("cdr.archive.location") + 
                         "/" +subDir.getName()); // i.e CdrArchive/240_2

          //create the target directories, if directory exits, no effect
          Files.createDirectories(newDir);
          if (output) { // true if its failed
            
            // input file moving to archive folder with failed
            Files.move(source, newDir.resolve(source.getFileName() + 
                properties.getProperty("cdr.archive.filename.failed.sufix")), 
                StandardCopyOption.REPLACE_EXISTING);
            
            logger.info("Cdr conversion Failed");
          } else { //success
            
            // input file moving to archive folder with done
            Files.move(source, newDir.resolve(source.getFileName() + 
                properties.getProperty("cdr.archive.filename.sufix")), 
                StandardCopyOption.REPLACE_EXISTING);
            
            logger.info("Cdr conversion completed");
          }

        } catch (Exception e) {
          logger.warn("Error occured while proccessing the file: " 
                           + paths.getName() + e.getMessage());
        }

        }); // end of forEach
        
      }); // end of forEach  
        
      //if(subDirList.isEmpty()) {
        logger.info("Waiting for input file - " + 
         properties.getProperty("cdr.wait.time") + " Milli seconds");
      //}

    } catch (Exception e) {
      throw new InternalError("Internal error while processing file" + e.getMessage());
    }
    
  } // End of CdrFileConverter

} // End of class
