/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the MOC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class MocRecord {

  /**
   * Method to convert the MOC record to decoded value string.
   * 
   * @param parseData  - MOC record from 3rd byte to 169 byte, total 169-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseMOC(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    final CommonFields mocFields = new CommonFields();
    // MOC specific field names
    final String callingSubsFirstLac;
    final String callingSubsFirstCi;
    final String callingSubsLastExId;
    final String callingSubsLastLac;
    final String callingSubsLastCi;
    final String callingSubsFirstMcc;
    final String callingSubsFirstMnc;
    final String callingSubsLastMcc;
    final String callingSubsLastMnc;
    final String inCategoryKey;
    final String callingSubsSecondMcc;
    final String callingSubsSecondMnc;

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = mocFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(mocFields.getIntermediateRecordNumber());

    // intermediateChargingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = mocFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(mocFields.getNumberOfSsRecords());

    // callingImsi
    offset = mocFields.setCallingImsi(parseData, offset);
    resultList.add(mocFields.getCallingImsi());

    // callingImei
    offset = mocFields.setCallingImei(parseData, offset);
    resultList.add(mocFields.getCallingImei());

    // callingNumber
    offset = mocFields.setCallingNumber(parseData, offset);
    resultList.add(mocFields.getCallingNumber());

    // callingCategory
    resultList.add(parseData[offset++]);

    // callingMsClassmark
    resultList.add(parseData[offset++]);

    // calledImsi
    offset = mocFields.setCalledImsi(parseData, offset);
    resultList.add(mocFields.getCalledImsi());

    // calledImei
    offset = mocFields.setCalledImei(parseData, offset);
    resultList.add(mocFields.getCalledImei());

    // calledNumberTon
    resultList.add(parseData[offset++]);

    // Called_number
    offset = mocFields.setCalledNumber(parseData, offset);
    resultList.add(mocFields.getCalledNumber());

    // calledMsClassmark
    resultList.add(parseData[offset++]);

    // dialledDigitsTon
    resultList.add(parseData[offset++]);

    // DialledDigits
    offset = mocFields.setDialledDigits(parseData, offset);
    resultList.add(mocFields.getDialledDigits());

    // callingSubsFirstLac,Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsFirstLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(callingSubsFirstLac);
    offset += tempStr.length;

    // callingSubsFirstCi,Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsFirstCi = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(callingSubsFirstCi);
    offset += tempStr.length;

    // callingSubsLastExId,Read 10bytes , 10bcd 1byte nibble swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    callingSubsLastExId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsLastExId);
    offset += tempStr.length;

    // callingSubsLastLac,Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsLastLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(callingSubsLastLac);
    offset += tempStr.length;

    // callingSubsLastCi,Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsLastCi = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(callingSubsLastCi);
    offset += tempStr.length;

    // InCircuitGroup
    offset = mocFields.setInCircuitGroup(parseData, offset);
    resultList.add(mocFields.getInCircuitGroup());

    // InCircuit
    offset = mocFields.setInCircuit(parseData, offset);
    resultList.add(mocFields.getInCircuit());

    // basicServiceType
    resultList.add(parseData[offset++]);

    // basicServiceCode
    resultList.add(parseData[offset++]);

    // FacilityUsage
    offset = mocFields.setFacilityUsage(parseData, offset);
    resultList.add(mocFields.getFacilityUsage());

    // nonTransparencyIndicator
    resultList.add(parseData[offset++]);

    // channelRateIndicator
    resultList.add(parseData[offset++]);

    // InChannelAllocatedTime
    offset = mocFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(mocFields.getInChannelAllocatedTime());

    // ChargingStartTime
    offset = mocFields.setChargingStartTime(parseData, offset);
    resultList.add(mocFields.getChargingStartTime());

    // ChargingEndTime
    offset = mocFields.setChargingEndTime(parseData, offset);
    resultList.add(mocFields.getChargingEndTime());

    // CauseForTermination
    offset = mocFields.setCauseForTermination(parseData, offset);
    resultList.add(mocFields.getCauseForTermination());

    // callType
    resultList.add(parseData[offset++]);

    // origMczChrgType
    resultList.add(parseData[offset++]);

    // OrigMczDuration
    offset = mocFields.setOrigMczDuration(parseData, offset);
    resultList.add(mocFields.getOrigMczDuration());

    // OrigMczTariffClass
    offset = mocFields.setOrigMczTariffClass(parseData, offset);
    resultList.add(mocFields.getOrigMczTariffClass());

    // OrigMczPulses
    offset = mocFields.setOrigMczPulses(parseData, offset);
    resultList.add(mocFields.getOrigMczPulses());

    // calledMsrnTon
    resultList.add(parseData[offset++]);

    // CalledMsrn
    offset = mocFields.setCalledMsrn(parseData, offset);
    resultList.add(mocFields.getCalledMsrn());

    // callingNumberTon
    resultList.add(parseData[offset++]);

    // IntermediateChrgeCause
    offset = mocFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(mocFields.getIntermediateChrgeCause());

    // CallingModifyParameters
    offset = mocFields.setCallingModifyParameters(parseData, offset);
    resultList.add(mocFields.getCallingModifyParameters());

    // origMczModifyPercent
    offset = mocFields.setOrigMczModifyPercent(parseData, offset);
    resultList.add(mocFields.getOrigMczModifyPercent());

    // origMczModifyDirection
    resultList.add(parseData[offset++]);

    // OrigDiallingClass
    offset = mocFields.setOrigDiallingClass(parseData, offset);
    resultList.add(mocFields.getOrigDiallingClass());

    // LegCallReference
    offset = mocFields.setLegCallReference(parseData, offset);
    resultList.add(mocFields.getLegCallReference());

    // CallReferenceTime
    offset = mocFields.setCallReferenceTime(parseData, offset);
    resultList.add(mocFields.getCallReferenceTime());

    // speechVersion
    resultList.add(parseData[offset++]);

    // LocRoutingNumber
    offset = mocFields.setLocRoutingNumber(parseData, offset);
    resultList.add(mocFields.getLocRoutingNumber());

    // npdbQueryStatus
    resultList.add(parseData[offset++]);

    // locRoutingNumberTon
    resultList.add(parseData[offset++]);

    // cdbIndicator
    resultList.add(parseData[offset++]);

    // CamelCallReference
    offset = mocFields.setCamelCallReference(parseData, offset);
    resultList.add(mocFields.getCamelCallReference());

    // camelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = mocFields.setCamelExchangeId(parseData, offset);
    resultList.add(mocFields.getCamelExchangeId());

    // NumberOfAllInRecords
    offset = mocFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(mocFields.getNumberOfAllInRecords());

    // cugInformation
    resultList.add(parseData[offset++]);

    // cugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInterlock
    offset = mocFields.setCugInterlock(parseData, offset);
    resultList.add(mocFields.getCugInterlock());

    // calledSubsLastExIdTon
    resultList.add(parseData[offset++]);

    // callingSubsFirstMcc,Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsFirstMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsFirstMcc);
    offset += tempStr.length;

    // callingSubsFirstMnc,Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsFirstMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsFirstMnc);
    offset += tempStr.length;

    // callingSubsLastMcc,Read 2bytes, 2 hex byte 
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsLastMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsLastMcc);
    offset += tempStr.length;

    // callingSubsLastMnc,Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsLastMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsLastMnc);
    offset += tempStr.length;

    // CalledSubsFirstMcc
    offset = mocFields.setCalledSubsFirstMcc(parseData, offset);
    resultList.add(mocFields.getCalledSubsFirstMcc());

    // CalledSubsFirstMnc
    offset = mocFields.setCalledSubsFirstMnc(parseData, offset);
    resultList.add(mocFields.getCalledSubsFirstMnc());

    // CalledSubsLastMcc
    offset = mocFields.setCalledSubsLastMcc(parseData, offset);
    resultList.add(mocFields.getCalledSubsLastMcc());

    // CalledSubsLastMnc
    offset = mocFields.setCalledSubsLastMnc(parseData, offset);
    resultList.add(mocFields.getCalledSubsLastMnc());

    // radioNetworkType
    resultList.add(parseData[offset++]);

    // selectedCodec
    resultList.add(parseData[offset++]);

    // emergencyCallCategory
    resultList.add(parseData[offset++]);

    // Pni
    offset = mocFields.setPni(parseData, offset);
    resultList.add(mocFields.getPni());

    // outBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideUserPlaneIndex
    offset = mocFields.setOutsideUserPlaneIndex(parseData, offset);
    resultList.add(mocFields.getOutsideUserPlaneIndex());

    // OutsideControlPlaneIndex
    offset = mocFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(mocFields.getOutsideControlPlaneIndex());

    // GlobalCallReference
    offset = mocFields.setGlobalCallReference(parseData, offset);
    resultList.add(mocFields.getGlobalCallReference());

    // optimalRoutingIndicator
    resultList.add(parseData[offset++]);

    // HotBillingRecordNumber
    offset = mocFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(mocFields.getHotBillingRecordNumber());

    // CalledImeisv
    offset = mocFields.setCalledImeisv(parseData, offset);
    resultList.add(mocFields.getCalledImeisv());

    // CallingImeisv
    offset = mocFields.setCallingImeisv(parseData, offset);
    resultList.add(mocFields.getCallingImeisv());

    // csArp
    resultList.add(parseData[offset++]);

    // virtualMscIdTon
    resultList.add(parseData[offset++]);

    // VirtualMscId
    offset = mocFields.setVirtualMscId(parseData, offset);
    resultList.add(mocFields.getVirtualMscId());

    // NumberOfInAnnouncements
    offset = mocFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(mocFields.getNumberOfInAnnouncements());

    // NbrOfOrigCapInRecs
    offset = mocFields.setNbrOfOrigCapInRecs(parseData, offset);
    resultList.add(mocFields.getNbrOfOrigCapInRecs());

    // redirectedIndicator
    resultList.add(parseData[offset++]);

    // connectedToNumberTon
    resultList.add(parseData[offset++]);

    // ConnectedToNumber
    offset = mocFields.setConnectedToNumber(parseData, offset);
    resultList.add(mocFields.getConnectedToNumber());

    // inCategoryKey,Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    inCategoryKey = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(inCategoryKey);
    offset += tempStr.length;

    // AddRoutingCategory
    offset = mocFields.setAddRoutingCategory(parseData, offset);
    resultList.add(mocFields.getAddRoutingCategory());

    // routingCategory
    resultList.add(parseData[offset++]);

    // regionalSubsIndicator
    resultList.add(parseData[offset++]);

    // regionalSubsLocationType
    resultList.add(parseData[offset++]);

    // callingChargingArea,Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    String callingChargingArea = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(callingChargingArea);
    offset += tempStr.length;

    // NumberOfInRecords
    offset = mocFields.setNumberOfInRecords(parseData, offset);
    resultList.add(mocFields.getNumberOfInRecords());

    // scpConnection
    resultList.add(parseData[offset++]);

    // origMczChangePercent
    resultList.add(parseData[offset++]);

    // origMczChangeDirection
    resultList.add(parseData[offset++]);

    // OutCircuitGroupName
    offset = mocFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(mocFields.getOutCircuitGroupName());

    // InCircuitGroupName
    offset = mocFields.setInCircuitGroupName(parseData, offset);
    resultList.add(mocFields.getInCircuitGroupName());

    // reqFixedNwUserRate
    resultList.add(parseData[offset++]);

    // reqOtherModemType
    resultList.add(parseData[offset++]);

    // acceptableChannelCodings
    resultList.add(parseData[offset++]);

    // reqNumberOfChannels
    resultList.add(parseData[offset++]);

    // reqAirInterfaceUserRate
    resultList.add(parseData[offset++]);

    // reqUserInitiatedModInd
    resultList.add(parseData[offset++]);

    // usedNumberOfChannels
    resultList.add(parseData[offset++]);

    // usedOtherModemType
    resultList.add(parseData[offset++]);

    // usedFixedNwUserRate
    resultList.add(parseData[offset++]);

    // usedChannelCoding
    resultList.add(parseData[offset++]);

    // callingCellBand
    resultList.add(parseData[offset++]);

    // msClassmark3
    resultList.add(parseData[offset++]);

    // OrigMczDurationTenMs
    offset = mocFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(mocFields.getOrigMczDurationTenMs());

    // outpulsedNumberTon
    resultList.add(parseData[offset++]);

    // outpulsedNumber, Read 12bytes , hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    String outpulsedNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(outpulsedNumber);
    offset += tempStr.length;

    // ctThirdPartyNumberTon
    resultList.add(parseData[offset++]);

    // CtThirdPartyNumber
    offset = mocFields.setCtThirdPartyNumber(parseData, offset);
    resultList.add(mocFields.getCtThirdPartyNumber());

    // emlppLevel
    resultList.add(parseData[offset++]);

    // OutCircuit
    offset = mocFields.setOutCircuit(parseData, offset);
    resultList.add(mocFields.getOutCircuit());

    // OutCircuitGroup
    offset = mocFields.setOutCircuitGroup(parseData, offset);
    resultList.add(mocFields.getOutCircuitGroup());

    // usedAirInterfaceUserRate
    resultList.add(parseData[offset++]);

    // callingSubsSecondMcc,Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsSecondMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsSecondMcc);
    offset += tempStr.length;

    // callingSubsSecondMnc,Read 2bytes, 2 hex byte 
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    callingSubsSecondMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingSubsSecondMnc);
    offset += tempStr.length;

    // callingSubsLastExIdTon
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseMOC

} // End of class
