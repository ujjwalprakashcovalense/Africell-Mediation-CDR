/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the HW record decoding.
 * 
 * @author robin.varghese
 *
 */
public class DocRecord {

  /**
   * Method to convert the DOC record to decoded value string.
   * 
   * @param parseData  - DOC record from 3rd byte to 216 byte, total 216-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseDOC(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final String internalUiId1;
    final String acmDuration;
    final String duration;
    final String internalUiId2;
    final String internalUiId3;
    final String internalUiId4;
    final String internalUiId5;
    final String deviceInitiatedNumber;
    final String trigCallReference;
    final String origMczChangeDirection;
    final CommonFields docFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = docFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(docFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // IntermediateChrgeCause
    offset = docFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(docFields.getIntermediateChrgeCause());

    // NumberOfSsRecords
    offset = docFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(docFields.getNumberOfSsRecords());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // CallingNumber
    offset = docFields.setCallingNumber(parseData, offset);
    resultList.add(docFields.getCallingNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = docFields.setCalledNumber(parseData, offset);
    resultList.add(docFields.getCalledNumber());

    // InChannelAllocatedTime
    offset = docFields.setDateTime(parseData, offset);
    resultList.add(docFields.getDateTime());

    // chargingStartTime
    offset = docFields.setDateTime(parseData, offset);
    resultList.add(docFields.getDateTime());

    // chargingEndTime
    offset = docFields.setDateTime(parseData, offset);
    resultList.add(docFields.getDateTime());

    // CauseForTermination
    offset = docFields.setCauseForTermination(parseData, offset);
    resultList.add(docFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // OrigMczChrgType
    resultList.add(parseData[offset++]);

    // OrigMczDuration
    offset = docFields.setOrigMczDuration(parseData, offset);
    resultList.add(docFields.getOrigMczDuration());

    // OrigMczTariffClass
    offset = docFields.setOrigMczTariffClass(parseData, offset);
    resultList.add(docFields.getOrigMczTariffClass());

    // OrigMczPulses
    offset = docFields.setOrigMczPulses(parseData, offset);
    resultList.add(docFields.getOrigMczPulses());

    // LegCallReference
    offset = docFields.setLegCallReference(parseData, offset);
    resultList.add(docFields.getLegCallReference());

    // DeviceIdentifier
    resultList.add(parseData[offset++]);

    // ServiceIdentifier
    resultList.add(parseData[offset++]);

    // CallRefernceTime
    offset = docFields.setDateTime(parseData, offset);
    resultList.add(docFields.getDateTime());

    // CamelCallReference
    offset = docFields.setCamelCallReference(parseData, offset);
    resultList.add(docFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = docFields.setCamelExchangeId(parseData, offset);
    resultList.add(docFields.getCamelExchangeId());

    // GlobalCallReference
    offset = docFields.setGlobalCallReference(parseData, offset);
    resultList.add(docFields.getGlobalCallReference());

    // InternalUiId1 , Read 6 bytes ,1 Hex Byte + 5 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 6);
    internalUiId1 = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(internalUiId1);
    offset += tempStr.length;

    // AcmDuration , Read 4 bytes, 4 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    acmDuration = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(acmDuration);
    offset += tempStr.length;

    // Duration , Read 4 bytes, 3 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    duration = CommonDecoderUtils.getBcdByteRightToLeft(tempStr);
    resultList.add(duration);
    offset += tempStr.length;

    // InternalUiId2 , Read 6 bytes ,1 Hex Byte + 5 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 6);
    internalUiId2 = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(internalUiId2);
    offset += tempStr.length;

    // InternalUiId3 , Read 6 bytes ,1 Hex Byte + 5 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 6);
    internalUiId3 = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(internalUiId3);
    offset += tempStr.length;

    // InternalUiId4 , Read 6 bytes ,1 Hex Byte + 5 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 6);
    internalUiId4 = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(internalUiId4);
    offset += tempStr.length;

    // InternalUiId5 , Read 6 bytes ,1 Hex Byte + 5 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 6);
    internalUiId5 = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(internalUiId5);
    offset += tempStr.length;

    // DeviceInitiatedNumberTon
    resultList.add(parseData[offset++]);

    // DeviceInitiatedNumber , Read 12 bytes ,1 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    deviceInitiatedNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(deviceInitiatedNumber);
    offset += tempStr.length;

    // TrigCallReferenceTime
    offset = docFields.setDateTime(parseData, offset);
    resultList.add(docFields.getDateTime());

    // TrigCallReference , Read 5 HEX bytes, word + word + byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    offset += tempStr.length;
    String[] tempValue = CommonDecoderUtils.readBytes(parseData, offset, 1);
    trigCallReference = CommonDecoderUtils.getHexByteSwap(tempStr) + tempValue[0];
    resultList.add(trigCallReference);
    offset += tempValue.length;

    // TrigLegCallReference
    offset = docFields.setReference(parseData, offset);
    resultList.add(docFields.getReference());

    // OrigMczChangePercent
    resultList.add(parseData[offset++]);

    // OrigMczChangeDirection , Read 1 bytes ,4 BCD Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    origMczChangeDirection = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(origMczChangeDirection);
    offset += tempStr.length;

    // OrigMczDurationTenMs
    offset = docFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(docFields.getOrigMczDurationTenMs());

    return resultList;
  } // End of parseDOC

} // End of class
