package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

public class STCRecord {

	/**
	 * Method to convert the STC record to decoded value string.
	 * 
	 * @param parseData  - STC record from 3rd byte to 288 byte, total 288-3 byte
	 *                   values.
	 * @param resultList - appended all field names.
	 */
	public static List<String> parseSTC(String[] parseData, List<String> resultList) {

		int offset = 0;
		String[] tempStr;
		String[] tempValue;
		final CommonFields stcFields = new CommonFields();
		final String icidOverflow;
		final String redirectingNumber;
		final String sessionTransferIcidOverflow;
		final String legalCallReference;
		final String answerTime;
		final String outInterOperatorId;
		final String outSbcDomainName;
		final String icid;
		final String outBncConnectionType;

		// decode header data
		resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
		offset += 22; // after header position

		// intermediateRecordNumber
		offset = stcFields.setIntermediateRecordNumber(parseData, offset);
		resultList.add(stcFields.getIntermediateRecordNumber());

		// CallingNumberTon
		resultList.add(parseData[offset++]);

		// calledImsi
		offset = stcFields.setCalledImsi(parseData, offset);
		resultList.add(stcFields.getCalledImsi());

		// NumberOfInRecords
		offset = stcFields.setNumberOfInRecords(parseData, offset);
		resultList.add(stcFields.getNumberOfInRecords());

		// NumberOfSsRecords
		offset = stcFields.setNumberOfSsRecords(parseData, offset);
		resultList.add(stcFields.getNumberOfSsRecords());

		// IntermediateChrgCause
		offset = stcFields.setIntermediateChrgeCause(parseData, offset);
		resultList.add(stcFields.getIntermediateChrgeCause());

		// IntermediateChrgingInd
		resultList.add(parseData[offset++]);

		// calling_number
		offset = stcFields.setCallingNumber(parseData, offset);
		resultList.add(stcFields.getCallingNumber());

		// CallingNumberTon
		resultList.add(parseData[offset++]);

		// CalledNumber
		offset = stcFields.setCalledNumber(parseData, offset);
		resultList.add(stcFields.getCalledNumber());

		// CalledCategory
		resultList.add(parseData[offset++]);

		// ChargingStartTime
		offset = stcFields.setDateTime(parseData, offset);
		resultList.add(stcFields.getDateTime());

		// InChannelAllocatedTime
		offset = stcFields.setInChannelAllocatedTime(parseData, offset);
		resultList.add(stcFields.getInChannelAllocatedTime());

		// FacilityUsage
		offset = stcFields.setFacilityUsage(parseData, offset);
		resultList.add(stcFields.getFacilityUsage());

		// RoutingCategory
		resultList.add(parseData[offset++]);

		// ChargingEndTime
		offset = stcFields.setDateTime(parseData, offset);
		resultList.add(stcFields.getDateTime());

		// CauseForTermination
		offset = stcFields.setCauseForTermination(parseData, offset);
		resultList.add(stcFields.getCauseForTermination());

		// CallType
		resultList.add(parseData[offset++]);

		// TermMCZDuration
		offset = stcFields.setTermMczDuration(parseData, offset);
		resultList.add(stcFields.getTermMczDuration());

		// TermMCZModifyDuration
		resultList.add(parseData[offset++]);

		// TermMCZModifyPercent
		offset = stcFields.setTermMczModifypercent(parseData, offset);
		resultList.add(stcFields.getTermMczModifypercent());

		// LegalCallReference
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
		offset += tempStr.length;
		tempValue = CommonDecoderUtils.readBytes(parseData, offset, 1);
		String callReferenceHex = CommonDecoderUtils.getHexByteSwap(tempStr) + tempValue[0];
		Long outputLong = Long.parseLong(callReferenceHex, 16);
		legalCallReference = String.valueOf(outputLong);
		String callReferenceUpdated = legalCallReference.substring(0, 8);
		resultList.add(callReferenceUpdated);
		offset += tempValue.length;

		// CalledModifyParameters
		offset = stcFields.setCalledModifyParameters(parseData, offset);
		resultList.add(stcFields.getCalledModifyParameters());

		// CallReferenceTime
		offset = stcFields.setCallReferenceTime(parseData, offset);
		resultList.add(stcFields.getCallReferenceTime());

		// IcidLength
		resultList.add(parseData[offset++]);

		// IcidOverflow
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
		icidOverflow = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
		resultList.add(icidOverflow);
		offset += tempStr.length;

		// Icid
		offset = stcFields.setIcid(parseData, offset);
		resultList.add(stcFields.getIcid());

		// SipSigMode
		resultList.add(parseData[offset++]);

		// AnswerTime
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
		answerTime = CommonDecoderUtils.getDateTime(tempStr);
		resultList.add(answerTime);
		offset += tempStr.length;

		// Pni
		offset = stcFields.setPni(parseData, offset);
		resultList.add(stcFields.getPni());

		// OutBncConnectionType
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
		outBncConnectionType = CommonDecoderUtils.getHexStringList(tempStr);
		resultList.add(outBncConnectionType);
		offset += tempStr.length;

		// OutSideUserPlaneIndex
		offset = stcFields.setOutsideUserPlaneIndex(parseData, offset);
		resultList.add(stcFields.getOutsideUserPlaneIndex());

		// OutsideControlPlaneIndex
		offset = stcFields.setOutsideControlPlaneIndex(parseData, offset);
		resultList.add(stcFields.getOutsideControlPlaneIndex());

		// GlobalCallReference
		offset = stcFields.setGlobalCallReference(parseData, offset);
		resultList.add(stcFields.getGlobalCallReference());

		// RedirectingNumberTon
		resultList.add(parseData[offset++]);

		// RedirectingNumber
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
		redirectingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
		resultList.add(redirectingNumber);
		offset += tempStr.length;

		// InCircuitGroup
		offset = stcFields.setInCircuitGroup(parseData, offset);
		resultList.add(stcFields.getInCircuitGroup());

		// InCircuitGroupName
		offset = stcFields.setInCircuitGroupName(parseData, offset);
		resultList.add(stcFields.getInCircuitGroupName());

		// OutCircuitGroupName
		offset = stcFields.setOutCircuitGroupName(parseData, offset);
		resultList.add(stcFields.getOutCircuitGroupName());

		// OutCircuitGroup
		offset = stcFields.setOutCircuitGroup(parseData, offset);
		resultList.add(stcFields.getOutCircuitGroup());

		// SessionTransferIcidOverflow
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
		sessionTransferIcidOverflow = CommonDecoderUtils.getHexStringList(tempStr);
		resultList.add(sessionTransferIcidOverflow);
		offset += tempStr.length;

		// AddRoutingCategory
		offset = stcFields.setAddRoutingCategory(parseData, offset);
		resultList.add(stcFields.getAddRoutingCategory());

		// TermMCZChangePercent
		resultList.add(parseData[offset++]);

		// TermMCZChangeDirection
		resultList.add(parseData[offset++]);

		// ScpConnection
		resultList.add(parseData[offset++]);

		// NumberOfAllInRecords
		offset = stcFields.setNumberOfAllInRecords(parseData, offset);
		resultList.add(stcFields.getNumberOfAllInRecords());

		// TermMCZDurationTenMS
		offset = stcFields.setTermMczDurationTenMs(parseData, offset);
		resultList.add(stcFields.getTermMczDurationTenMs());

		// Icid
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 34);
		icid = CommonDecoderUtils.getHexStringList(tempStr);
		resultList.add(icid);
		offset += tempStr.length;

		// TermMCZChrgType
		resultList.add(parseData[offset++]);

		// OrigRemoteTrunkGroupId
		offset = stcFields.setOrigRemoteTrunkGroupId(parseData, offset);
		resultList.add(stcFields.getOrigRemoteTrunkGroupId());

		// DirectoryNumber
		offset = stcFields.setDirectoryNumber(parseData, offset);
		resultList.add(stcFields.getDirectoryNumber());

		// OutInterOperatorId
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 64);
		outInterOperatorId = CommonDecoderUtils.getHexByteSwap(tempStr);
		resultList.add(outInterOperatorId);
		offset += tempStr.length;

		// OutSbcDomainName
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 64);
		outSbcDomainName = CommonDecoderUtils.getHexByteSwap(tempStr);
		resultList.add(outSbcDomainName);
		offset += tempStr.length;

		// CamelExchangeIdTon
		resultList.add(parseData[offset++]);

		// CamelExchangeId
		offset = stcFields.setCamelExchangeId(parseData, offset);
		resultList.add(stcFields.getCamelExchangeId());

		// CamelCallReference
		offset = stcFields.setCamelCallReference(parseData, offset);
		resultList.add(stcFields.getCamelCallReference());

		return resultList;

	}
}
