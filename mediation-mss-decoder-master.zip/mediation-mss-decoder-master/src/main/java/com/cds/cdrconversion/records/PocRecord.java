/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the POC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class PocRecord {

  /**
   * Method to convert the POC record to decoded value string.
   * 
   * @param parseData  - POC record from 3rd byte to 288 byte, total 288-3 byte
   *                     values.
   * @param resultList - appended all field names.
   */
  public static List<String> parsePOC(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields pocFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = pocFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(pocFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = pocFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(pocFields.getNumberOfSsRecords());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // calling_number
    offset = pocFields.setCallingNumber(parseData, offset);
    resultList.add(pocFields.getCallingNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = pocFields.setCalledNumber(parseData, offset);
    resultList.add(pocFields.getCalledNumber());

    // InCircuitGroup
    offset = pocFields.setInCircuitGroup(parseData, offset);
    resultList.add(pocFields.getInCircuitGroup());

    // InCircuit
    offset = pocFields.setInCircuit(parseData, offset);
    resultList.add(pocFields.getInCircuit());

    // InChannelAllocatedTime
    offset = pocFields.setDateTime(parseData, offset);
    resultList.add(pocFields.getDateTime());

    // ChargingStartTime
    offset = pocFields.setDateTime(parseData, offset);
    resultList.add(pocFields.getDateTime());

    // ChargingEndTime
    offset = pocFields.setDateTime(parseData, offset);
    resultList.add(pocFields.getDateTime());

    // CauseForTermination
    offset = pocFields.setCauseForTermination(parseData, offset);
    resultList.add(pocFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // TicketType
    resultList.add(parseData[offset++]);

    // IazChrgType
    resultList.add(parseData[offset++]);

    // IazDuration
    offset = pocFields.setIazDuration(parseData, offset);
    resultList.add(pocFields.getIazDuration());

    // IazTariffClass
    offset = pocFields.setIazTariffClass(parseData, offset);
    resultList.add(pocFields.getIazTariffClass());

    // IazPulses 
    offset = pocFields.setIazPulses(parseData, offset);
    resultList.add(pocFields.getIazPulses());

    // CalledMsrnTon
    resultList.add(parseData[offset++]);

    // CalledMsrn
    offset = pocFields.setCalledMsrn(parseData, offset);
    resultList.add(pocFields.getCalledMsrn());

    // IntermediateChrgeCause
    offset = pocFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(pocFields.getIntermediateChrgeCause());

    // OrigDiallingClass
    offset = pocFields.setOrigDiallingClass(parseData, offset);
    resultList.add(pocFields.getOrigDiallingClass());

    // LegCallReference
    offset = pocFields.setLegCallReference(parseData, offset);
    resultList.add(pocFields.getLegCallReference());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    // CallReferenceTime
    offset = pocFields.setDateTime(parseData, offset);
    resultList.add(pocFields.getDateTime());

    // OrigRemoteTrunkGroupId
    offset = pocFields.setOrigRemoteTrunkGroupId(parseData, offset);
    resultList.add(pocFields.getOrigRemoteTrunkGroupId());

    // LocRoutingNumber
    offset = pocFields.setLocRoutingNumber(parseData, offset);
    resultList.add(pocFields.getLocRoutingNumber());

    // NpdbQueryStatus
    resultList.add(parseData[offset++]);

    // LocRoutingNumberTon
    resultList.add(parseData[offset++]);

    // CamelCallReference
    offset = pocFields.setCamelCallReference(parseData, offset);
    resultList.add(pocFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = pocFields.setCamelExchangeId(parseData, offset);
    resultList.add(pocFields.getCamelExchangeId());

    // NumberOfAllInRecords
    offset = pocFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(pocFields.getNumberOfAllInRecords());

    // CugInterlock
    offset = pocFields.setCugInterlock(parseData, offset);
    resultList.add(pocFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // SelectedCodec
    resultList.add(parseData[offset++]);

    // inBncConnectionType
    resultList.add(parseData[offset++]);

    // InsideUserPlaneIndex
    offset = pocFields.setInsideUserPlaneIndex(parseData, offset);
    resultList.add(pocFields.getInsideUserPlaneIndex());

    // InsideControlPlaneIndex
    offset = pocFields.setInsideControlPlaneIndex(parseData, offset);
    resultList.add(pocFields.getInsideControlPlaneIndex());

    // GlobalCallReference
    offset = pocFields.setGlobalCallReference(parseData, offset);
    resultList.add(pocFields.getGlobalCallReference());

    // NumberOfInAnnouncements
    offset = pocFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(pocFields.getNumberOfInAnnouncements());

    // NbrOfOrigCapInRecs
    offset = pocFields.setNbrOfOrigCapInRecs(parseData, offset);
    resultList.add(pocFields.getNbrOfOrigCapInRecs());

    // RedirectedIndicator
    resultList.add(parseData[offset++]);

    // ScpConnection
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = pocFields.setNumberOfInRecords(parseData, offset);
    resultList.add(pocFields.getNumberOfInRecords());

    // OrigMczChangeDirection
    resultList.add(parseData[offset++]);

    // OrigMczChangePercent
    resultList.add(parseData[offset++]);

    // IazChangePercent
    resultList.add(parseData[offset++]);

    // IazChangeDirection
    resultList.add(parseData[offset++]);

    // InCircuitGroupName
    offset = pocFields.setInCircuitGroupName(parseData, offset);
    resultList.add(pocFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = pocFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(pocFields.getOutCircuitGroupName());

    // CalledImsi
    offset = pocFields.setCalledImsi(parseData, offset);
    resultList.add(pocFields.getCalledImsi());

    // OrigMczDurationTenMs
    offset = pocFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(pocFields.getOrigMczDurationTenMs());

    // OrigMczDuration
    offset = pocFields.setOrigMczDuration(parseData, offset);
    resultList.add(pocFields.getOrigMczDuration());

    // OutCircuitGroup
    offset = pocFields.setOutCircuitGroup(parseData, offset);
    resultList.add(pocFields.getOutCircuitGroup());

    // OutCircuit
    offset = pocFields.setOutCircuit(parseData, offset);
    resultList.add(pocFields.getOutCircuit());

    // OrigMczChrgType
    resultList.add(parseData[offset++]);

    // IcidOverflow
    resultList.add(parseData[offset++]);

    // IcidLength
    resultList.add(parseData[offset++]);

    // Icid
    offset = pocFields.setIcid(parseData, offset);
    resultList.add(pocFields.getIcid());

    return resultList;
  } // End of parsePOC

} // End of class
