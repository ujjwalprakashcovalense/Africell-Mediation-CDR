/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the RCC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class RccRecord {

  /**
   * Method to convert the RCC record to decoded value string.
   * 
   * @param parseData  - rcc record from 3rd byte to 232 byte, total 232-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseRCC(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields rccFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = rccFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(rccFields.getIntermediateRecordNumber());

    // CalledImei
    offset = rccFields.setCalledImei(parseData, offset);
    resultList.add(rccFields.getCalledImei());

    // CalledImeisv
    offset = rccFields.setCalledImeisv(parseData, offset);
    resultList.add(rccFields.getCalledImeisv());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // CalledImsi
    offset = rccFields.setCalledImsi(parseData, offset);
    resultList.add(rccFields.getCalledImsi());

    // NumberOfInRecords
    offset = rccFields.setNumberOfInRecords(parseData, offset);
    resultList.add(rccFields.getNumberOfInRecords());

    // NumberOfSsRecords
    offset = rccFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(rccFields.getNumberOfSsRecords());

    // IntermediateChrgeCause
    offset = rccFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(rccFields.getIntermediateChrgeCause());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = rccFields.setCalledNumber(parseData, offset);
    resultList.add(rccFields.getCalledNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CallingNumber
    offset = rccFields.setCallingNumber(parseData, offset);
    resultList.add(rccFields.getCallingNumber());

    // DialledDigitsTon
    resultList.add(parseData[offset++]);

    // DialledDigits
    offset = rccFields.setDialledDigits(parseData, offset);
    resultList.add(rccFields.getDialledDigits());

    // CalledMsrnTon
    resultList.add(parseData[offset++]);

    // CalledMsClassMark
    resultList.add(parseData[offset++]);

    // CalledMsrn
    offset = rccFields.setCalledMsrn(parseData, offset);
    resultList.add(rccFields.getCalledMsrn());

    // CallingCategory
    resultList.add(parseData[offset++]);

    // InCircuitGroup
    offset = rccFields.setInCircuitGroup(parseData, offset);
    resultList.add(rccFields.getInCircuitGroup());

    // InChannelAllocatedTime
    offset = rccFields.setDateTime(parseData, offset);
    resultList.add(rccFields.getDateTime());

    // InCircuit
    offset = rccFields.setInCircuit(parseData, offset);
    resultList.add(rccFields.getInCircuit());

    // OutCircuitGroup
    offset = rccFields.setOutCircuitGroup(parseData, offset);
    resultList.add(rccFields.getOutCircuitGroup());

    // OutCircuit
    offset = rccFields.setOutCircuit(parseData, offset);
    resultList.add(rccFields.getOutCircuit());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    // FacilityUsage
    offset = rccFields.setFacilityUsage(parseData, offset);
    resultList.add(rccFields.getFacilityUsage());

//    // chargingStartTimeTenMs
//    offset = rccFields.setChargingStartTimeTenMs(parseData, offset);
//    resultList.add(rccFields.getChargingStartTimeTenMs()); // TODO
//
//    // chargingEndTimeTenMs
//    offset = rccFields.setChargingEndTimeTenMs(parseData, offset); // TODO
//    resultList.add(rccFields.getChargingEndTimeTenMs());

    // CauseForTermination
    offset = rccFields.setCauseForTermination(parseData, offset);
    resultList.add(rccFields.getCauseForTermination());

    // OrigMczChrgType
    resultList.add(parseData[offset++]);

    // OrigMczDuration
    offset = rccFields.setOrigMczDuration(parseData, offset);
    resultList.add(rccFields.getOrigMczDuration());

    // OrigMczChangeDirection
    resultList.add(parseData[offset++]);

    // OrigMczPulses
    offset = rccFields.setOrigMczPulses(parseData, offset);
    resultList.add(rccFields.getOrigMczPulses());

    // OrigMczChangePercent
    resultList.add(parseData[offset++]);

    // LegCallReference
    offset = rccFields.setLegCallReference(parseData, offset);
    resultList.add(rccFields.getLegCallReference());

    // ScpConnection
    resultList.add(parseData[offset++]);

    // callReferenceTime
    offset = rccFields.setDateTime(parseData, offset);
    resultList.add(rccFields.getDateTime());

    // NumberOfAllInRecords
    offset = rccFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(rccFields.getNumberOfAllInRecords());

    // OrigMczDurationTenMs
    offset = rccFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(rccFields.getOrigMczDurationTenMs());

    // InBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideControlPlaneIndex
    offset = rccFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(rccFields.getOutsideControlPlaneIndex());

    // InsideUserPlaneIndex
    offset = rccFields.setInsideUserPlaneIndex(parseData, offset);
    resultList.add(rccFields.getInsideUserPlaneIndex());

    // InsideControlPlaneIndex
    offset = rccFields.setInsideControlPlaneIndex(parseData, offset);
    resultList.add(rccFields.getInsideControlPlaneIndex());

    // outBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideControlPlaneIndex
    offset = rccFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(rccFields.getOutsideControlPlaneIndex());

    // GlobalCallReference
    offset = rccFields.setGlobalCallReference(parseData, offset);
    resultList.add(rccFields.getGlobalCallReference());

    // ConnectedToNumberTon
    resultList.add(parseData[offset++]);

    // ConnectedToNumber
    offset = rccFields.setConnectedToNumber(parseData, offset);
    resultList.add(rccFields.getConnectedToNumber());

    // CugInterlock
    offset = rccFields.setCugInterlock(parseData, offset);
    resultList.add(rccFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // Pni
    offset = rccFields.setPni(parseData, offset);
    resultList.add(rccFields.getPni());

    return resultList;
  } // End of parseRCC

} // End of class
