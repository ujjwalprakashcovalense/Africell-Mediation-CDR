/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the SMMF record decoding.
 * 
 * @author robin.varghese
 *
 */
public class SmmfRecord {

  /**
   * Method to convert the SMMF record to decoded value string.
   * 
   * @param parseData  - SMMF record from 3rd byte to 169 byte, total 169-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseSMMF(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    // SMMF field names
    final String deliveryTime;
    final String forwordedToSmsc;

    CommonFields smmfFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // calledImsi
    offset = smmfFields.setCalledImsi(parseData, offset);
    resultList.add(smmfFields.getCalledImsi());

    // calledNumberTon
    resultList.add(parseData[offset++]);

    // calledImei
    offset = smmfFields.setCalledImei(parseData, offset);
    resultList.add(smmfFields.getCalledImei());

    // SmsCentre
    offset = smmfFields.setSmsCentre(parseData, offset);
    resultList.add(smmfFields.getSmsCentre());

    // CalledCategory
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = smmfFields.setCalledNumber(parseData, offset);
    resultList.add(smmfFields.getCalledNumber());

    // IncomingTime
    offset = smmfFields.setIncomingTime(parseData, offset);
    resultList.add(smmfFields.getIncomingTime());

    // ForwardedToNumber
    offset = smmfFields.setForwardedToNumber(parseData, offset);
    resultList.add(smmfFields.getForwardedToNumber());

    // ForwardedToNumberTon
    resultList.add(parseData[offset++]);

    // SmsLength
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = smmfFields.setNumberOfInRecords(parseData, offset);
    resultList.add(smmfFields.getNumberOfInRecords());

    // DeliveryTime , Read 7bytes ,5bcd bytes
    offset = smmfFields.setDateTime(parseData, offset);
    resultList.add(smmfFields.getDateTime());

    // CauseForTermination
    offset = smmfFields.setCauseForTermination(parseData, offset);
    resultList.add(smmfFields.getCauseForTermination());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // MscType
    resultList.add(parseData[offset++]);

    // CalledVmscNumber
    offset = smmfFields.setCallingVmscNumber(parseData, offset);
    resultList.add(smmfFields.getCallingVmscNumber());

    // SmsType
    resultList.add(parseData[offset++]);

    // CallingNumber
    offset = smmfFields.setCallingNumber(parseData, offset);
    resultList.add(smmfFields.getCallingNumber());

    // CallReferenceTime
    offset = smmfFields.setCallReferenceTime(parseData, offset);
    resultList.add(smmfFields.getCallReferenceTime());

    // ForwordedToSmsc , Read 12bytes ,12bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    forwordedToSmsc= CommonDecoderUtils.getBcdByteNibbleSwap(tempStr); // specially tested
    resultList.add(forwordedToSmsc);
    offset += tempStr.length;

    // ConcatenatedSmsReference
    offset = smmfFields.setConcatenatedSmsReference(parseData, offset);
    resultList.add(smmfFields.getConcatenatedSmsReference());

    // ConcatenatedRecordNumber
    resultList.add(parseData[offset++]);

    // NumOfConcatenatedSms
    resultList.add(parseData[offset++]);

    // ApplicationInfo
    resultList.add(parseData[offset++]);

    // RoutingCategory
    resultList.add(parseData[offset++]);

    // AddRoutingCategory
    offset = smmfFields.setAddRoutingCategory(parseData, offset);
    resultList.add(smmfFields.getAddRoutingCategory());

    // CalledImeisv
    offset = smmfFields.setCalledImeisv(parseData, offset);
    resultList.add(smmfFields.getCalledImeisv());

    return resultList;
  } // End of parseSMMF
} // End of class
