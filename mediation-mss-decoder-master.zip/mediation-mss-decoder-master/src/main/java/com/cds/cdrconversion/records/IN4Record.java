/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the IN4 record decoding.
 * 
 * @author robin.varghese
 *
 */
public class IN4Record {

  /**
   * Method to convert the IN4 record to decoded value string.
   * 
   * @param parseData  - IN4 record from 3rd byte to 228 byte, total 228-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseIN4(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final CommonFields inFields = new CommonFields();
    final String inData;
    final String inDataLength;

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // in_record_number, 1 bcd byte
    resultList.add(CommonDecoderUtils.getBcdByte(parseData[offset++]));
    
   // in_data ,read 160 bytes bcd
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 160);
    inData = CommonDecoderUtils.getBcdBytes(tempStr);
    resultList.add(inData);
    offset += tempStr.length;
    
    // LegCallReference
    offset = inFields.setLegCallReference(parseData, offset);
    resultList.add(inFields.getLegCallReference());
    
    // InChannelAllocatedTime
    offset = inFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(inFields.getInChannelAllocatedTime());

    // in_data_length , Read 2bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    inDataLength = String.valueOf(CommonDecoderUtils.getHexWordDecimal(tempStr));
    resultList.add(inDataLength);
    offset += tempStr.length;
    
    // CamelCallReference
    offset = inFields.setCamelCallReference(parseData, offset);
    resultList.add(inFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = inFields.setCamelExchangeId(parseData, offset);
    resultList.add(inFields.getCamelExchangeId());

    // basicCallStateModel
    resultList.add(parseData[offset++]);
   
    // party_to_charge
    resultList.add(parseData[offset++]);
    
    // protocol_identification
    resultList.add(parseData[offset++]);

    // CallReferenceTime
    offset = inFields.setCallReferenceTime(parseData, offset);
    resultList.add(inFields.getCallReferenceTime());
    
    // GlobalCallReference
    offset = inFields.setGlobalCallReference(parseData, offset);
    resultList.add(inFields.getGlobalCallReference());

    return resultList;
  } // End of parseIN4

} // End of class
