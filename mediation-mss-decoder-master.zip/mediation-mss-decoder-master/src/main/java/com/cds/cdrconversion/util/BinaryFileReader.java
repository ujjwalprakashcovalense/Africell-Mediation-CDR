package com.cds.cdrconversion.util;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * The class wil read values from inputstream object with given offset and
 * length.
 * 
 * 
 */
public class BinaryFileReader {

  /**
   * method will read values with given offset and length
   * 
   * @param bif
   * 
   * @return - hex values of specified amount of bytes in a string.
   * @throws IOException
   */
  public String[] bytesReader(int length, BufferedInputStream bif) throws IOException {

    final byte byteArray[] = new byte[length];
    final String[] arrayList = new String[length];

    try {

      bif.read(byteArray, 0, length);
      //bif.mark(0);

      // converting decimal byte[] inputstream to hex value
      for (int i = 0; i < byteArray.length; i++) {
        arrayList[i] = String.format("%02X", byteArray[i]);
      }
      // log.info("Read record byte[] : " + Arrays.toString(byteArray));
      // log.info("Read record String[] Hex conv : " + Arrays.toString(arrayList));
    } catch (IOException e) {
      throw new IOException("Exception occured while reading the file" + e.getMessage());
    }
    return arrayList;
  } // End of bytesReader
} // End of class
