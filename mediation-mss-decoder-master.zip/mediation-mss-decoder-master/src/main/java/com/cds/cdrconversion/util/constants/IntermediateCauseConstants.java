package com.cds.cdrconversion.util.constants;
/**
 * The  class provides all the constants used by getIntermediateCause.
 */
public class IntermediateCauseConstants {

  public static final String BIT_1  = "Value at the end of the cal";
  public static final String BIT_2  = "|Intermediate charging because time limit has been reached";
  public static final String BIT_3  = "|Intermediate charging because pulse limit has been reached";
  public static final String BIT_4  = "|The change of the used data rate in user plane";
  public static final String BIT_5  = "|Call re-establishment";
  public static final String BIT_6  = "|Chargeable IN user interaction ended and charging has ended.";
  public static final String BIT_7  = "|Handover has changed the channel-related parameters";
  public static final String BIT_8  = "|Handover has changed the band of air interface (Not used)";
  public static final String BIT_9  = "|Tariff change";
  public static final String BIT_10 = "|SCP originating the charging change by means of the SCI information";
  public static final String BIT_11 = "|Inter-MSS handover";
  public static final String BIT_12 = "|Follow-on call";
  public static final String BIT_13 = "|Changing of localised service identity";
  public static final String BIT_14 = "|Call drop back";
  public static final String BIT_15 = "|Inter-PLMN handover";
  public static final String BIT_16 = "|Inter-system handover";
  public static final String BIT_17 = "|Disconnect leg A";
  public static final String BIT_18 = "|Disconnect leg B";
  public static final String BIT_19 = "|End of Camel user interaction";
  public static final String BIT_20 = "|Call type of SIP (speech/multimedia) or addition/removal of media component";
  public static final String BIT_21 = "|Codec change*";
  public static final String BIT_22 = "|Explicit call transfer";
  public static final String BIT_23 = "|Through connection cut by SCP";
  public static final String BIT_24 = "|Subsequent FCI received";
  public static final String BIT_25 = "|Change in SIP access information/Terminal IP";
  public static final String BIT_26 = "|Directory Assistance Service (DACC); in connection withFeature 1928: Release Link Trunk (RLT) message supportin ISUP for 411 Directory calls";
  public static final String BIT_27 = "|Intra-system relocation between different radio network elements is made (legacy RNC <-> I-BTS)";
  public static final String BIT_28 = "|(SIP) Session Transfer to a different domain";

 private IntermediateCauseConstants()
 {
   
 }
}
