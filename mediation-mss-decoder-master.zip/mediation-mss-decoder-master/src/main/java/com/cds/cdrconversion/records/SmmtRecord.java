/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the SMMT record decoding.
 * 
 * @author robin.varghese
 *
 */
public class SmmtRecord {

  /**
   * Method to convert the SMMT record to decoded value string.
   * 
   * @param parseData  - SMMT record from 3rd byte to 155 byte, total 155-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseSMMT(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    // SMMT field names
    final String callingNumber;

    CommonFields smmtField = new CommonFields();
    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // CalledImsi
    offset = smmtField.setCalledImsi(parseData, offset);
    resultList.add(smmtField.getCalledImsi());

    // CalledImei
    offset = smmtField.setCalledImei(parseData, offset);
    resultList.add(smmtField.getCalledImei());

    // CalledNumber
    offset = smmtField.setCalledNumber(parseData, offset);
    resultList.add(smmtField.getCalledNumber());

    // calledCategory
    resultList.add(parseData[offset++]);

    // calledMsClassmark =
    resultList.add(parseData[offset++]);

    // ServedSubsLac
    offset = smmtField.setServedSubsLac(parseData, offset);
    resultList.add(smmtField.getServedSubsLac());

    // ServedSubsCi
    offset = smmtField.setServedSubsCi(parseData, offset);
    resultList.add(smmtField.getServedSubsCi());

    // SmsCentre
    offset = smmtField.setSmsCentre(parseData, offset);
    resultList.add(smmtField.getSmsCentre());

    // IncomingTime
    offset = smmtField.setIncomingTime(parseData, offset);
    resultList.add(smmtField.getIncomingTime());

    // CauseForTermination
    offset = smmtField.setCauseForTermination(parseData, offset);
    resultList.add(smmtField.getCauseForTermination());

    // mscType
    resultList.add(parseData[offset++]);

    // callingNumber Read 11 bytes , 10 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 11);
    callingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingNumber);
    offset += tempStr.length;

    // CallingVmscNumber
    offset = smmtField.setCallingVmscNumber(parseData, offset);
    resultList.add(smmtField.getCallingVmscNumber());

    // callingNumberTon
    resultList.add(parseData[offset++]);

    // calledNumberTon
    resultList.add(parseData[offset++]);

    // smsType
    resultList.add(parseData[offset++]);

    // CallReferenceTime
    offset = smmtField.setCallReferenceTime(parseData, offset);
    resultList.add(smmtField.getCallReferenceTime());

    // ServedSubsMcc
    offset = smmtField.setServedSubsMcc(parseData, offset);
    resultList.add(smmtField.getServedSubsMcc());

    // ServedSubsMnc
    offset = smmtField.setServedSubsMnc(parseData, offset);
    resultList.add(smmtField.getServedSubsMnc());

    // radioNetworkType
    resultList.add(parseData[offset++]);

    // HotBillingRecordNumber
    offset = smmtField.setHotBillingRecordNumber(parseData, offset);
    resultList.add(smmtField.getHotBillingRecordNumber());

    // CalledImeisv
    offset = smmtField.setCalledImeisv(parseData, offset);
    resultList.add(smmtField.getCalledImeisv());

    // routingCategory
    resultList.add(parseData[offset++]);

    // AddRoutingCategory
    offset = smmtField.setAddRoutingCategory(parseData, offset);
    resultList.add(smmtField.getAddRoutingCategory());

    // CallingVmscNumber
    offset = smmtField.setCallingVmscNumber(parseData, offset);
    resultList.add(smmtField.getCallingVmscNumber());

    // TariffClass
    offset = smmtField.setTariffClass(parseData, offset);
    resultList.add(smmtField.getTariffClass());

    // smsLength
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = smmtField.setNumberOfInRecords(parseData, offset);
    resultList.add(smmtField.getNumberOfInRecords());

    // ueTimeZone
    resultList.add(parseData[offset++]);

    // numOfConcatenatedSms
    resultList.add(parseData[offset++]);

    // concatenatedRecordNumber =
    resultList.add(parseData[offset++]);

    // ConcatenatedSmsReference
    offset = smmtField.setConcatenatedSmsReference(parseData, offset);
    resultList.add(smmtField.getConcatenatedSmsReference());

    // applicationInfo
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseSMTT
} // End of class
