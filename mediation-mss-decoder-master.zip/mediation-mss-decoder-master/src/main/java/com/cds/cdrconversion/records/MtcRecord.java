/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the MTC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class MtcRecord {

  /**
   * Method to convert the MTC record to decoded value string.
   * 
   * @param parseData  - MTC record from 3rd byte to 372 byte, total 372-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseMTC(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    final CommonFields mtcFields = new CommonFields();
    // MTC specific field names
    final String calledSubsFirstLac;
    final String calledSubsFirstCi;
    final String calledSubsLastLac;
    final String calledSubsLastCi;
    final String termMczTariffClass;
    final String termMczPulses;
    final String calledSubsSecondMcc;
    final String calledSubsSecondMnc;
    final String pic;
    
    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = mtcFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(mtcFields.getIntermediateRecordNumber());

    // intermediateChargingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = mtcFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(mtcFields.getNumberOfSsRecords());

    // CallingNumber
    offset = mtcFields.setCallingNumber(parseData, offset);
    resultList.add(mtcFields.getCallingNumber());

    // CalledImsi
    offset = mtcFields.setCalledImsi(parseData, offset);
    resultList.add(mtcFields.getCalledImsi());

    // CalledImei
    offset = mtcFields.setCalledImei(parseData, offset);
    resultList.add(mtcFields.getCalledImei());

    // calledNumber
    offset = mtcFields.setCalledNumber(parseData, offset);
    resultList.add(mtcFields.getCalledNumber());

    // calledCategory
    resultList.add(parseData[offset++]);

    // calledMsClassmark
    resultList.add(parseData[offset++]);

    // outCircuitGroup
    offset = mtcFields.setOutCircuitGroup(parseData, offset);
    resultList.add(mtcFields.getOutCircuitGroup());

    // outCircuit
    offset = mtcFields.setOutCircuit(parseData, offset);
    resultList.add(mtcFields.getOutCircuit());

    // Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsFirstLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(calledSubsFirstLac);
    offset += tempStr.length;

    // Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsFirstCi = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(calledSubsFirstCi);
    offset += tempStr.length;

    // CalledSubsLastExId
    offset = mtcFields.setCalledSubsLastExId(parseData, offset);
    resultList.add(mtcFields.getCalledSubsLastExId());

    // calledSubsLastLac
    // Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsLastLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(calledSubsLastLac);
    offset += tempStr.length;

    // calledSubsLastCi
    // Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsLastCi = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(calledSubsLastCi);
    offset += tempStr.length;

    // basicServiceType
    resultList.add(parseData[offset++]);

    // basicServiceCode
    resultList.add(parseData[offset++]);

    // facilityUsage
    offset = mtcFields.setFacilityUsage(parseData, offset); 
    resultList.add(mtcFields.getFacilityUsage());

    // nonTransparencyIndicator
    resultList.add(parseData[offset++]);

    // channelRateIndicator
    resultList.add(parseData[offset++]);

    // chargingStartTime
    offset = mtcFields.setChargingStartTime(parseData, offset);
    resultList.add(mtcFields.getChargingStartTime());

    // chargingEndTime
    offset = mtcFields.setChargingEndTime(parseData, offset);
    resultList.add(mtcFields.getChargingEndTime());

    // causeForTermination
    offset = mtcFields.setCauseForTermination(parseData, offset);
    resultList.add(mtcFields.getCauseForTermination());

    // callType
    resultList.add(parseData[offset++]);

    // termMczChrgType
    resultList.add(parseData[offset++]);

    // causeForTermination
    offset = mtcFields.setTermMczDuration(parseData, offset);
    resultList.add(mtcFields.getTermMczDuration());

    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    termMczTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(termMczTariffClass);
    offset += tempStr.length;

    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    termMczPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(termMczPulses);
    offset += tempStr.length;

    // callingNumberTon
    resultList.add(parseData[offset++]);

    // calledNumberTon
    resultList.add(parseData[offset++]);

    // intermediateChrgeCause
    offset = mtcFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(mtcFields.getIntermediateChrgeCause());

    // calledModifyParameters
    offset = mtcFields.setCalledModifyParameters(parseData, offset);
    resultList.add(mtcFields.getCalledModifyParameters());

    // termMczModifypercent
    offset = mtcFields.setTermMczModifypercent(parseData, offset);
    resultList.add(mtcFields.getTermMczModifypercent());

    // termMczModifyDirection
    resultList.add(parseData[offset++]);

    // legCallReference
    offset = mtcFields.setLegCallReference(parseData, offset);
    resultList.add(mtcFields.getLegCallReference());

    // outChannelAllocatedTime
    offset = mtcFields.setOutChannelAllocatedTime(parseData, offset);
    resultList.add(mtcFields.getOutChannelAllocatedTime());

    // callReferenceTime
    offset = mtcFields.setCallReferenceTime(parseData, offset);
    resultList.add(mtcFields.getCallReferenceTime());

    // speechVersion
    resultList.add(parseData[offset++]);

    // locRoutingNumber
    offset = mtcFields.setLocRoutingNumber(parseData, offset);
    resultList.add(mtcFields.getLocRoutingNumber());

    // locRoutingNumberTon
    resultList.add(parseData[offset++]);

    // cdbIndicator
    resultList.add(parseData[offset++]);

    // camelExchangeId
    offset = mtcFields.setCamelExchangeId(parseData, offset);
    resultList.add(mtcFields.getCamelExchangeId());

    // camelCallReference
    offset = mtcFields.setCamelCallReference(parseData, offset);
    resultList.add(mtcFields.getCamelCallReference());

    // camelExchangeIdTon
    resultList.add(parseData[offset++]);

    // numberOfAllInRecords
    offset = mtcFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(mtcFields.getNumberOfAllInRecords());

    // cugInterlock
    offset = mtcFields.setCugInterlock(parseData, offset);
    resultList.add(mtcFields.getCugInterlock());

    // cugOutgoingAccess
    resultList.add(parseData[offset++]);

    // cugInformation
    resultList.add(parseData[offset++]);

    // calledSubsLastExIdTon
    resultList.add(parseData[offset++]);

    // CalledSubsFirstMcc
    offset = mtcFields.setCalledSubsFirstMcc(parseData, offset);
    resultList.add(mtcFields.getCalledSubsFirstMcc());

    // CalledSubsFirstMnc
    offset = mtcFields.setCalledSubsFirstMnc(parseData, offset);
    resultList.add(mtcFields.getCalledSubsFirstMnc());

    // CalledSubsLastMcc
    offset = mtcFields.setCalledSubsLastMcc(parseData, offset);
    resultList.add(mtcFields.getCalledSubsLastMcc());

    // CalledSubsLastMnc
    offset = mtcFields.setCalledSubsLastMnc(parseData, offset);
    resultList.add(mtcFields.getCalledSubsLastMnc());

    // radioNetworkType
    resultList.add(parseData[offset++]);
    
    // calledSubsSecondMcc, Read 2bytes , 1hex 
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsSecondMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(calledSubsSecondMcc);
    offset += tempStr.length;

    // calledSubsSecondMnc Read 2bytes , 1hex 
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    calledSubsSecondMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(calledSubsSecondMnc);
    offset += tempStr.length;

    // selectedCodec
    resultList.add(parseData[offset++]);

    // pni
    offset = mtcFields.setPni(parseData, offset);
    resultList.add(mtcFields.getPni());

    // inBncConnectionType
    resultList.add(parseData[offset++]);

    // insideControlPlaneIndex
    offset = mtcFields.setInsideControlPlaneIndex(parseData, offset);
    resultList.add(mtcFields.getInsideControlPlaneIndex());

    // insideUserPlaneIndex
    offset = mtcFields.setInsideUserPlaneIndex(parseData, offset);
    resultList.add(mtcFields.getInsideUserPlaneIndex());

    // GlobalCallReference
    offset = mtcFields.setGlobalCallReference(parseData, offset);
    resultList.add(mtcFields.getGlobalCallReference());

    // callingPstnCategory
    resultList.add(parseData[offset++]);

    // optimalRoutingIndicator
    resultList.add(parseData[offset++]);

    // hotBillingRecordNumber
    offset = mtcFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(mtcFields.getHotBillingRecordNumber());

    // CalledImeisv
    offset = mtcFields.setCalledImeisv(parseData, offset);
    resultList.add(mtcFields.getCalledImeisv());

    // csArp
    resultList.add(parseData[offset++]);

    // virtualMscId
    offset = mtcFields.setVirtualMscId(parseData, offset);
    resultList.add(mtcFields.getVirtualMscId());

    // virtualMscIdTon
    resultList.add(parseData[offset++]);

    // numberOfInAnnouncements
    offset = mtcFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(mtcFields.getNumberOfInAnnouncements());

    // nbrOfTermCapInRecs
    offset = mtcFields.setNbrOfTermCapInRecs(parseData, offset);
    resultList.add(mtcFields.getNbrOfTermCapInRecs());

    // routingCategory
    resultList.add(parseData[offset++]);

    // addRoutingCategory
    offset = mtcFields.setAddRoutingCategory(parseData, offset);
    resultList.add(mtcFields.getAddRoutingCategory());

    // scpConnection
    resultList.add(parseData[offset++]);

    // numberOfInRecords
    offset = mtcFields.setNumberOfInRecords(parseData, offset);
    resultList.add(mtcFields.getNumberOfInRecords());

    // termMczChangePercent
    resultList.add(parseData[offset++]);

    // termMczChangeDirection
    resultList.add(parseData[offset++]);

    // InCircuitGroupName
    offset = mtcFields.setInCircuitGroupName(parseData, offset);
    resultList.add(mtcFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = mtcFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(mtcFields.getOutCircuitGroupName());

    // reqFixedNwUserRate
    resultList.add(parseData[offset++]);

    // reqOtherModemType
    resultList.add(parseData[offset++]);

    // acceptableChannelCodings
    resultList.add(parseData[offset++]);

    // reqNumberOfChannels
    resultList.add(parseData[offset++]);

    // reqAirInterfaceUserRate
    resultList.add(parseData[offset++]);

    // reqUserInitiatedModInd
    resultList.add(parseData[offset++]);

    // usedNumberOfChannels
    resultList.add(parseData[offset++]);

    //usedOtherModemType
    resultList.add(parseData[offset++]);
    
    //usedFixedNwUserRate
    resultList.add(parseData[offset++]);
    
    //usedChannelCoding
    resultList.add(parseData[offset++]);
    
    //msClassmark3
    resultList.add(parseData[offset++]);
    
    // calledCellBand
    resultList.add(parseData[offset++]);

    // TermMczDurationTenMs
    offset = mtcFields.setTermMczDurationTenMs(parseData, offset);
    resultList.add(mtcFields.getTermMczDurationTenMs());

    // dialledDigitsTon 
    resultList.add(parseData[offset++]);

    // pic, Read 2bytes, 2 hex byte 
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    pic = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(pic); offset+= tempStr.length;
     
    // DialledDigits
    offset = mtcFields.setDialledDigits(parseData, offset);
    resultList.add(mtcFields.getDialledDigits());
    
    // inCircuitGroup
    offset = mtcFields.setInCircuitGroup(parseData, offset);
    resultList.add(mtcFields.getInCircuitGroup());
    
    // inCircuit
    offset = mtcFields.setInCircuit(parseData, offset);
    resultList.add(mtcFields.getInCircuit()); 
    
    // CtThirdPartyNumber  
    offset = mtcFields.setCtThirdPartyNumber(parseData, offset);
    resultList.add(mtcFields.getCtThirdPartyNumber());
    
    // ctThirdPartyNumberTon 
    resultList.add(parseData[offset++]);

    // emlppLevel 
    resultList.add(parseData[offset++]);

    // usedAirInterfaceUserRate 
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseMTC
  
  
} // End of class
