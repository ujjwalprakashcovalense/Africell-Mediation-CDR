/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the SUSP record decoding.
 * 
 * @author robin.varghese
 *
 */
public class SuspRecord {

  /**
   * Method to convert the SUSP record to decoded value string.
   * 
   * @param parseData  - SUSP record from 3rd byte to 184 byte, total 184-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseSUSP(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final CommonFields suspFields = new CommonFields();
    final String ssRecordNumber;
    final String servedSubsCi;
    final String resultIndicator;
    final String parameters;

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // Read 1bytes, 1bcd byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    ssRecordNumber = CommonDecoderUtils.getBcdByte(tempStr[0]);
    resultList.add(ssRecordNumber);
    offset += tempStr.length;

    // served_imsi
    offset = suspFields.setServedImsi(parseData, offset);
    resultList.add(suspFields.getServedImsi());

    // served_imei
    offset = suspFields.setServedImei(parseData, offset);
    resultList.add(suspFields.getServedImei());

    // served_number
    offset = suspFields.setServedNumber(parseData, offset);
    resultList.add(suspFields.getServedNumber());

    // ServedSubsLac
    offset = suspFields.setServedSubsLac(parseData, offset);
    resultList.add(suspFields.getServedSubsLac());

    // ServedSubsCi Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    servedSubsCi = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(servedSubsCi);
    offset += tempStr.length;

    // supplementary_service_code
    resultList.add(parseData[offset++]);

    // action
    resultList.add(parseData[offset++]);

    // charging_time
    offset = suspFields.setChargingStartTime(parseData, offset);
    resultList.add(suspFields.getChargingStartTime());

    // cause_for_termination
    offset = suspFields.setCauseForTermination(parseData, offset);
    resultList.add(suspFields.getCauseForTermination());

    // result_indicator, Read 2bytes - 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    resultIndicator = CommonDecoderUtils.getHexByteSwap(tempStr);
    offset += tempStr.length;
    resultList.add(resultIndicator);

    // parameters_length
    resultList.add(parseData[offset++]);

    // parameters, Read 30bytes - 30 hexbytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 30); 
    parameters = CommonDecoderUtils.getHexStringList(tempStr);
    offset += tempStr.length;
    resultList.add(parameters);

    // served_number_ton
    resultList.add(parseData[offset++]);
    // served_ms_classmark
    resultList.add(parseData[offset++]);
    // basic_service_type
    resultList.add(parseData[offset++]);
    // basic_service_code
    resultList.add(parseData[offset++]);

    // LegCallReference
    offset = suspFields.setLegCallReference(parseData, offset);
    resultList.add(suspFields.getLegCallReference());

    // CallReferenceTime
    offset = suspFields.setCallReferenceTime(parseData, offset);
    resultList.add(suspFields.getCallReferenceTime());

    // CamelCallReference
    offset = suspFields.setCamelCallReference(parseData, offset);
    resultList.add(suspFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = suspFields.setCamelExchangeId(parseData, offset);
    resultList.add(suspFields.getCamelExchangeId());

    // basicCallStateModel
    resultList.add(parseData[offset++]);

    // ServedSubsMcc
    offset = suspFields.setServedSubsMcc(parseData, offset);
    resultList.add(suspFields.getServedSubsMcc());

    // ServedSubsMnc
    offset = suspFields.setServedSubsMnc(parseData, offset);
    resultList.add(suspFields.getServedSubsMnc());

    // radioNetworkType
    resultList.add(parseData[offset++]);

    // Pni
    offset = suspFields.setPni(parseData, offset);
    resultList.add(suspFields.getPni());

    // GlobalCallReference
    offset = suspFields.setGlobalCallReference(parseData, offset);
    resultList.add(suspFields.getGlobalCallReference());

    // HotBillingRecordNumber
    offset = suspFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(suspFields.getHotBillingRecordNumber());

    // served_imeisv
    offset = suspFields.setServedImeisv(parseData, offset);
    resultList.add(suspFields.getServedImeisv());

    // routing_category
    resultList.add(parseData[offset++]);

    // served_cell_band
    resultList.add(parseData[offset++]);
    
    // AddRoutingCategory 
    offset = suspFields.setAddRoutingCategory(parseData, offset);
    resultList.add(suspFields.getAddRoutingCategory());
    
    // ms_classmark3
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseCOC

} // End of class
