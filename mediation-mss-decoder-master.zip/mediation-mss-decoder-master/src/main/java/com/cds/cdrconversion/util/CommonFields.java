package com.cds.cdrconversion.util;

import lombok.Getter;

/**
 * This class will create common fields decoding for all record types.
 * 
 * @author robin.varghese
 *
 */
@Getter
public class CommonFields extends CommonField {

  String[] tempStr;

  private String callingImsi;
  private String callingImei;
  private String callingNumber;
  private String origMczModifyPercent;
  private String intermediateRecordNumber;
  private String numberOfSsRecords;
  private String calledImsi;
  private String calledImei;
  private String calledNumber;
  private String outCircuitGroup;
  private String outCircuit;
  private String calledSubsLastExId;
  private String facilityUsage;
  private String chargingStartTime;
  private String chargingEndTime;
  private String causeForTermination;
  private String termMczDuration;
  private String intermediateChrgeCause;
  private String calledModifyParameters;
  private String termMczModifypercent;
  private String legCallReference;
  private String outChannelAllocatedTime;
  private String callReferenceTime;
  private String locRoutingNumber;
  private String camelExchangeId;
  private String camelCallReference;
  private String numberOfAllInRecords;
  private String cugInterlock;
  private String calledSubsFirstMcc;
  private String calledSubsFirstMnc;
  private String calledSubsLastMcc;
  private String calledSubsLastMnc;
  private String pni;
  private String insideControlPlaneIndex;
  private String insideUserPlaneIndex;
  private String globalCallReference;
  private String hotBillingRecordNumber;
  private String calledImeisv;
  private String virtualMscId;
  private String numberOfInAnnouncements;
  private String nbrOfTermCapInRecs;
  private String addRoutingCategory;
  private String numberOfInRecords;
  private String inCircuitGroupName;
  private String outCircuitGroupName;
  private String termMczDurationTenMs;
  private String dialledDigits;
  private String inCircuitGroup;
  private String inCircuit;
  private String ctThirdPartyNumber;
  private String inChannelAllocatedTime;
  private String origMczDuration;
  private String origMczTariffClass;
  private String origMczPulses;
  private String calledMsrn;
  private String callingModifyParameters;
  private String origDiallingClass;
  private String outsideControlPlaneIndex;
  private String callingImeisv;
  private String nbrOfOrigCapInRecs;
  private String connectedToNumber;
  private String origMczDurationTenMs;
  private String outsideUserPlaneIndex;

  /**
   * method will decode the calling imsi value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingImsi(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.callingImsi = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of setCallingImsi

  /**
   * method will decode the callingImei value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingImei(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.callingImei = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  }

  /**
   * method will decode the callingNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingNumber(String[] parseData, int offset) {
    // Read 12bytes ,NUMBER
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.callingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  }

  /**
   * method will decode the origMczModifyPercent value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigMczModifyPercent(String[] parseData, int offset) {
    // Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.origMczModifyPercent = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of origMczModifyPercent

  /**
   * method will decode the intermediateRecordNumber value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIntermediateRecordNumber(String[] parseData, int offset) {
    // Read 1bytes , 1bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.intermediateRecordNumber = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of intermediateRecordNumber

  /**
   * method will decode the numberOfSsRecords value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNumberOfSsRecords(String[] parseData, int offset) {
    // Read 1bytes , 1bcd byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.numberOfSsRecords = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of numberOfSsRecords

  /**
   * method will decode the CalledImsi value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledImsi(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.calledImsi = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of CalledImsi

  /**
   * method will decode the CalledImei value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledImei(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.calledImei = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of CalledImei

  /**
   * method will decode the calledNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledNumber(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.calledNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledNumber

  /**
   * method will decode the outCircuitGroup value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutCircuitGroup(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.outCircuitGroup = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of outCircuitGroup

  /**
   * method will decode the outCircuitGroup value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutCircuit(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.outCircuit = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of outCircuit

  /**
   * method will decode the calledSubsLastExId value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledSubsLastExId(String[] parseData, int offset) {
    // Read 10bytes , 10bcd 1byte nibble swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    this.calledSubsLastExId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledSubsLastExId

  /**
   * method will decode the facilityUsage value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setFacilityUsage(String[] parseData, int offset) {
    // Read 5bytes , 1hexdword ignore 1byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 5);
    facilityUsage = CommonDecoderUtils.getFacilityUsage(tempStr);
    return offset += tempStr.length;
  } // End of facilityUsage

  /**
   * method will decode the chargingStartTime value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setChargingStartTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.chargingStartTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // End of chargingStartTime

  /**
   * method will decode the chargingEndTime value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setChargingEndTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.chargingEndTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // End of chargingStartTime

  /**
   * method will decode the causeForTermination value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCauseForTermination(String[] parseData, int offset) {
    // Read 4bytes , 1hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.causeForTermination = CommonDecoderUtils.getHexByteRightToLeft(tempStr);
    return offset += tempStr.length;
  } // End of causeForTermination

  /**
   * method will decode the termMczDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setTermMczDuration(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.termMczDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of termMczDuration

  /**
   * method will decode the termMczDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIntermediateChrgeCause(String[] parseData, int offset) {
    // Read 4bytes , 1hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.intermediateChrgeCause = CommonDecoderUtils.getIntermediateChrgeCause(tempStr);
    return offset += tempStr.length;
  } // End of intermediateChrgeCause

  /**
   * method will decode the termMczDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledModifyParameters(String[] parseData, int offset) {
    // Read 14bytes , 7hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 14);
    this.calledModifyParameters = CommonDecoderUtils.getHexStringList(tempStr);
    return offset += tempStr.length;
  } // End of CalledModifyParameters

  /**
   * method will decode the TermMczModifypercent value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setTermMczModifypercent(String[] parseData, int offset) {
    // Read 2bytes , 1hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.termMczModifypercent = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of TermMczModifypercent

  /**
   * method will decode the legCallReference value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setLegCallReference(String[] parseData, int offset) {
    // Read 4bytes , word+word+byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    offset += tempStr.length;
    String[] tempValue = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.legCallReference = CommonDecoderUtils.getHexByteSwap(tempStr) + tempValue[0];
    return offset += tempValue.length;
  } // End of legCallReference

  /**
   * method will decode the outChannelAllocatedTime value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutChannelAllocatedTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.outChannelAllocatedTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // End of outChannelAllocatedTime

  /**
   * method will decode the callReferenceTime value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallReferenceTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.callReferenceTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // End of callReferenceTime

  /**
   * method will decode the locRoutingNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setLocRoutingNumber(String[] parseData, int offset) {
    // Read 12bytes ,1 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.locRoutingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of locRoutingNumber

  /**
   * method will decode the camelExchangeIdr value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCamelExchangeId(String[] parseData, int offset) {
    // Read 9bytes, 9 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 9);
    this.camelExchangeId = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of camelExchangeId

  /**
   * method will decode the CamelCallReference value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCamelCallReference(String[] parseData, int offset) {
    // Read 8bytes, 1 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.camelCallReference = CommonDecoderUtils.getHexStringList(tempStr);
    return offset += tempStr.length;
  } // End of CamelCallReference

  /**
   * method will decode the numberOfAllInRecords value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNumberOfAllInRecords(String[] parseData, int offset) {
    // Read 1bytes , 1bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.numberOfAllInRecords = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of numberOfAllInRecords

  /**
   * method will decode the cugInterlock value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCugInterlock(String[] parseData, int offset) {
    // Read 4bytes,2 bytes BCD + 1 HEX word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    String snetworkCode = "network code:" + CommonDecoderUtils.getBcdBytes(tempStr);
    offset += tempStr.length;
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.cugInterlock = snetworkCode + "|" + "cug interlock:"
                        + CommonDecoderUtils.getHexWordDecimal(tempStr);
    return offset += tempStr.length;
  } // End of cugInterlock

  /**
   * method will decode the CalledSubsFirstMcc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledSubsFirstMcc(String[] parseData, int offset) {
    // Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.calledSubsFirstMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledSubsFirstMcc

  /**
   * method will decode the CalledSubsFirstMnc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledSubsFirstMnc(String[] parseData, int offset) {
    // Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.calledSubsFirstMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledSubsFirstMnc

  /**
   * method will decode the CalledSubsLastMcc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledSubsLastMcc(String[] parseData, int offset) {
    // Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.calledSubsLastMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledSubsLastMcc

  /**
   * method will decode the CalledSubsLastMnc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledSubsLastMnc(String[] parseData, int offset) {
    // Read 2bytes, 2 hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.calledSubsLastMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledSubsLastMnc

  /**
   * method will decode the pni value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setPni(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.pni = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of pni

  /**
   * method will decode the insideControlPlaneIndex value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInsideControlPlaneIndex(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.insideControlPlaneIndex = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of insideControlPlaneIndex

  /**
   * method will decode the insideUserPlaneIndex value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInsideUserPlaneIndex(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.insideUserPlaneIndex = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of insideUserPlaneIndex

  /**
   * method will decode the GlobalCallReference value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setGlobalCallReference(String[] parseData, int offset) {
    // Read 21bytes , 16 BCD bytes + 5 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 16);
    offset += tempStr.length;
    String[] tempValue = CommonDecoderUtils.readBytes(parseData, offset, 5);
    this.globalCallReference = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr)
        + CommonDecoderUtils.getHexByteNibbleSwap(tempValue);
    return offset += tempValue.length;
  } // End of GlobalCallReference

  /**
   * method will decode the hotBillingRecordNumber value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setHotBillingRecordNumber(String[] parseData, int offset) {
    // Read 4bytes ,1 BCD dword -> 1byte swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.hotBillingRecordNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of hotBillingRecordNumber

  /**
   * method will decode the calledImeisv value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledImeisv(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.calledImeisv = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of calledImeisv

  /**
   * method will decode the virtualMscId value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setVirtualMscId(String[] parseData, int offset) {
    // Read 10bytes , 1byte nibble swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    this.virtualMscId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of virtualMscId

  /**
   * method will decode the numberOfInAnnouncements value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNumberOfInAnnouncements(String[] parseData, int offset) {
    // Read 1bytes , 1bcd byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.numberOfInAnnouncements = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of numberOfInAnnouncements

  /**
   * method will decode the nbrOfTermCapInRecs value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNbrOfTermCapInRecs(String[] parseData, int offset) {
    // Read 1bytes , 1bcd byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.nbrOfTermCapInRecs = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of NbrOfTermCapInRecs

  /**
   * method will decode the addRoutingCategory value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setAddRoutingCategory(String[] parseData, int offset) {
    // Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.addRoutingCategory = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of addRoutingCategory

  /**
   * method will decode the numberOfInRecords value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNumberOfInRecords(String[] parseData, int offset) {
    // Read 1bytes , 1bcd byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.numberOfInRecords = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of numberOfInRecords

  /**
   * method will decode the inCircuitGroupName value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInCircuitGroupName(String[] parseData, int offset) {
    // Read 16bytes , 16 ASCII HEX bytes*
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 16);
    this.inCircuitGroupName = CommonDecoderUtils.hexToAscii(tempStr);
    return offset += tempStr.length;
  } // End of inCircuitGroupName

  /**
   * method will decode the OutCircuitGroupName value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutCircuitGroupName(String[] parseData, int offset) {
    // Read 16bytes , 16 ASCII HEX bytes*
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 16);
    this.outCircuitGroupName = CommonDecoderUtils.hexToAscii(tempStr);
    return offset += tempStr.length;
  } // End of OutCircuitGroupName

  /**
   * method will decode the termMczDurationTenMs value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setTermMczDurationTenMs(String[] parseData, int offset) {
    // Read 4bytes , 4 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.termMczDurationTenMs = CommonDecoderUtils.getBcdByteRightToLeft(tempStr);
    return offset += tempStr.length;
  } // End of termMczDurationTenMs

  /**
   * method will decode the termdialledDigits value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setDialledDigits(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.dialledDigits = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of dialledDigits

  /**
   * method will decode the inCircuitGroup value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInCircuitGroup(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.inCircuitGroup = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of inCircuitGroup

  /**
   * method will decode the InCircuit value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInCircuit(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.inCircuit = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of InCircuit

  /**
   * method will decode the CtThirdPartyNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCtThirdPartyNumber(String[] parseData, int offset) {
    // Read 12bytes , hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.ctThirdPartyNumber = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of CtThirdPartyNumber

  /**
   * method will decode the InChannelAllocatedTime value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setInChannelAllocatedTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.inChannelAllocatedTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // End of InChannelAllocatedTime

  /**
   * method will decode the OrigMczDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigMczDuration(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.origMczDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OrigMczDuration

  /**
   * method will decode the OrigMczTariffClass value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigMczTariffClass(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.origMczTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OrigMczTariffClass

  /**
   * method will decode the OrigMczPulses value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigMczPulses(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.origMczPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OrigMczPulses

  /**
   * method will decode the CalledMsrn value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCalledMsrn(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.calledMsrn = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of CalledMsrn

  /**
   * method will decode the CallingModifyParameters value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingModifyParameters(String[] parseData, int offset) {
    // Read 14bytes , 7hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 14);
    this.callingModifyParameters = CommonDecoderUtils.getHexStringList(tempStr);
    return offset += tempStr.length;
  } // End of CallingModifyParameters

  /**
   * method will decode the OrigDiallingClass value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigDiallingClass(String[] parseData, int offset) {
    // Read 2bytes , 1hex word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.origDiallingClass = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of CallingModifyParameters

  /**
   * method will decode the OutsideUserPlaneIndex value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutsideUserPlaneIndex(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.outsideUserPlaneIndex = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OutsideUserPlaneIndex

  /**
   * method will decode the OutsideControlPlaneIndex value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOutsideControlPlaneIndex(String[] parseData, int offset) {
    // Read 2bytes , 1bcd word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.outsideControlPlaneIndex = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OutsideControlPlaneIndex

  /**
   * method will decode the CallingImeisv value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingImeisv(String[] parseData, int offset) {
    // Read 8bytes ,8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.callingImeisv = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of CallingImeisv

  /**
   * method will decode the NbrOfOrigCapInRecs value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setNbrOfOrigCapInRecs(String[] parseData, int offset) {
    // Read 1bytes , 1bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.nbrOfOrigCapInRecs = CommonDecoderUtils.getBcdByte((tempStr[0]));
    return offset += tempStr.length;
  } // End of NbrOfOrigCapInRecs

  /**
   * method will decode the ConnectedToNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setConnectedToNumber(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.connectedToNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of ConnectedToNumber

  /**
   * method will decode the OrigMczDurationTenMs value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigMczDurationTenMs(String[] parseData, int offset) {
    // Read 4bytes , 4 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.origMczDurationTenMs = CommonDecoderUtils.getBcdByteRightToLeft(tempStr);
    return offset += tempStr.length;
  } // End of OrigMczDurationTenMs

} // End of Class
