/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the LOCA record decoding.
 * 
 * @author robin.varghese
 *
 */
public class LocaRecord {

  /**
   * Method to convert the LOCA record to decoded value string.
   * 
   * @param parseData  - LOCA record from 3rd byte to 159 byte, total 159-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseLOCA(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final String subsOldLac;
    final String subsOldExId;
    final String subsNewLac;
    final String subsNewExId;
    final String servedNumber;
    final String mmeIpAddress;

    final CommonFields locaFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // ServedImsi
    offset = locaFields.setServedImsi(parseData, offset);
    resultList.add(locaFields.getServedImsi());

    // SubsOldLac, Read 2bytes , hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    subsOldLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(subsOldLac);
    offset += tempStr.length;

    // subsOldExId ,Read 10bytes , 10byteBCD
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    subsOldExId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(subsOldExId);
    offset += tempStr.length;

    // SubsNewLac, Read 2bytes , hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    subsNewLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(subsNewLac);
    offset += tempStr.length;

    // subsNewExId ,Read 10bytes , 10byteBCD
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    subsNewExId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(subsNewExId);
    offset += tempStr.length;

    // ChargingTime, 7 Bytes , 5 BCD bytes + 1 BCD word
    offset = locaFields.setDateTime(parseData, offset);
    resultList.add(locaFields.getDateTime());

    // ServedNumberTon
    resultList.add(parseData[offset++]);

    // ServedNumber, Read 12bytes , hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    servedNumber = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(servedNumber);
    offset += tempStr.length;

    // CallReferenceTime, 7 Bytes , 5 BCD bytes + 1 BCD word
    offset = locaFields.setDateTime(parseData, offset);
    resultList.add(locaFields.getDateTime());

    // mmeIpAddress ,Read 17bytes , 17 Hex byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 17);
    mmeIpAddress = CommonDecoderUtils.getHexByteNibbleSwap(tempStr);
    resultList.add(mmeIpAddress);
    offset += tempStr.length;

    // NumberOfInRecords, 7 Bytes , 5 BCD bytes + 1 BCD word
    offset = locaFields.setNumberOfInRecords(parseData, offset);
    resultList.add(locaFields.getNumberOfInRecords());

    // LocUpIndicator
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseLOCA

} // End of class
