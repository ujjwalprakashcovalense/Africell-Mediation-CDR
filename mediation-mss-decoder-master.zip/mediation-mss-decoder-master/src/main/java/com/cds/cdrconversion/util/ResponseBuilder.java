package com.cds.cdrconversion.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cds.cdrconversion.ConversionProcessor;
import com.cds.cdrconversion.util.constants.HeaderNames;

/**
 * The class wil write final output result to specified output file.
 */
public class ResponseBuilder {

	private String outputDirectory;
	private String outputFileExtension;
	private String outputFileSufix;
	private PrintWriter printWriter;
	private HeaderNames headerNames = new HeaderNames();
	private final static Logger logger = LoggerFactory.getLogger(ConversionProcessor.class.getName());
	boolean inboundSplit;

	public ResponseBuilder() {

		// loading the config values from properties
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream("application.properties"));
			outputDirectory = properties.getProperty("cdr.output.directory");
			outputFileExtension = properties.getProperty("cdr.outfile.extension");
			outputFileSufix = properties.getProperty("cdr.outfile.sufix");
			inboundSplit = Boolean.parseBoolean(properties.getProperty("cdr.outfile.inbound.split"));

			// creating output folder if it is not exist
			File outputPath = new File(outputDirectory);
			outputPath.mkdir();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * Method will write final output to specific file with given filename.
	 * 
	 * @param subDir
	 * 
	 * @throws IOException
	 */
	public void fileWriter(LinkedHashMap<String, List<String>> finalListMap, String fileName, String subDir)
			throws Exception {

		logger.info("Total no of records converted : " + finalListMap.size());

		// writing to the file row by row
		finalListMap.forEach((k, v) -> {

			try {
				// forming csv format
				String value = v.toString().replace("[", "").replace("]", "").replace(", ", ",");
				String recordType = k.substring(0, k.lastIndexOf("-")); // i.e COC-86 to COC

				// i.e inputFilename_MOC_DWH.csv
				// constructing a output file
				String inputFile = fileName.substring(0, fileName.lastIndexOf(".")); // trim upto before DAT
				String outputFile = outputFileSufix == null ? inputFile + "_" + recordType
						: inputFile + "_" + recordType + outputFileSufix;

				// creating sub directories
				Path path = Files.createDirectories(Paths.get(outputDirectory + "/" + subDir));
				outputFile = path + "/" + outputFile + outputFileExtension;

				File file = new File(outputFile);

				if (file.exists() && !file.isDirectory()) {
					printWriter = new PrintWriter(new FileOutputStream(file, true));
					// write values only
					printWriter.println(value);

				} else {
					// new file
					printWriter = new PrintWriter(outputFile);
					// write heading on first line
					printWriter.println(headerNames.header.get(recordType));
					// write values
					printWriter.println(value);
				}
				printWriter.close(); // closing the output file writer

				boolean voice = Arrays.asList("MOC", "MTC").stream().anyMatch(recordType::contains);
				boolean sms = Arrays.asList("SMMO", "SMMT").stream().anyMatch(recordType::contains);

				/**
				 * finding inbound/roaming voice(MOC/MTC and sms cdrs and splitting into new csv
				 * file
				 **/

				if (inboundSplit && voice || sms) {

					String imsi;

					if (voice)
						imsi = recordType.equals("MOC") ? v.get(9) : v.get(10); // taking calling/called imsi from
																				// moc/mtc
					else
						imsi = v.get(6); // taking calling/called imsi from smmo/smmt

					if (!imsi.startsWith("63105")) {

						// inputFilename_MOC_DWH -> CF1915_202207051415_INBOUND_MTC_DWH
						outputFile = outputFileSufix == null ? inputFile + "_" + recordType
								: inputFile + "_" + "INBOUND" + "_" + recordType + outputFileSufix;

						// subdir for voice and sms
						String inboundDir = voice ? "/inbound/voice" : "/inbound/sms";

						// creating sub directories i.e, /offline/output/240_2/inbound/voice
						path = Files.createDirectories(Paths.get(outputDirectory + "/" + inboundDir));
						outputFile = path + "/" + outputFile + outputFileExtension;

						file = new File(outputFile);

						if (file.exists() && !file.isDirectory()) {
							printWriter = new PrintWriter(new FileOutputStream(file, true));
							// write values only
							printWriter.println(value);

						} else {
							// new file
							printWriter = new PrintWriter(outputFile);
							// write heading on first line
							// printWriter.println(headerNames.header.get(recordType));
							// write values
							printWriter.print(value);
						}
						printWriter.close(); // closing the output file writer
					} // end of moc/mtc if

				} // end of inbound split if

			} catch (Exception e) {
				logger.error("Error occurred while output writing :" + e.getMessage());
			}

		}); // end of foreach loop
	} // end of fileWriter
} // End of class
