/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;


/**
 * The class will process the PBXT record decoding.
 * 
 * @author robin.varghese
 *
 */
public class PbxtRecord {

  /**
   * Method to convert the PBXT record to decoded value string.
   * 
   * @param parseData  - PBXT record from 3rd byte to 195 byte, total 195-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parsePBXT(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields pbxtFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = pbxtFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(pbxtFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = pbxtFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(pbxtFields.getNumberOfSsRecords());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // CallingNumber
    offset = pbxtFields.setCallingNumber(parseData, offset);
    resultList.add(pbxtFields.getCallingNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = pbxtFields.setCalledNumber(parseData, offset);
    resultList.add(pbxtFields.getCalledNumber());

    // OutCircuitGroup
    offset = pbxtFields.setOutCircuitGroup(parseData, offset);
    resultList.add(pbxtFields.getOutCircuitGroup());

    // OutCircuit
    offset = pbxtFields.setOutCircuit(parseData, offset);
    resultList.add(pbxtFields.getOutCircuit());

    // OutChannelAllocatedTime
    offset = pbxtFields.setDateTime(parseData, offset);
    resultList.add(pbxtFields.getDateTime());

    // ChargingStartTime
    offset = pbxtFields.setDateTime(parseData, offset);
    resultList.add(pbxtFields.getDateTime());

    // ChargingEndTime
    offset = pbxtFields.setDateTime(parseData, offset);
    resultList.add(pbxtFields.getDateTime());

    // CauseForTermination
    offset = pbxtFields.setCauseForTermination(parseData, offset);
    resultList.add(pbxtFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // OazChrgType
    resultList.add(parseData[offset++]);
    
    // OazDuration
    offset = pbxtFields.setIazDuration(parseData, offset);
    resultList.add(pbxtFields.getIazDuration());

    // OazTariffClass
    offset = pbxtFields.setOazTariffClass(parseData, offset);
    resultList.add(pbxtFields.getOazTariffClass());

    // OazPulses
    offset = pbxtFields.setOazPulses(parseData, offset);
    resultList.add(pbxtFields.getOazPulses());

    // IntermediateChrgeCause
    offset = pbxtFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(pbxtFields.getIntermediateChrgeCause());

    // LegCallReference
    offset = pbxtFields.setLegCallReference(parseData, offset);
    resultList.add(pbxtFields.getLegCallReference());

    // CallReferenceTime
    offset = pbxtFields.setCallReferenceTime(parseData, offset);
    resultList.add(pbxtFields.getCallReferenceTime());

    // NumberOfAllInRecords
    offset = pbxtFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(pbxtFields.getNumberOfAllInRecords());

    // Pni
    offset = pbxtFields.setPni(parseData, offset);
    resultList.add(pbxtFields.getPni());

    // GlobalCallReference
    offset = pbxtFields.setGlobalCallReference(parseData, offset);
    resultList.add(pbxtFields.getGlobalCallReference());

    // RedirectedIndicator
    resultList.add(parseData[offset++]);

    // CugInterlock
    offset = pbxtFields.setCugInterlock(parseData, offset);
    resultList.add(pbxtFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = pbxtFields.setNumberOfInRecords(parseData, offset);
    resultList.add(pbxtFields.getNumberOfInRecords());

    // ScpConnection
    resultList.add(parseData[offset++]);
    
    // termMczChangeDirection
    resultList.add(parseData[offset++]);
    
    // termMczChangePercent
    resultList.add(parseData[offset++]);

    // oaz_change_direction
    resultList.add(parseData[offset++]);
    
    // OazChangePercent
    resultList.add(parseData[offset++]);

    // InCircuitGroupName
    offset = pbxtFields.setInCircuitGroupName(parseData, offset);
    resultList.add(pbxtFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = pbxtFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(pbxtFields.getOutCircuitGroupName());

    // TermMczDurationTenMs
    offset = pbxtFields.setTermMczDurationTenMs(parseData, offset);
    resultList.add(pbxtFields.getTermMczDurationTenMs());

    // TermMczDuration
    offset = pbxtFields.setTermMczDuration(parseData, offset);
    resultList.add(pbxtFields.getTermMczDuration());

    // OrigMczChrgType
    resultList.add(parseData[offset++]);

    // DirectoryNumber
    offset = pbxtFields.setDirectoryNumber(parseData, offset);
    resultList.add(pbxtFields.getDirectoryNumber());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parsePBXT

} // End of class
