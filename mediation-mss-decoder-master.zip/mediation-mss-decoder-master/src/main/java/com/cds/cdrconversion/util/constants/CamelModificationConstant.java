package com.cds.cdrconversion.util.constants;

/**
 * The facilityConstantUtil class provides all the constants used by
 * CamelModification field.
 */
public class CamelModificationConstant {

  public static final String BIT_1  = "Calling category";
  public static final String BIT_2  = "|Original called number";
  public static final String BIT_3  = "|Additional Calling line identity";
  public static final String BIT_4  = "|Redirecting number Open Mobile Softswitch Cloud Release 21.2, Issue 02";
  public static final String BIT_5  = "|Redirection counter";
  public static final String BIT_6  = "|Carrier information";
  public static final String BIT_7  = "|Originating line information";
  public static final String BIT_8  = "|Charge number";
  public static final String BIT_9  = "|Forward conference";
  public static final String BIT_10 = "|Call diversion";
  public static final String BIT_11 = "|Calling party restriction ";
  public static final String BIT_12 = "|Backward conference";
  public static final String BIT_13 = "|Connected number";
  public static final String BIT_14 = "|Hold";
  public static final String BIT_15 = "|Call wait";
  public static final String BIT_16 = "|Explicit call transfer";
  public static final String BIT_17 = "|Call completion";
  public static final String BIT_18 = "|CUG interlock code";
  public static final String BIT_19 = "|CUG outgoing access";
  public static final String BIT_20 = "|Non CUG-call";
  public static final String BIT_21 = "|Destination routing number";
  public static final String BIT_22 = "|Calling Party Number";
  private CamelModificationConstant() {

  }
}
