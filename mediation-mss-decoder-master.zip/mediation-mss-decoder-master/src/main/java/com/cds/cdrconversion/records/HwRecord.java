/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;


/**
 * The class will process the HW record decoding.
 * 
 * @author robin.varghese
 *
 */
public class HwRecord {

  /**
   * Method to convert the HW record to decoded value string.
   * 
   * @param parseData  - WW record from 3rd byte to 159 byte, total 159-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseHW(String[] parseData, List<String> resultList) {

    int offset = 0;
    String[] tempStr;
    final String equipmentId;
    final CommonFields hwFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = hwFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(hwFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // EquipmentType
    resultList.add(parseData[offset++]);

    // equipmentId , Read 10bytes ,10 Hex Byte
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    equipmentId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(equipmentId);
    offset += tempStr.length;

    // ServedImsi
    offset = hwFields.setServedImsi(parseData, offset);
    resultList.add(hwFields.getServedImsi());

    // ServedNumberTon
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // ServedNumber
    offset = hwFields.setServedNumber(parseData, offset);
    resultList.add(hwFields.getServedNumber());

    // chargingStartTime
    offset = hwFields.setDateTime(parseData, offset);
    resultList.add(hwFields.getDateTime());

    // chargingEndTime
    offset = hwFields.setDateTime(parseData, offset);
    resultList.add(hwFields.getDateTime());

    // ChargeableDuration
    offset = hwFields.setChargeableDuration(parseData, offset);
    resultList.add(hwFields.getChargeableDuration());

    // LegCallReference
    offset = hwFields.setLegCallReference(parseData, offset);
    resultList.add(hwFields.getLegCallReference());

    // CauseForTermination
    offset = hwFields.setCauseForTermination(parseData, offset);
    resultList.add(hwFields.getCauseForTermination());

    // InChannelAllocatedTime
    offset = hwFields.setDateTime(parseData, offset);
    resultList.add(hwFields.getDateTime());

    // IntermediateChrgeCause
    offset = hwFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(hwFields.getIntermediateChrgeCause());

    // CallReferenceTime
    offset = hwFields.setDateTime(parseData, offset);
    resultList.add(hwFields.getDateTime());

    // HotBillingRecordNumber
    offset = hwFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(hwFields.getHotBillingRecordNumber());
    
    return resultList;
  } // End of parseHW

} // End of class
