/*
 * Copyright (C) 2022 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.util;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cds.cdrconversion.util.constants.CamelModificationConstant;
import com.cds.cdrconversion.util.constants.FacilityConstant;
import com.cds.cdrconversion.util.constants.IntermediateCauseConstants;

public class CommonDecoderUtils {
	private final static Logger logger = LoggerFactory.getLogger(CommonDecoderUtils.class.getName());

	/**
	 * Method will decode the given string array into hex word and converting to
	 * decimal.
	 * 
	 * @param hexArray - string array of record length.
	 * @return - decoded decimal value
	 */
	public static int getHexWordDecimal(String[] hexArray) {

		// HEX WORD swapping (abcd)->(cdab) swaping the byte
		String hexWord = hexArray[1] + hexArray[0];

		return getDecimal(hexWord);
	} // end of getHexWordDecimal

	/**
	 * Method will conver hexadecimal to decimal value.
	 * 
	 * @param value - hex string value to convert.
	 * @return - converted decimal value
	 */
	public static int getDecimal(String value) {

		return Integer.parseInt(value, 16);
	} // End of getDecimal

	/**
	 * Method will convert 1 byte BCD , using the bitwise logic.
	 * 
	 * @param value - hex string value to convert.
	 * @return - bcd value as string
	 */
	public static String getBcdByte(String head) {

		// ( a b )->(a b)
		StringBuffer buffer = new StringBuffer();
		int byte1 = Integer.parseUnsignedInt(head, 16);
		int byte1Units = (byte1 & 0x0f);
		int byte1Tens = (byte1 & 0xf0) >>> 4;
		// ignore only F
		if (byte1Tens < 10)
			buffer.append(String.valueOf(byte1Tens));
		if (byte1Units < 10)
			buffer.append(String.valueOf(byte1Units));

		return buffer.toString();
	} // End of getBcdByte

	/**
	 * Method will convert 1 hexadecimal byte to decimal value.
	 * 
	 * @param value - 1 hex string value to convert.
	 * @return - converted decimal value.
	 */
	public static String hexByteToDec(String value) {

		return String.valueOf(Integer.parseInt(value));
	} // End of hexByteToDec

	/**
	 * String list array reader based on offset and length.
	 * 
	 */
	public static String[] readBytes(String[] headerData, int startoffset, int length) {

		final String[] strList = new String[length];
		for (int i = 0; i < length; i++) {
			strList[i] = headerData[startoffset + i];
		}
		return strList;
	} // end of readBytes.

	/**
	 * Method will perform nibble swapping for 1 byte ( a b )->(b a).
	 * 
	 * @param tempStr - 1 bye hex string[] value to convert.
	 * @return - swapped 1 bytes value.
	 */
	public static String oneByteNibbleSwap(String tempStr) {

		// ( a b )->(b a)
		StringBuffer buffer = new StringBuffer();
		int byte1 = Integer.parseUnsignedInt(tempStr, 16);
		int byte1Units = (byte1 & 0x0f);
		int byte1Tens = (byte1 & 0xf0) >>> 4;
		// ignore only F
		if (byte1Units < 10)
			buffer.append(String.valueOf(byte1Units));
		if (byte1Tens < 10)
			buffer.append(String.valueOf(byte1Tens));

		return buffer.toString();
	} // End of oneByteNibbleSwap

	/**
	 * Method will decode the given string hexdump array into HEX WORD swapping (ab
	 * cd ef gh)->(cd ab gh ef )
	 * 
	 * @param hexArray - hex string array.
	 * @return - swapped hex byte value.
	 */
	public static String getHexByteSwap(String[] hexArray) {

		// HEX WORD swapping (ab cd ef gh)->(cd ab gh ef ) swaping the byte
		StringBuffer buffer = new StringBuffer();

		for (int i = 1; i < hexArray.length; i += 2) {
			buffer.append((hexArray[i]));
			buffer.append((hexArray[i - 1]));

		}
		return buffer.toString();
	} // end of getMultiBcdHexBytes

	/**
	 * Method will convert multiple bcd byte nibble swapping for logic.
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted multi bcd bytes value.
	 */
	public static String getBcdByteNibbleSwap(String[] hexStr) {

		// multi byte nibble swapping (ab cd )->(ba dc)
		StringBuffer buffer = new StringBuffer();

		for (int i = 0; i < hexStr.length; i++) {
			buffer.append(oneByteNibbleSwap(hexStr[i]));
		}
		return buffer.toString();
	} // End of getMultiBcd

	/**
	 * Method will convert 5 BCD bytes + 1 BCD word: SSMMHH DDMMYYYY (time = 3
	 * bytes, day = 2 bytes + word)
	 * 
	 * @param tempStr - multi hex bytes string[] value to convert.
	 * @return - converted dateformat string.
	 */
	public static String getDateTime(String[] tempStr) {

		String bcd = getBcdBytes(tempStr);
		String dateTimeFormat;
		if (bcd.isEmpty()) // ignoring all FF values
			return bcd;

		String SS = tempStr[0];
		String MMT = tempStr[1];
		String HH = tempStr[2];
		String time = SS + MMT + HH;

		String DD = tempStr[3];
		String MMD = tempStr[4];
		String YY1 = tempStr[5];
		String YY2 = tempStr[6];
		// if time contains FF return only date
		if (time.contains("FF"))
			return YY2 + YY1 + "-" + MMD + "-" + DD; // YYYY-MM-DD

		// YYYY-MM-DD HH:MM:SS DDMMYYYY -> 2021-08-30 11:15:18
		dateTimeFormat = YY2 + YY1 + "-" + MMD + "-" + DD + " " + HH + ":" + MMT + ":" + SS;
		return dateTimeFormat;
	} // end of getDateTime

	/**
	 * Method will convert given hex string to ASCII value string.
	 * 
	 * @param hexStr - hex string value to convert.
	 * @return - converted ASCII string.
	 */
	public static String hexToAscii(String[] hexStr) {
		StringBuilder output = new StringBuilder("");

		for (int i = 0; i < hexStr.length; i++) {
			if (!hexStr[i].equals("00"))
				output.append((char) Integer.parseInt(hexStr[i], 16));
		}
		return output.toString();
	} // End of hexToAscii

	/**
	 * Method will convert multiple bcd byte into a single string. (ab cd )->(ab cd)
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted multi bcd bytes value.
	 */
	public static String getBcdBytes(String[] hexStr) {

		// (ab cd )->(ab cd)
		StringBuffer buffer = new StringBuffer();

		for (int i = 0; i < hexStr.length; i++) {
			buffer.append(getBcdByte((hexStr[i])));
		}
		return buffer.toString();
	} // End of getBcdBytes

	/**
	 * Method will convert multiple bcd byte into a single string. swapping the (ab
	 * cd)->(cd ba)
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted swapped bcd bytes value.
	 */
	public static String getBcdByteSwap(String[] hexStr) {

		// BCD byte swapping (ab cd)->(cd ba)
		StringBuffer buffer = new StringBuffer();

		for (int i = hexStr.length - 1; i >= 0; i--) {
			buffer.append(getBcdByte((hexStr[i])));
		}
		return buffer.toString();
	} // End of getBcdByteSwap

	/**
	 * Method will convert multiple hex byte array to nibble swapping logic. (ab cd
	 * )->(ba dc)
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted multi hex bytes value.
	 */
	public static String getHexByteNibbleSwap(String[] hexStr) {

		// multi byte nibble swapping (ab cd )->(ba dc)
		StringBuffer buffer = new StringBuffer();
		int byte1Units;
		int byte1;
		int byte1Tens;
		for (int i = 0; i < hexStr.length; i++) {
			byte1 = Integer.parseUnsignedInt(hexStr[i], 16);
			byte1Units = (byte1 & 0x0f);
			byte1Tens = (byte1 & 0xf0) >>> 4;
			// 21 -> 12
			String byte1Hex = Integer.toHexString(byte1Units).toUpperCase()
					+ Integer.toHexString(byte1Tens).toUpperCase();
			buffer.append(byte1Hex);
		}
		return buffer.toString();

	}// End of getHexByteNibbleSwap

	/**
	 * Method will convert multiple hex byte into right to left logic. (ab cd ef gh
	 * )->(gh ef cd ab)
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted swapped hex bytes value.
	 */
	public static String getHexByteRightToLeft(String[] hexStr) {

		// BCD byte swapping (ab cd ef gh )->(gh ef cd ab)
		StringBuffer buffer = new StringBuffer();

		for (int i = hexStr.length - 1; i >= 0; i--) {
			buffer.append((hexStr[i]));
		}
		return buffer.toString();
	} // End of getHexByteRightToLeft

	/**
	 * Method will convert multiple hex byte into bcd from right to left logic. (ab
	 * cd ef gh )->(gh ef cd ab)
	 * 
	 * @param hexStr - multi hex bytes string[] value to convert.
	 * @return - converted swapped bcd bytes value.
	 */
	public static String getBcdByteRightToLeft(String[] hexStr) {

		// BCD byte swapping (ab cd ef gh )->(gh ef cd ab)
		StringBuffer buffer = new StringBuffer();

		for (int i = hexStr.length - 1; i >= 0; i--) {
			buffer.append(getBcdByte(hexStr[i]));
		}
		return buffer.toString();
	} // End of getBcdByteRightToLeft

	/**
	 * Method will append all list of string array of hex string into one string.
	 * 
	 * @param hexStr - string[] value to append.
	 * @return - appended hex string.
	 */
	public static String getHexStringList(String[] hexStr) {

		StringBuffer buffer = new StringBuffer();

		for (int i = 0; i < hexStr.length; i++) {
			buffer.append(hexStr[i]);
		}
		return buffer.toString();
	} // End of getHexStringList

	/**
	 * Method will decode the header section of all record type.
	 * 
	 * @return - decoded header part.
	 */
	public static List<String> getHeaderData(String[] parseData, int offset, List<String> resultList) {

		String[] tempStr;
		String[] tempValue;
		// common header part
		final String recordNumber;
		final String recordStatus;
		final int checkSum;
		String callReference;
		final String exchangeId;

		// Read 4bytes ,1 BCD dword -> 1byte swapping logic
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
		recordNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
		resultList.add(recordNumber);
		offset += tempStr.length;

		// Read 1hex byte
		recordStatus = parseData[offset++];
		resultList.add(recordStatus);

		// Read 2bytes , hexword
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
		checkSum = CommonDecoderUtils.getHexWordDecimal(tempStr);
		resultList.add(String.valueOf(checkSum));
		offset += tempStr.length;

		// Read 5bytes , word+word+byte
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
		offset += tempStr.length;
		tempValue = CommonDecoderUtils.readBytes(parseData, offset, 1);

		String callReferenceHex = CommonDecoderUtils.getHexByteSwap(tempStr) + tempValue[0];

		Long outputLong = Long.parseLong(callReferenceHex, 16);

		callReference = String.valueOf(outputLong);
		String callReferenceUpdated = callReference.substring(0, 8);
		// logger.info("callReference in Hex: {}",callReferenceHex);
		// logger.info("callReference in decimal: {}",callReference);
		resultList.add(callReferenceUpdated);
		offset += tempValue.length;

		// Read 10bytes , 1byte nibble swapping logic
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
		exchangeId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
		resultList.add(exchangeId);
		offset += tempStr.length;
		return resultList;
	} // End of getHeaderData

	/**
	 * Method will process the decoding rule for facilityUsage. lsb to msb bit
	 * reading logic 1 to 32 bit.
	 * 
	 * @param hexStr - string[] value to decode.
	 * @return - decoded value.
	 */
	public static String getFacilityUsage(String[] hexStr) {

		StringBuffer buffer = new StringBuffer();
		// converting input to hexdword -[01, 00, 00, 00] ->
		String hexdword = getHexByteRightToLeft(hexStr);
		// hexdword = 00 00 00 01
		int hexdwordbyte = Integer.parseUnsignedInt(hexdword, 16);

		// i.e. there is some value
		if ((hexdwordbyte & 0xffffffff) > 0) {
			// Some bit on byte 1 is set
			if ((hexdwordbyte & 0x000000ff) > 0) {

				// Compare bits for byte1- 0000 0000 0000 0000 0000 0000 0000 0001
				if ((hexdwordbyte & 0x00000001) > 0)
					buffer.append(FacilityConstant.BIT_1);

				// bit 2= 0000 0000 0000 0000 0000 0000 0000 0010
				if ((hexdwordbyte & 0x00000002) > 0)
					buffer.append(FacilityConstant.BIT_2);

				// bit 3= 0000 0000 0000 0000 0000 0000 0000 0100
				if ((hexdwordbyte & 0x00000004) > 0)
					buffer.append(FacilityConstant.BIT_3);

				// bit 4= 0000 0000 0000 0000 0000 0000 0000 1000
				if ((hexdwordbyte & 0x00000008) > 0)
					buffer.append(FacilityConstant.BIT_4);

				// bit 5= 0000 0000 0000 0000 0000 0000 0001 0000
				if ((hexdwordbyte & 0x00000010) > 0)
					buffer.append(FacilityConstant.BIT_5);

				// bit 6= 0000 0000 0000 0000 0000 0000 0010 0000
				if ((hexdwordbyte & 0x00000020) > 0)
					buffer.append(FacilityConstant.BIT_6);

				// bit 7= 0000 0000 0000 0000 0000 0000 0100 0000
				if ((hexdwordbyte & 0x00000040) > 0)
					buffer.append(FacilityConstant.BIT_7);

				// bit 8= 0000 0000 0000 0000 0000 0000 1000 0000
				if ((hexdwordbyte & 0x00000080) > 0)
					buffer.append(FacilityConstant.BIT_8);
			} // End of 1st byte compare

			// Some bit on byte2 is set
			if ((hexdwordbyte & 0x0000ff00) > 0) {

				// bit 9= 0000 0000 0000 0000 0000 0001 0000 0000
				if ((hexdwordbyte & 0x00000100) > 0)
					buffer.append(FacilityConstant.BIT_9);
				// bit 10= 0000 0000 0000 0000 0000 0010 0000 0000
				if ((hexdwordbyte & 0x00000200) > 0)
					buffer.append(FacilityConstant.BIT_10);
				// bit 11= 0000 0000 0000 0000 0000 0100 0000 0000
				if ((hexdwordbyte & 0x00000400) > 0)
					buffer.append(FacilityConstant.BIT_11);
				// bit 12= 0000 0000 0000 0000 0000 1000 0000 0000
				if ((hexdwordbyte & 0x00000800) > 0)
					buffer.append(FacilityConstant.BIT_12);
				// bit 13= 0000 0000 0000 0000 0001 0000 0000 0000
				if ((hexdwordbyte & 0x00001000) > 0)
					buffer.append(FacilityConstant.BIT_13);
				// bit 14= 0000 0000 0000 0000 0010 0000 0000 0000
				if ((hexdwordbyte & 0x00002000) > 0)
					buffer.append(FacilityConstant.BIT_14);
				// bit 15= 0000 0000 0000 0000 0100 0000 0000 0000
				if ((hexdwordbyte & 0x00004000) > 0)
					buffer.append(FacilityConstant.BIT_15);
				// bit 16= 0000 0000 0000 0000 1000 0000 0000 0000
				if ((hexdwordbyte & 0x00008000) > 0)
					buffer.append(FacilityConstant.BIT_16);
			} // End of 2nd byte compare

			// Some bit on byte3 is set
			if ((hexdwordbyte & 0x00ff0000) > 0) {
				if ((hexdwordbyte & 0x00010000) > 0) // bit 17
					buffer.append(FacilityConstant.BIT_17);
				if ((hexdwordbyte & 0x00020000) > 0) // bit 18
					buffer.append(FacilityConstant.BIT_18);
				if ((hexdwordbyte & 0x00040000) > 0) // bit 19
					buffer.append(FacilityConstant.BIT_19);
				if ((hexdwordbyte & 0x00080000) > 0) // bit 20
					buffer.append(FacilityConstant.BIT_20);
				if ((hexdwordbyte & 0x00100000) > 0) // bit 21
					buffer.append(FacilityConstant.BIT_21);
				if ((hexdwordbyte & 0x00200000) > 0) // bit 22
					buffer.append(FacilityConstant.BIT_22);
				if ((hexdwordbyte & 0x00400000) > 0) // bit 23
					buffer.append(FacilityConstant.BIT_23);
				if ((hexdwordbyte & 0x00800000) > 0) // bit 24
					buffer.append(FacilityConstant.BIT_24);
			} // End of 3nd byte compare

			// Some bit on byte4 is set
			if ((hexdwordbyte & 0xff000000) > 0) {
				if ((hexdwordbyte & 0x01000000) > 0) // bit 25
					buffer.append(FacilityConstant.BIT_25);
				if ((hexdwordbyte & 0x02000000) > 0) // bit 26
					buffer.append(FacilityConstant.BIT_26);
				if ((hexdwordbyte & 0x04000000) > 0) // bit 27
					buffer.append(FacilityConstant.BIT_27);
				if ((hexdwordbyte & 0x08000000) > 0) // bit 28
					buffer.append(FacilityConstant.BIT_28);
				if ((hexdwordbyte & 0x10000000) > 0) // bit 29
					buffer.append(FacilityConstant.BIT_29);
				if ((hexdwordbyte & 0x20000000) > 0) // bit 30
					buffer.append(FacilityConstant.BIT_30);
				if ((hexdwordbyte & 0x40000000) > 0) // bit 31
					buffer.append(FacilityConstant.BIT_31);
				if ((hexdwordbyte & 0x80000000) > 0) // bit 32
					buffer.append(FacilityConstant.BIT_32);
			} // End of 4nd byte compare

		} // end of main if

		return buffer.toString();
	} // End of getFacilityUsage

	public static String getIntermediateChrgeCause(String[] tempStr) {
		StringBuffer buffer = new StringBuffer();
		// converting input to hexdword
		String hexdword = getHexByteRightToLeft(tempStr);
		int hexdwordbyte = Integer.parseUnsignedInt(hexdword, 16);
		// i.e. there is some value
		if ((hexdwordbyte & 0xffffffff) > 0) {
			// Some bit on byte 1 is set
			if ((hexdwordbyte & 0x000000ff) > 0) {

				// Compare bits for byte1- 0000 0000 0000 0000 0000 0000 0000 0001
				if ((hexdwordbyte & 0x00000001) > 0)
					buffer.append(IntermediateCauseConstants.BIT_1);

				// bit 2= 0000 0000 0000 0000 0000 0000 0000 0010
				if ((hexdwordbyte & 0x00000002) > 0)
					buffer.append(IntermediateCauseConstants.BIT_2);

				// bit 3= 0000 0000 0000 0000 0000 0000 0000 0100
				if ((hexdwordbyte & 0x00000004) > 0)
					buffer.append(IntermediateCauseConstants.BIT_3);

				// bit 4= 0000 0000 0000 0000 0000 0000 0000 1000
				if ((hexdwordbyte & 0x00000008) > 0)
					buffer.append(IntermediateCauseConstants.BIT_4);

				// bit 5= 0000 0000 0000 0000 0000 0000 0001 0000
				if ((hexdwordbyte & 0x00000010) > 0)
					buffer.append(IntermediateCauseConstants.BIT_5);

				// bit 6= 0000 0000 0000 0000 0000 0000 0010 0000
				if ((hexdwordbyte & 0x00000020) > 0)
					buffer.append(IntermediateCauseConstants.BIT_6);

				// bit 7= 0000 0000 0000 0000 0000 0000 0100 0000
				if ((hexdwordbyte & 0x00000040) > 0)
					buffer.append(IntermediateCauseConstants.BIT_7);

				// bit 8= 0000 0000 0000 0000 0000 0000 1000 0000
				if ((hexdwordbyte & 0x00000080) > 0)
					buffer.append(IntermediateCauseConstants.BIT_8);
			} // End of 1st byte compare

			// Some bit on byte2 is set
			if ((hexdwordbyte & 0x0000ff00) > 0) {

				// bit 9= 0000 0000 0000 0000 0000 0001 0000 0000
				if ((hexdwordbyte & 0x00000100) > 0)
					buffer.append(IntermediateCauseConstants.BIT_9);
				// bit 10= 0000 0000 0000 0000 0000 0010 0000 0000
				if ((hexdwordbyte & 0x00000200) > 0)
					buffer.append(IntermediateCauseConstants.BIT_10);
				// bit 11= 0000 0000 0000 0000 0000 0100 0000 0000
				if ((hexdwordbyte & 0x00000400) > 0)
					buffer.append(IntermediateCauseConstants.BIT_11);
				// bit 12= 0000 0000 0000 0000 0000 1000 0000 0000
				if ((hexdwordbyte & 0x00000800) > 0)
					buffer.append(IntermediateCauseConstants.BIT_12);
				// bit 13= 0000 0000 0000 0000 0001 0000 0000 0000
				if ((hexdwordbyte & 0x00001000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_13);
				// bit 14= 0000 0000 0000 0000 0010 0000 0000 0000
				if ((hexdwordbyte & 0x00002000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_14);
				// bit 15= 0000 0000 0000 0000 0100 0000 0000 0000
				if ((hexdwordbyte & 0x00004000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_15);
				// bit 16= 0000 0000 0000 0000 1000 0000 0000 0000
				if ((hexdwordbyte & 0x00008000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_16);
			} // End of 2nd byte compare

			// Some bit on byte3 is set
			if ((hexdwordbyte & 0x00ff0000) > 0) {
				if ((hexdwordbyte & 0x00010000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_17);
				if ((hexdwordbyte & 0x00020000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_18);
				if ((hexdwordbyte & 0x00040000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_19);
				if ((hexdwordbyte & 0x00080000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_20);
				if ((hexdwordbyte & 0x00100000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_21);
				if ((hexdwordbyte & 0x00200000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_22);
				if ((hexdwordbyte & 0x00400000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_23);
				if ((hexdwordbyte & 0x00800000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_24);
			} // End of 3nd byte compare

			// Some bit on byte4 is set
			if ((hexdwordbyte & 0xff000000) > 0) {
				if ((hexdwordbyte & 0x01000000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_25);
				if ((hexdwordbyte & 0x02000000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_26);
				if ((hexdwordbyte & 0x04000000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_27);
				if ((hexdwordbyte & 0x08000000) > 0)
					buffer.append(IntermediateCauseConstants.BIT_28);
			} // End of byte4 if

		} // end of main if

		return buffer.toString();

	}

	/**
	 * Method will process the decoding rule for camel_modification. lsb to msb bit
	 * reading logic 1 to 32 bit.
	 * 
	 * @param hexStr - string[] value to decode.
	 * @return - decoded value string.
	 */
	public static String getCamelModification(String[] tempStr) {
		StringBuffer buffer = new StringBuffer();
		// converting input to hex string
		String hexString = getHexStringList(tempStr);
		int hexdwordbyte = Integer.parseUnsignedInt(hexString, 16);
		// i.e. there is some value
		if ((hexdwordbyte & 0xffffffff) > 0) {
			// Some bit on byte 1 is set
			if ((hexdwordbyte & 0x000000ff) > 0) {

				// Compare bits for byte1- 0000 0000 0000 0000 0000 0000 0000 0001
				if ((hexdwordbyte & 0x00000001) > 0)
					buffer.append(CamelModificationConstant.BIT_1);

				// bit 2= 0000 0000 0000 0000 0000 0000 0000 0010
				if ((hexdwordbyte & 0x00000002) > 0)
					buffer.append(CamelModificationConstant.BIT_2);

				// bit 3= 0000 0000 0000 0000 0000 0000 0000 0100
				if ((hexdwordbyte & 0x00000004) > 0)
					buffer.append(CamelModificationConstant.BIT_3);

				// bit 4= 0000 0000 0000 0000 0000 0000 0000 1000
				if ((hexdwordbyte & 0x00000008) > 0)
					buffer.append(CamelModificationConstant.BIT_4);

				// bit 5= 0000 0000 0000 0000 0000 0000 0001 0000
				if ((hexdwordbyte & 0x00000010) > 0)
					buffer.append(CamelModificationConstant.BIT_5);

				// bit 6= 0000 0000 0000 0000 0000 0000 0010 0000
				if ((hexdwordbyte & 0x00000020) > 0)
					buffer.append(CamelModificationConstant.BIT_6);

				// bit 7= 0000 0000 0000 0000 0000 0000 0100 0000
				if ((hexdwordbyte & 0x00000040) > 0)
					buffer.append(CamelModificationConstant.BIT_7);

				// bit 8= 0000 0000 0000 0000 0000 0000 1000 0000
				if ((hexdwordbyte & 0x00000080) > 0)
					buffer.append(CamelModificationConstant.BIT_8);
			} // End of 1st byte compare

			// Some bit on byte2 is set
			if ((hexdwordbyte & 0x0000ff00) > 0) {

				// bit 9= 0000 0000 0000 0000 0000 0001 0000 0000
				if ((hexdwordbyte & 0x00000100) > 0)
					buffer.append(CamelModificationConstant.BIT_9);
				// bit 10= 0000 0000 0000 0000 0000 0010 0000 0000
				if ((hexdwordbyte & 0x00000200) > 0)
					buffer.append(CamelModificationConstant.BIT_10);
				// bit 11= 0000 0000 0000 0000 0000 0100 0000 0000
				if ((hexdwordbyte & 0x00000400) > 0)
					buffer.append(CamelModificationConstant.BIT_11);
				// bit 12= 0000 0000 0000 0000 0000 1000 0000 0000
				if ((hexdwordbyte & 0x00000800) > 0)
					buffer.append(CamelModificationConstant.BIT_12);
				// bit 13= 0000 0000 0000 0000 0001 0000 0000 0000
				if ((hexdwordbyte & 0x00001000) > 0)
					buffer.append(CamelModificationConstant.BIT_13);
				// bit 14= 0000 0000 0000 0000 0010 0000 0000 0000
				if ((hexdwordbyte & 0x00002000) > 0)
					buffer.append(CamelModificationConstant.BIT_14);
				// bit 15= 0000 0000 0000 0000 0100 0000 0000 0000
				if ((hexdwordbyte & 0x00004000) > 0)
					buffer.append(CamelModificationConstant.BIT_15);
				// bit 16= 0000 0000 0000 0000 1000 0000 0000 0000
				if ((hexdwordbyte & 0x00008000) > 0)
					buffer.append(CamelModificationConstant.BIT_16);
			} // End of 2nd byte compare

			// Some bit on byte3 is set
			if ((hexdwordbyte & 0x00ff0000) > 0) {
				if ((hexdwordbyte & 0x00010000) > 0)
					buffer.append(CamelModificationConstant.BIT_17);
				if ((hexdwordbyte & 0x00020000) > 0)
					buffer.append(CamelModificationConstant.BIT_18);
				if ((hexdwordbyte & 0x00040000) > 0)
					buffer.append(CamelModificationConstant.BIT_19);
				if ((hexdwordbyte & 0x00080000) > 0)
					buffer.append(CamelModificationConstant.BIT_20);
				if ((hexdwordbyte & 0x00100000) > 0)
					buffer.append(CamelModificationConstant.BIT_21);
				if ((hexdwordbyte & 0x00200000) > 0)
					buffer.append(CamelModificationConstant.BIT_22);
			} // End of 3nd byte compare
		} // end of main if

		return buffer.toString();

	} // End of getCamelModification

} // End of util class
