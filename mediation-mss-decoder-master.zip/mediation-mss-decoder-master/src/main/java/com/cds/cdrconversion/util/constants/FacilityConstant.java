package com.cds.cdrconversion.util.constants;
/**
 * The facilityConstantUtil class provides all the constants used by getFacilityUsage.
 */
public class FacilityConstant {

  public static final String BIT_1  = "aoc - charging";
  public static final String BIT_2  = "|aoc - charging information at the end of the call";
  public static final String BIT_3  = "|aoc - information";
  public static final String BIT_4  = "|calling line identification presentation";
  public static final String BIT_5  = "|calling line identification restriction";
  public static final String BIT_6  = "|call hold";
  public static final String BIT_7  = "|call wait";
  public static final String BIT_8  = "|multiparty";
  public static final String BIT_9  = "|intelligent network";
  public static final String BIT_10 = "|call transfer";
  public static final String BIT_11 = "|call transfer recall";
  public static final String BIT_12 = "|call drop back";
  public static final String BIT_13 = "|forwarding";
  public static final String BIT_14 = "|call-forwarding overdrive";
  public static final String BIT_15 = "|internal user interaction with INAP/CAMEL CTR operation";
  public static final String BIT_16 = "|external user interaction with INAP/CAMEL ETC operation";
  public static final String BIT_17 = "|completion of calls to busy subscribers";
  public static final String BIT_18 = "|camel";
  public static final String BIT_19 = "|ported in";
  public static final String BIT_20 = "|connected line identification presentation";
  public static final String BIT_21 = "|connected line identification restriction";
  public static final String BIT_22 = "|uus1 - origination/release of call";
  public static final String BIT_23 = "|uus2 - ringing phase";
  public static final String BIT_24 = "|uus3 - during connection";
  public static final String BIT_25 = "|aoc - during the call";
  public static final String BIT_26 = "|multicall";
  public static final String BIT_27 = "|eMLPP";
  public static final String BIT_28 = "|TTY";
  public static final String BIT_29 = "|SINAP";
  public static final String BIT_30 = "|CNAP";
  public static final String BIT_31 = "|HSCSD";
  public static final String BIT_32 = "|T-ADS";
  private FacilityConstant() {
    
  }
}
