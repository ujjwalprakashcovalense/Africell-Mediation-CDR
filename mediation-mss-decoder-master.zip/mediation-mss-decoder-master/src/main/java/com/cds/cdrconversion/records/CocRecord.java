/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the COC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class CocRecord {

  /**
   * Method to convert the COC record to decoded value string.
   * 
   * @param parseData  - COC record from 3rd byte to 159 byte, total 159-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseCOC(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields cocFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = cocFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(cocFields.getIntermediateRecordNumber());

    // IntermediateChrgeCause  
    offset = cocFields.setIntermediateChrgeCause(parseData, offset);  
    resultList.add(cocFields.getIntermediateChrgeCause());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // InChannelAllocatedTime
    offset = cocFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(cocFields.getInChannelAllocatedTime());

    // ChargingStartTime
    offset = cocFields.setChargingStartTime(parseData, offset);
    resultList.add(cocFields.getChargingStartTime());

    // ChargingEndTime
    offset = cocFields.setChargingEndTime(parseData, offset);
    resultList.add(cocFields.getChargingEndTime());

    // DurationBeforeAnswer
    offset = cocFields.setDurationBeforeAnswer(parseData, offset);
    resultList.add(cocFields.getDurationBeforeAnswer());

    // ChargeableDuration
    offset = cocFields.setChargeableDuration(parseData, offset);
    resultList.add(cocFields.getChargeableDuration());

    // LegCallReference 
    offset = cocFields.setLegCallReference(parseData, offset);  
    resultList.add(cocFields.getLegCallReference());

    // CamelCallReference 
    offset = cocFields.setCamelCallReference(parseData, offset);
    resultList.add(cocFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = cocFields.setCamelExchangeId(parseData, offset);
    resultList.add(cocFields.getCamelExchangeId());

    // basicCallStateModel
    resultList.add(parseData[offset++]);

    // scfAddressTon
    resultList.add(parseData[offset++]);

    // ScfAddress
    offset = cocFields.setScfAddress(parseData, offset);
    resultList.add(cocFields.getScfAddress());

    // CamelServiceKey 
    offset = cocFields.setCamelServiceKey(parseData, offset);
    resultList.add(cocFields.getCamelServiceKey());

    // DefaultCallHandling
    resultList.add(parseData[offset++]);

    // DestinationNumberTon
    resultList.add(parseData[offset++]);

    // DestinationNumber
    offset = cocFields.setDestinationNumber(parseData, offset);
    resultList.add(cocFields.getDestinationNumber());

    // LevelOfCamelService
    resultList.add(parseData[offset++]);

    // CamelModification
    offset = cocFields.setCamelModification(parseData, offset); 
    resultList.add(cocFields.getCamelModification());

    // CamelModifyParameters
    offset = cocFields.setCamelModifyParameters(parseData, offset);
    resultList.add(cocFields.getCamelModifyParameters());

    // NumberOfInRecords
    offset = cocFields.setNumberOfInRecords(parseData, offset);
    resultList.add(cocFields.getNumberOfInRecords());

    // CallReferenceTime
    offset = cocFields.setCallReferenceTime(parseData, offset);
    resultList.add(cocFields.getCallReferenceTime());

    // LegId
    resultList.add(parseData[offset++]);

    // GlobalCallReference
    offset = cocFields.setGlobalCallReference(parseData, offset);
    resultList.add(cocFields.getGlobalCallReference());

    // DialogueType
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseCOC

} // End of class
