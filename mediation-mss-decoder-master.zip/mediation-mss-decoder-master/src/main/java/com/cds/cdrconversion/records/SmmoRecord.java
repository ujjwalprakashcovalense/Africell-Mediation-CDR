/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the SMMO record decoding.
 * 
 * @author robin.varghese
 *
 */
public class SmmoRecord {

  /**
   * Method to convert the SMMO record to decoded value string.
   * 
   * @param parseData  - SMMO record from 3rd byte to 169 byte, total 169-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseSMMO(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    // SMMO field names
    final String callingNumber;

    CommonFields smmoFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // callingImsi
    offset = smmoFields.setCallingImsi(parseData, offset);
    resultList.add(smmoFields.getCallingImsi());

    // callingImei
    offset = smmoFields.setCallingImei(parseData, offset);
    resultList.add(smmoFields.getCallingImei());

    // callingNumber, Read 10bytes ,NUMBER
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    callingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(callingNumber);
    offset += tempStr.length;

    // callingCategory
    resultList.add(parseData[offset++]);

    // callingMsClassmark
    resultList.add(parseData[offset++]);

    // SmsCentre
    offset = smmoFields.setSmsCentre(parseData, offset);
    resultList.add(smmoFields.getSmsCentre());

    // ServedSubsLac
    offset = smmoFields.setServedSubsLac(parseData, offset);
    resultList.add(smmoFields.getServedSubsLac());

    // ServedSubsCi
    offset = smmoFields.setServedSubsCi(parseData, offset);
    resultList.add(smmoFields.getServedSubsCi());

    // IncomingTime
    offset = smmoFields.setIncomingTime(parseData, offset);
    resultList.add(smmoFields.getIncomingTime());

    // CauseForTermination
    offset = smmoFields.setCauseForTermination(parseData, offset);
    resultList.add(smmoFields.getCauseForTermination());

    // mscType
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = smmoFields.setCalledNumber(parseData, offset);
    resultList.add(smmoFields.getCalledNumber());
    
    // callingNumberTon
    resultList.add(parseData[offset++]);

    // calledNumberTon
    resultList.add(parseData[offset++]);

    // CallingVmscNumber
    offset = smmoFields.setCallingVmscNumber(parseData, offset);
    resultList.add(smmoFields.getCallingVmscNumber());

    // smsType
    resultList.add(parseData[offset++]);

    // DialledDigits
    offset = smmoFields.setDialledDigits(parseData, offset);
    resultList.add(smmoFields.getDialledDigits());

    // CallReferenceTime
    offset = smmoFields.setCallReferenceTime(parseData, offset);
    resultList.add(smmoFields.getCallReferenceTime());

    // routingCategory
    resultList.add(parseData[offset++]);

    // ConcatenatedSmsReference
    offset = smmoFields.setConcatenatedSmsReference(parseData, offset);
    resultList.add(smmoFields.getConcatenatedSmsReference());

    // numOfConcatenatedSms
    resultList.add(parseData[offset++]);

    // concatenatedRecordNumber
    resultList.add(parseData[offset++]);

    // applicationInfo
    resultList.add(parseData[offset++]);

    // AddRoutingCategory
    offset = smmoFields.setAddRoutingCategory(parseData, offset);
    resultList.add(smmoFields.getAddRoutingCategory());

    // dialledDigitsTon
    resultList.add(parseData[offset++]);

    // ServedSubsMcc
    offset = smmoFields.setServedSubsMcc(parseData, offset);
    resultList.add(smmoFields.getServedSubsMcc());

    // radioNetworkType
    resultList.add(parseData[offset++]);

    // ServedSubsMnc
    offset = smmoFields.setServedSubsMnc(parseData, offset);
    resultList.add(smmoFields.getServedSubsMnc());

    // HotBillingRecordNumber
    offset = smmoFields.setHotBillingRecordNumber(parseData, offset);
    resultList.add(smmoFields.getHotBillingRecordNumber());

    // CalledImsi
    offset = smmoFields.setCalledImsi(parseData, offset);
    resultList.add(smmoFields.getCalledImsi());

    // CalledImeisv
    offset = smmoFields.setCalledImeisv(parseData, offset);
    resultList.add(smmoFields.getCalledImeisv());

    // ueTimeZone
    resultList.add(parseData[offset++]);

    // Pni
    offset = smmoFields.setPni(parseData, offset);
    resultList.add(smmoFields.getPni());

    // TariffClass
    offset = smmoFields.setTariffClass(parseData, offset);
    resultList.add(smmoFields.getTariffClass());

    // smsLength
    resultList.add(parseData[offset++]);

    // commandType
    resultList.add(parseData[offset++]);

    // messageReference
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseSMMO
} // End of class
