/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the PTC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class PtcRecord {

  /**
   * Method to convert the PTC record to decoded value string.
   * 
   * @param parseData  - PTC record from 3rd byte to 257 byte, total 257-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parsePTC(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields ptcFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = ptcFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(ptcFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = ptcFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(ptcFields.getNumberOfSsRecords());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = ptcFields.setCallingNumber(parseData, offset);
    resultList.add(ptcFields.getCallingNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = ptcFields.setCalledNumber(parseData, offset);
    resultList.add(ptcFields.getCalledNumber());

    // OutCircuitGroup
    offset = ptcFields.setOutCircuitGroup(parseData, offset);
    resultList.add(ptcFields.getOutCircuitGroup());

    // OutCircuit
    offset = ptcFields.setOutCircuit(parseData, offset);
    resultList.add(ptcFields.getOutCircuit());

    // ChargingStartTime
    offset = ptcFields.setDateTime(parseData, offset);
    resultList.add(ptcFields.getDateTime());

    // ChargingEndTime
    offset = ptcFields.setDateTime(parseData, offset);
    resultList.add(ptcFields.getDateTime());

    // CauseForTermination
    offset = ptcFields.setCauseForTermination(parseData, offset);
    resultList.add(ptcFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // TicketType
    resultList.add(parseData[offset++]);

    // OazChrgType
    resultList.add(parseData[offset++]);

    // OazDuration
    offset = ptcFields.setOazDuration(parseData, offset);
    resultList.add(ptcFields.getOazDuration());

    // OazTariffClass
    offset = ptcFields.setOazTariffClass(parseData, offset);
    resultList.add(ptcFields.getOazTariffClass());

    // OazPulses
    offset = ptcFields.setOazPulses(parseData, offset);
    resultList.add(ptcFields.getOazPulses());

    // CalledMsrnTon
    resultList.add(parseData[offset++]);

    // CalledMsrn
    offset = ptcFields.setCalledMsrn(parseData, offset);
    resultList.add(ptcFields.getCalledMsrn());

    // IntermediateChrgeCause
    offset = ptcFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(ptcFields.getIntermediateChrgeCause());

    // LegCallReference
    offset = ptcFields.setLegCallReference(parseData, offset);
    resultList.add(ptcFields.getLegCallReference());
    
   // outChannelAllocatedTime
    offset = ptcFields.setOutChannelAllocatedTime(parseData, offset);
    resultList.add(ptcFields.getOutChannelAllocatedTime());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    // callReferenceTime
    offset = ptcFields.setCallReferenceTime(parseData, offset);
    resultList.add(ptcFields.getCallReferenceTime());
    
    // OrigRemoteTrunkGroupId
    offset = ptcFields.setOrigRemoteTrunkGroupId(parseData, offset);
    resultList.add(ptcFields.getOrigRemoteTrunkGroupId());

    // LocRoutingNumber
    offset = ptcFields.setLocRoutingNumber(parseData, offset);
    resultList.add(ptcFields.getLocRoutingNumber());

    // NpdbQueryStatus
    resultList.add(parseData[offset++]);

    // LocRoutingNumberTon
    resultList.add(parseData[offset++]);

    // NumberOfAllInRecords
    offset = ptcFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(ptcFields.getNumberOfAllInRecords());

    // CugInterlock
    offset = ptcFields.setCugInterlock(parseData, offset);
    resultList.add(ptcFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // SelectedCodec
    resultList.add(parseData[offset++]);

    // OutBncConnectionType
    resultList.add(parseData[offset++]);

    // OutsideUserPlaneIndex
    offset = ptcFields.setOutsideUserPlaneIndex(parseData, offset);
    resultList.add(ptcFields.getOutsideUserPlaneIndex());

    // OutsideControlPlaneIndex
    offset = ptcFields.setOutsideControlPlaneIndex(parseData, offset);
    resultList.add(ptcFields.getOutsideControlPlaneIndex());

    // GlobalCallReference
    offset = ptcFields.setGlobalCallReference(parseData, offset);
    resultList.add(ptcFields.getGlobalCallReference());

    // RedirectedIndicator
    resultList.add(parseData[offset++]);

    // ScpConnection
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = ptcFields.setNumberOfInRecords(parseData, offset);
    resultList.add(ptcFields.getNumberOfInRecords());

    // TermMczChangeDirection
    resultList.add(parseData[offset++]);

    // TermMczChangePercent
    resultList.add(parseData[offset++]);

    // OazChangePercent
    resultList.add(parseData[offset++]);
    
    // OazChangeDirection
    resultList.add(parseData[offset++]);
    
    // InCircuitGroupName
    offset = ptcFields.setInCircuitGroupName(parseData, offset);
    resultList.add(ptcFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = ptcFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(ptcFields.getOutCircuitGroupName());

    // OrigMczDuration
    offset = ptcFields.setOrigMczDuration(parseData, offset);
    resultList.add(ptcFields.getOrigMczDuration());

    // OrigMczDurationTenMs
    offset = ptcFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(ptcFields.getOrigMczDurationTenMs());

    // InCircuitGroup
    offset = ptcFields.setInCircuitGroup(parseData, offset);
    resultList.add(ptcFields.getInCircuitGroup());

    // InCircuit
    offset = ptcFields.setInCircuit(parseData, offset);
    resultList.add(ptcFields.getInCircuit());

    // IcidOverflow
    resultList.add(parseData[offset++]);

    // IcidLength
    resultList.add(parseData[offset++]);

    // Icid
    offset = ptcFields.setIcid(parseData, offset);
    resultList.add(ptcFields.getIcid());

    return resultList;
  } // End of parsePTC

} // End of class
