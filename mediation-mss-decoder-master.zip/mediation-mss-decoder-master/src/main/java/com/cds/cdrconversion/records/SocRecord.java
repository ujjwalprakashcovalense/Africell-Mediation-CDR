package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

public class SocRecord {

	/**
	 * Method to convert the SOC record to decoded value string.
	 * 
	 * @param parseData  - SOC record from 3rd byte to 288 byte, total 288-3 byte
	 *                   values.
	 * @param resultList - appended all field names.
	 */
	public static List<String> parseSOC(String[] parseData, List<String> resultList) {

		int offset = 0;
		String[] tempStr;
		final CommonFields socFields = new CommonFields();
		final String intermediateChrgCause;
		final String answerTime;
		final String icidOverflow;
		final String inInterOperatorId;
		final String inSbcDomainName;
		final String directoryNumber;
		final String redirectingNumber;
		final String sessionTransferIcidOverflow;

		// decode header data
		resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
		offset += 22; // after header position

		// intermediateRecordNumber
		offset = socFields.setIntermediateRecordNumber(parseData, offset);
		resultList.add(socFields.getIntermediateRecordNumber());

		// IntermediateChrgingInd
		resultList.add(parseData[offset++]);

		// IntermediateChrgCause
		offset = socFields.setIntermediateChrgeCause(parseData, offset);
		resultList.add(socFields.getIntermediateChrgeCause());

		// NumberOfSsRecords
		offset = socFields.setNumberOfSsRecords(parseData, offset);
		resultList.add(socFields.getNumberOfSsRecords());

		// NumberOfInRecords
		offset = socFields.setNumberOfInRecords(parseData, offset);
		resultList.add(socFields.getNumberOfInRecords());

		// CallingNumberTon
		resultList.add(parseData[offset++]);

		// callingImsi
		offset = socFields.setCallingImsi(parseData, offset);
		resultList.add(socFields.getCallingImsi());

		// calling_number
		offset = socFields.setCallingNumber(parseData, offset);
		resultList.add(socFields.getCallingNumber());

		// CalledNumberTon
		resultList.add(parseData[offset++]);

		// CalledNumber
		offset = socFields.setCalledNumber(parseData, offset);
		resultList.add(socFields.getCalledNumber());

		// CallingCategory
		resultList.add(parseData[offset++]);

		// CalledCategory
		resultList.add(parseData[offset++]);

		// InChannelAllocatedTime
		offset = socFields.setDateTime(parseData, offset);
		resultList.add(socFields.getDateTime());

		// FacilityUsage
		offset = socFields.setFacilityUsage(parseData, offset);
		resultList.add(socFields.getFacilityUsage());

		// ChargingStartTime
		offset = socFields.setDateTime(parseData, offset);
		resultList.add(socFields.getDateTime());

		// ChargingEndTime
		offset = socFields.setDateTime(parseData, offset);
		resultList.add(socFields.getDateTime());

		// AnswerTime
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
		answerTime = CommonDecoderUtils.getDateTime(tempStr);
		resultList.add(answerTime);
		offset += tempStr.length;

		// CauseForTermination
		offset = socFields.setCauseForTermination(parseData, offset);
		resultList.add(socFields.getCauseForTermination());

		// CallType
		resultList.add(parseData[offset++]);

		// OrigMczDuration
		offset = socFields.setOrigMczDuration(parseData, offset);
		resultList.add(socFields.getOrigMczDuration());

		// OrigMczModifyPercent
		offset = socFields.setOrigMczModifyPercent(parseData, offset);
		resultList.add(socFields.getOrigMczModifyPercent());

		// OrigMczModifyDirection
		resultList.add(parseData[offset++]);

		// LegCallReference
		offset = socFields.setLegCallReference(parseData, offset);
		resultList.add(socFields.getLegCallReference());

		// CallReferenceTime
		offset = socFields.setCallReferenceTime(parseData, offset);
		resultList.add(socFields.getCallReferenceTime());

		// IcidLength
		resultList.add(parseData[offset++]);

		// IcidOverflow
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
		icidOverflow = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
		resultList.add(icidOverflow);
		offset += tempStr.length;

		// Icid
		offset = socFields.setIcid(parseData, offset);
		resultList.add(socFields.getIcid());

		// CallMedia
		resultList.add(parseData[offset++]);

		// SipSigMode
		resultList.add(parseData[offset++]);

		// DialledDigitsTon
		resultList.add(parseData[offset++]);

		// DialledDigits
		offset = socFields.setDialledDigits(parseData, offset);
		resultList.add(socFields.getDialledDigits());

		// SelectedCodec
		resultList.add(parseData[offset++]);

		// Pni
		offset = socFields.setPni(parseData, offset);
		resultList.add(socFields.getPni());

		// InBncConnectionType
		resultList.add(parseData[offset++]);

		// InsideUserPlaneIndex
		offset = socFields.setInsideUserPlaneIndex(parseData, offset);
		resultList.add(socFields.getInsideUserPlaneIndex());

		// InsideControlPlaneIndex
		offset = socFields.setInsideControlPlaneIndex(parseData, offset);
		resultList.add(socFields.getInsideControlPlaneIndex());

		// GlobalCallReference
		offset = socFields.setGlobalCallReference(parseData, offset);
		resultList.add(socFields.getGlobalCallReference());

		// CallingModifyingParameteres
		offset = socFields.setCallingModifyParameters(parseData, offset);
		resultList.add(socFields.getCalledModifyParameters());

		// RedirectingNumberTon
		resultList.add(parseData[offset++]);

		// RedirectingNumber
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
		redirectingNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
		resultList.add(redirectingNumber);
		offset += tempStr.length;

		// InCircuitGroup
		offset = socFields.setInCircuitGroup(parseData, offset);
		resultList.add(socFields.getInCircuitGroup());

		// OutCircuitGroupName
		offset = socFields.setOutCircuitGroupName(parseData, offset);
		resultList.add(socFields.getOutCircuitGroupName());

		// InCircuitGroupName
		offset = socFields.setInCircuitGroupName(parseData, offset);
		resultList.add(socFields.getInCircuitGroupName());

		// OutCircuitGroup
		offset = socFields.setOutCircuitGroup(parseData, offset);
		resultList.add(socFields.getOutCircuitGroup());

		// SessionTransferIcidOverflow
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 1);
		sessionTransferIcidOverflow = CommonDecoderUtils.getHexStringList(tempStr);
		resultList.add(sessionTransferIcidOverflow);
		offset += tempStr.length;

		// RoutingCategory
		resultList.add(parseData[offset++]);

		// AddRoutingCategory
		offset = socFields.setAddRoutingCategory(parseData, offset);
		resultList.add(socFields.getAddRoutingCategory());

		// CamelCallReference
		offset = socFields.setCamelCallReference(parseData, offset);
		resultList.add(socFields.getCamelCallReference());

		// CamelExchangeIdTon
		resultList.add(parseData[offset++]);

		// CamelExchangeId
		offset = socFields.setCamelExchangeId(parseData, offset);
		resultList.add(socFields.getCamelExchangeId());

		// ScpConnection
		resultList.add(parseData[offset++]);

		// OrigMczChangeDirection
		resultList.add(parseData[offset++]);

		// OrigMczChangePercent
		resultList.add(parseData[offset++]);

		// NumberOfAllInRecords
		offset = socFields.setNumberOfAllInRecords(parseData, offset);
		resultList.add(socFields.getNumberOfAllInRecords());

		// OrigMczDurationTenMs
		offset = socFields.setOrigMczDurationTenMs(parseData, offset);
		resultList.add(socFields.getOrigMczDurationTenMs());

		// OrigMczChrgType
		resultList.add(parseData[offset++]);

		// OrigRemoteTrunkGroupId
		offset = socFields.setOrigRemoteTrunkGroupId(parseData, offset);
		resultList.add(socFields.getOrigRemoteTrunkGroupId());

		// DirectoryNumber
		offset = socFields.setDirectoryNumber(parseData, offset);
		resultList.add(socFields.getDirectoryNumber());

		// InInterOperatorId
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 64);
		inInterOperatorId = CommonDecoderUtils.getHexByteSwap(tempStr);
		resultList.add(inInterOperatorId);
		offset += tempStr.length;

		// InSbcDomainName
		tempStr = CommonDecoderUtils.readBytes(parseData, offset, 64);
		inSbcDomainName = CommonDecoderUtils.getHexByteSwap(tempStr);
		resultList.add(inSbcDomainName);
		offset += tempStr.length;

		return resultList;

	}
}
