/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the CTC record decoding.
 * 
 * @author robin.varghese
 *
 */
public class CtcRecord {

  /**
   * Method to convert the CTC record to decoded value string.
   * 
   * @param parseData  - CTC record from 3rd byte to 159 byte, total 159-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseCTC(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields ctcFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = ctcFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(ctcFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // IntermediateChrgeCause
    offset = ctcFields.setIntermediateChrgeCause(parseData, offset); 
    resultList.add(ctcFields.getIntermediateChrgeCause());

    // InChannelAllocatedTime
    offset = ctcFields.setInChannelAllocatedTime(parseData, offset);
    resultList.add(ctcFields.getInChannelAllocatedTime());

    // ChargingStartTime
    offset = ctcFields.setChargingStartTime(parseData, offset);
    resultList.add(ctcFields.getChargingStartTime());

    // ChargingEndTime
    offset = ctcFields.setChargingEndTime(parseData, offset);
    resultList.add(ctcFields.getChargingEndTime());

    // DurationBeforeAnswer
    offset = ctcFields.setDurationBeforeAnswer(parseData, offset);
    resultList.add(ctcFields.getDurationBeforeAnswer());

    // ChargeableDuration
    offset = ctcFields.setChargeableDuration(parseData, offset);
    resultList.add(ctcFields.getChargeableDuration());

    // LegCallReference
    offset = ctcFields.setLegCallReference(parseData, offset);
    resultList.add(ctcFields.getLegCallReference());

    // CamelCallReference
    offset = ctcFields.setCamelCallReference(parseData, offset);
    resultList.add(ctcFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = ctcFields.setCamelExchangeId(parseData, offset);
    resultList.add(ctcFields.getCamelExchangeId());

    // basicCallStateModel
    resultList.add(parseData[offset++]);

    // scfAddressTon
    resultList.add(parseData[offset++]);

    // ScfAddress
    offset = ctcFields.setScfAddress(parseData, offset);
    resultList.add(ctcFields.getScfAddress());

    // CamelServiceKey
    offset = ctcFields.setCamelServiceKey(parseData, offset);
    resultList.add(ctcFields.getCamelServiceKey());

    // DefaultCallHandling
    resultList.add(parseData[offset++]);

    // DestinationNumberTon
    resultList.add(parseData[offset++]);

    // DestinationNumber
    offset = ctcFields.setDestinationNumber(parseData, offset);
    resultList.add(ctcFields.getDestinationNumber());

    // LevelOfCamelService
    resultList.add(parseData[offset++]);

    // CamelModification
    offset = ctcFields.setCamelModification(parseData, offset); 
    resultList.add(ctcFields.getCamelModification());

    // CamelModifyParameters
    offset = ctcFields.setCamelModifyParameters(parseData, offset);
    resultList.add(ctcFields.getCamelModifyParameters());

    // NumberOfInRecords
    offset = ctcFields.setNumberOfInRecords(parseData, offset);
    resultList.add(ctcFields.getNumberOfInRecords());

    // CallReferenceTime
    offset = ctcFields.setCallReferenceTime(parseData, offset);
    resultList.add(ctcFields.getCallReferenceTime());

    // LegId
    resultList.add(parseData[offset++]);

    // GlobalCallReference
    offset = ctcFields.setGlobalCallReference(parseData, offset);
    resultList.add(ctcFields.getGlobalCallReference());

    // DialogueType
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parseCTC

} // End of class
