/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;

/**
 * The class will process the BlockTrailer record decoding.
 * 
 * @author robin.varghese
 *
 */
public class BlockTrailerRecord {

  /**
   * Method to convert the parseBlockTrailer record to decoded value string.
   * 
   * @param parseData  - parseBlockTrailer record from 3rd byte to 20 byte, total
   *                   20-3 byte values.
   * @param resultList - appended all field names.
   */
  public static List<String> parseBlockTrailer(String[] parseData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    // BlockTrailer field names
    final String exchangeId;
    final String endTime;
    final String lastRecordNumber;

    // Read 10bytes , 1byte nibble swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    exchangeId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(exchangeId);
    offset += tempStr.length;

    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    endTime = CommonDecoderUtils.getDateTime(tempStr);
    resultList.add(endTime);
    offset += tempStr.length;

    // Read 4bytes ,1 BCD dword -> 1byte swapping logic
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    lastRecordNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(lastRecordNumber);
    offset += tempStr.length;

    return resultList;
  } // End of parseBlockTrailer
} // End of class
