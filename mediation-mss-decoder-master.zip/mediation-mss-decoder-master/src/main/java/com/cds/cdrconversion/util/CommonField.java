package com.cds.cdrconversion.util;

import lombok.Getter;

/**
 * This class will create common fields decoding for all record types.
 * 
 * @author robin.varghese
 *
 */
@Getter
public class CommonField {

  String[] tempStr;
  private String durationBeforeAnswer;
  private String chargeableDuration;
  private String camelServiceKey;
  private String destinationNumber;
  private String camelModification;
  private String scfAddress;
  private String camelModifyParameters;
  private String smsCentre;
  private String servedSubsLac;
  private String servedSubsCi;
  private String incomingTime;
  private String callingVmscNumber;
  private String concatenatedSmsReference;
  private String servedSubsMcc;
  private String servedSubsMnc;
  private String tariffClass;
  private String servedImsi;
  private String servedImei;
  private String servedImeisv;
  private String servedNumber;
  private String directoryNumber;
  private String dateTime;
  private String forwardedToNumber;
  private String reference;
  private String iazDuration;
  private String iazTariffClass;
  private String iazPulses;
  private String origRemoteTrunkGroupId;
  private String icidOverflow;
  private String icidLength;
  private String icid;
  private String oazDuration;
  private String oazTariffClass;
  private String oazPulses;

  /**
   * method will decode the DurationBeforeAnswer value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setDurationBeforeAnswer(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.durationBeforeAnswer = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of DurationBeforeAnswer

  /**
   * method will decode the ChargeableDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setChargeableDuration(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.chargeableDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of ChargeableDuration

  /**
   * method will decode the scfAddress value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setScfAddress(String[] parseData, int offset) {
    // Read 9bytes , 9bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 9);
    this.scfAddress = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of ScfAddress

  /**
   * method will decode the camelServiceKey value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCamelServiceKey(String[] parseData, int offset) {
    // Read 4bytes , 1hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.camelServiceKey = CommonDecoderUtils.getHexByteRightToLeft(tempStr);
    return offset += tempStr.length;
  } // End of camelServiceKey

  /**
   * method will decode the DestinationNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setDestinationNumber(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.destinationNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of DestinationNumber

  /**
   * method will decode the CamelModification value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCamelModification(String[] parseData, int offset) {
    // Read 4bytes , 1hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.camelModification = CommonDecoderUtils.getCamelModification(tempStr);
    return offset += tempStr.length;
  } // End of CamelModification

  /**
   * method will decode the CamelModifyParameters value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCamelModifyParameters(String[] parseData, int offset) {
    // Read 14bytes , 7hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 14);
    this.camelModifyParameters = CommonDecoderUtils.getHexStringList(tempStr);
    return offset += tempStr.length;
  } // CamelModifyParameters

  /**
   * method will decode the SmsCentre value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setSmsCentre(String[] parseData, int offset) {
    // Read 10bytes , 10byteBCD
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    this.smsCentre = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // SmsCentre

  /**
   * method will decode the ServedSubsLac value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedSubsLac(String[] parseData, int offset) {
    // Read 2bytes , hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.servedSubsLac = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // ServedSubsLac

  /**
   * method will decode the ServedSubsCi value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedSubsCi(String[] parseData, int offset) {
    // Read 4bytes , 1hexdword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    this.servedSubsCi = CommonDecoderUtils.getHexByteRightToLeft(tempStr); // todo confirm
    return offset += tempStr.length;
  } // ServedSubsci

  /**
   * method will decode the IncomingTime value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIncomingTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.incomingTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // IncomingTime

  /**
   * method will decode the CallingVmscNumber as well as CalledVmscNumber value
   * and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setCallingVmscNumber(String[] parseData, int offset) {
    // Read 10bytes , 10byteBCD
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 10);
    this.callingVmscNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // CallingVmscNumber

  /**
   * method will decode the ConcatenatedSmsReference value and set value to the
   * field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setConcatenatedSmsReference(String[] parseData, int offset) {
    // Read 2bytes , hexword
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.concatenatedSmsReference = CommonDecoderUtils.getHexByteSwap(tempStr);
    return offset += tempStr.length;
  } // ConcatenatedSmsReference

  /**
   * method will decode the ServedSubsMcc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedSubsMcc(String[] parseData, int offset) {
    // Read 2 Hexbytes for - 2Hex byte bcd nibble swapping
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.servedSubsMcc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // ServedSubsMcc

  /**
   * method will decode the ServedSubsMnc value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedSubsMnc(String[] parseData, int offset) {
    // Read 2 Hexbytes for - 2Hex byte bcd nibble swapping
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.servedSubsMnc = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // ServedSubsMcc

  /**
   * method will decode the TariffClass value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setTariffClass(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.tariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // TariffClass

  /**
   * method will decode the servedImsi value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedImsi(String[] parseData, int offset) {
    // Read 8bytes , 8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.servedImsi = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // setServedImsi

  /**
   * method will decode the servedImei value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedImei(String[] parseData, int offset) {
    // Read 8bytes , 8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.servedImei = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // servedImei

  /**
   * method will decode the servedImeisv value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedImeisv(String[] parseData, int offset) {
    // Read 8bytes , 8bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 8);
    this.servedImeisv = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // servedImeisv

  /**
   * method will decode the servedNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setServedNumber(String[] parseData, int offset) {
    // Read 12bytes , 12hex bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.servedNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // servedNumber

  /**
   * method will decode the directoryNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setDirectoryNumber(String[] parseData, int offset) {
    // Read 7bytes , 7 BCD bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.directoryNumber = CommonDecoderUtils.getBcdBytes(tempStr);
    return offset += tempStr.length;
  } // directoryNumber

  /**
   * method will decode the All the fields which read 7bytes, 5 BCD bytes + 1 BCD
   * word and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setDateTime(String[] parseData, int offset) {
    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 7);
    this.dateTime = CommonDecoderUtils.getDateTime(tempStr);
    return offset += tempStr.length;
  } // DateTime
  
  /**
   * method will decode the forwardedToNumber value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setForwardedToNumber(String[] parseData, int offset) {
    // Read 12bytes ,12 HEX bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 12);
    this.forwardedToNumber = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    return offset += tempStr.length;
  } // End of forwardedToNumber

   /**
   * method will decode the Reference value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setReference(String[] parseData, int offset) {
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 4);
    offset += tempStr.length;
    String[] tempValue = CommonDecoderUtils.readBytes(parseData, offset, 1);
    this.reference = CommonDecoderUtils.getHexByteSwap(tempStr) + tempValue[0];
    return offset += tempValue.length;
  } // ServedSubsLac

  /**
   * method will decode the IazDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIazDuration(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.iazDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of IazDuration

  /**
   * method will decode the IazTariffClass value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIazTariffClass(String[] parseData, int offset) {
    // Read 3bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.iazTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of IazTariffClass

  /**
   * method will decode the IazPulses value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIazPulses(String[] parseData, int offset) {
    // Read 2bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.iazPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of iazPulses

  /**
   * method will decode the OrigRemoteTrunkGroupId and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOrigRemoteTrunkGroupId(String[] parseData, int offset) {
    // Read 32bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 32);
    this.origRemoteTrunkGroupId = CommonDecoderUtils.hexToAscii(tempStr);
    return offset += tempStr.length;
  } // End of OrigRemoteTrunkGroupId

  /**
   * method will decode the Icid and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setIcid(String[] parseData, int offset) {
    // Read 32bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 32);
    this.icid = CommonDecoderUtils.getHexStringList(tempStr);
    return offset += tempStr.length;
  } // End of Icid

  /**
   * method will decode the OazDuration value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOazDuration(String[] parseData, int offset) {
    // Read 3bytes , 3bcd bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.oazDuration = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OazDuration

  /**
   * method will decode the OazTariffClass value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOazTariffClass(String[] parseData, int offset) {
    // Read 3bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 3);
    this.oazTariffClass = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OazTariffClass

  /**
   * method will decode the OazPulses value and set value to the field.
   * 
   * @param parseData - string array of bytes to read.
   * @param offset    - starting position to read the bytes.
   * 
   * @return - updated offset value.
   */
  public int setOazPulses(String[] parseData, int offset) {
    // Read 2bytes
    tempStr = CommonDecoderUtils.readBytes(parseData, offset, 2);
    this.oazPulses = CommonDecoderUtils.getBcdByteSwap(tempStr);
    return offset += tempStr.length;
  } // End of OazPulses
  
} // End of Class
