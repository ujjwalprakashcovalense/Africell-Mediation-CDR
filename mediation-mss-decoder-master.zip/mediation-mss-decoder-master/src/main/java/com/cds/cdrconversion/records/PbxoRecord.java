/*
 * Copyright (C) 2019 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.CommonFields;

/**
 * The class will process the PBXO record decoding.
 * 
 * @author robin.varghese
 *
 */
public class PbxoRecord {

  /**
   * Method to convert the PBXO record to decoded value string.
   * 
   * @param parseData  - PBXO record from 3rd byte to 244 byte, total 244-3 byte
   *                   values.
   * @param resultList - appended all field names.
   */
  public static List<String> parsePBXO(String[] parseData, List<String> resultList) {

    int offset = 0;
    final CommonFields pbxoFields = new CommonFields();

    // decode header data
    resultList = CommonDecoderUtils.getHeaderData(parseData, offset, resultList);
    offset += 22; // after header position

    // intermediateRecordNumber
    offset = pbxoFields.setIntermediateRecordNumber(parseData, offset);
    resultList.add(pbxoFields.getIntermediateRecordNumber());

    // IntermediateChrgingInd
    resultList.add(parseData[offset++]);

    // NumberOfSsRecords
    offset = pbxoFields.setNumberOfSsRecords(parseData, offset);
    resultList.add(pbxoFields.getNumberOfSsRecords());

    // CallingNumberTon
    resultList.add(parseData[offset++]);

    // CallingNumber
    offset = pbxoFields.setCallingNumber(parseData, offset);
    resultList.add(pbxoFields.getCallingNumber());

    // CalledNumberTon
    resultList.add(parseData[offset++]);

    // CalledNumber
    offset = pbxoFields.setCalledNumber(parseData, offset);
    resultList.add(pbxoFields.getCalledNumber());

    // InCircuitGroup
    offset = pbxoFields.setInCircuitGroup(parseData, offset);
    resultList.add(pbxoFields.getInCircuitGroup());

    // InCircuit
    offset = pbxoFields.setInCircuit(parseData, offset);
    resultList.add(pbxoFields.getInCircuit());

    // InChannelAllocatedTime
    offset = pbxoFields.setDateTime(parseData, offset);
    resultList.add(pbxoFields.getDateTime());

    // ChargingStartTime
    offset = pbxoFields.setDateTime(parseData, offset);
    resultList.add(pbxoFields.getDateTime());

    // ChargingEndTime
    offset = pbxoFields.setDateTime(parseData, offset);
    resultList.add(pbxoFields.getDateTime());

    // CauseForTermination
    offset = pbxoFields.setCauseForTermination(parseData, offset);
    resultList.add(pbxoFields.getCauseForTermination());

    // CallType
    resultList.add(parseData[offset++]);

    // iaz_chrg_type
    resultList.add(parseData[offset++]);

    // IazDuration
    offset = pbxoFields.setIazDuration(parseData, offset);
    resultList.add(pbxoFields.getIazDuration());

    // IazTariffClass
    offset = pbxoFields.setIazTariffClass(parseData, offset);
    resultList.add(pbxoFields.getIazTariffClass());

    // IazPulses
    offset = pbxoFields.setIazPulses(parseData, offset);
    resultList.add(pbxoFields.getIazPulses());

    // CalledMsrnTon
    resultList.add(parseData[offset++]);

    // CalledMsrn
    offset = pbxoFields.setCalledMsrn(parseData, offset);
    resultList.add(pbxoFields.getCalledMsrn());

    // IntermediateChrgeCause
    offset = pbxoFields.setIntermediateChrgeCause(parseData, offset);
    resultList.add(pbxoFields.getIntermediateChrgeCause());

    // OrigDiallingClass
    offset = pbxoFields.setOrigDiallingClass(parseData, offset);
    resultList.add(pbxoFields.getOrigDiallingClass());

    // LegCallReference
    offset = pbxoFields.setLegCallReference(parseData, offset);
    resultList.add(pbxoFields.getLegCallReference());

    // CallReferenceTime
    offset = pbxoFields.setCallReferenceTime(parseData, offset);
    resultList.add(pbxoFields.getCallReferenceTime());

    // LocRoutingNumber
    offset = pbxoFields.setLocRoutingNumber(parseData, offset);
    resultList.add(pbxoFields.getLocRoutingNumber());

    // NpdbQueryStatus
    resultList.add(parseData[offset++]);

    // LocRoutingNumberTon
    resultList.add(parseData[offset++]);

    // NumberOfAllInRecords
    offset = pbxoFields.setNumberOfAllInRecords(parseData, offset);
    resultList.add(pbxoFields.getNumberOfAllInRecords());

    // CamelCallReference
    offset = pbxoFields.setCamelCallReference(parseData, offset);
    resultList.add(pbxoFields.getCamelCallReference());

    // CamelExchangeIdTon
    resultList.add(parseData[offset++]);

    // CamelExchangeId
    offset = pbxoFields.setCamelExchangeId(parseData, offset);
    resultList.add(pbxoFields.getCamelExchangeId());

    // Pni
    offset = pbxoFields.setPni(parseData, offset);
    resultList.add(pbxoFields.getPni());

    // GlobalCallReference
    offset = pbxoFields.setGlobalCallReference(parseData, offset);
    resultList.add(pbxoFields.getGlobalCallReference());

    // NbrOfOrigCapInRecs
    offset = pbxoFields.setNbrOfOrigCapInRecs(parseData, offset);
    resultList.add(pbxoFields.getNbrOfOrigCapInRecs());

    // NumberOfInAnnouncements
    offset = pbxoFields.setNumberOfInAnnouncements(parseData, offset);
    resultList.add(pbxoFields.getNumberOfInAnnouncements());

    // RedirectedIndicator
    resultList.add(parseData[offset++]);

    // CugInterlock
    offset = pbxoFields.setCugInterlock(parseData, offset);
    resultList.add(pbxoFields.getCugInterlock());

    // CugOutgoingAccess
    resultList.add(parseData[offset++]);

    // CugInformation
    resultList.add(parseData[offset++]);

    // ScpConnection
    resultList.add(parseData[offset++]);

    // NumberOfInRecords
    offset = pbxoFields.setNumberOfInRecords(parseData, offset);
    resultList.add(pbxoFields.getNumberOfInRecords());

    // OrigMczChangePercent
    resultList.add(parseData[offset++]);

    // OrigMczChangeDirection
    resultList.add(parseData[offset++]);

    // IazChangePercent
    resultList.add(parseData[offset++]);

    // IazChangeDirection
    resultList.add(parseData[offset++]);
    // InCircuitGroupName
    offset = pbxoFields.setInCircuitGroupName(parseData, offset);
    resultList.add(pbxoFields.getInCircuitGroupName());

    // OutCircuitGroupName
    offset = pbxoFields.setOutCircuitGroupName(parseData, offset);
    resultList.add(pbxoFields.getOutCircuitGroupName());

    // OrigMczDurationTenMs
    offset = pbxoFields.setOrigMczDurationTenMs(parseData, offset);
    resultList.add(pbxoFields.getOrigMczDurationTenMs());

    // OrigMczDuration
    offset = pbxoFields.setOrigMczDuration(parseData, offset);
    resultList.add(pbxoFields.getOrigMczDuration());

    // OrigMczChrgType
    resultList.add(parseData[offset++]);

    // DirectoryNumber
    offset = pbxoFields.setDirectoryNumber(parseData, offset);
    resultList.add(pbxoFields.getDirectoryNumber());

    // BasicServiceType
    resultList.add(parseData[offset++]);

    // BasicServiceCode
    resultList.add(parseData[offset++]);

    return resultList;
  } // End of parsePBXO

} // End of class
