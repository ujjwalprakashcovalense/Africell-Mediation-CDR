/*
 * Copyright (C) 2022 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion.records;

import java.util.List;

import com.cds.cdrconversion.util.CommonDecoderUtils;

/**
 * The class will process the block header data decoding.
 * 
 * @author robin.varghese
 *
 */
public class BlockHeader {

  /**
   * Method to convert the block header record fields to decoded value.
   * 
   * @param headerData - head record from 3rd byte to 41 byte.
   * @param resultList - decoded values as string.
   */
  public static List<String> parseHeader(String[] headerData, List<String> resultList) {

    String[] tempStr;
    int offset = 0;
    // block header field names
    final String chargingBlockSize;
    final String tapeblockType;
    final String dataLengthinBlock;
    final String exchangeId;
    final String firstRecordNumber;
    final String batchSeqNumber;
    final String blockSeqNumber;
    final String startTime;
    final String formatVersion;

    // Read 1hex byte
    chargingBlockSize = headerData[offset++];
    resultList.add(chargingBlockSize);

    // 2 Hexbytes for tapeblockType - bytes wapping
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 2);
    tapeblockType = CommonDecoderUtils.getHexByteSwap(tempStr);
    resultList.add(tapeblockType); offset+=tempStr.length;

    // Read 2bytes , final string is decimal converted
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 2);
    dataLengthinBlock = String.valueOf(CommonDecoderUtils.getHexByteSwap(tempStr));
    resultList.add(dataLengthinBlock); offset+=tempStr.length;

    // Read 10bytes , 1byte nibble swapping logic
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 10);
    exchangeId = CommonDecoderUtils.getBcdByteNibbleSwap(tempStr);
    resultList.add(exchangeId);offset+=tempStr.length;

    // Read 4bytes ,1 BCD dword -> 1byte swapping logic
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 4);
    firstRecordNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(firstRecordNumber); offset+=tempStr.length;

    // Read 4bytes ,1byte swapping logic
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 4);
    batchSeqNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(batchSeqNumber); offset+=tempStr.length;

    // Read 2bytes ,1byte swapping logic
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 2);
    blockSeqNumber = CommonDecoderUtils.getBcdByteSwap(tempStr);
    resultList.add(blockSeqNumber); offset+=tempStr.length;

    // Read 7bytes, 5 BCD bytes + 1 BCD word
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 7);
    startTime = CommonDecoderUtils.getDateTime(tempStr);
    resultList.add(startTime); offset+=tempStr.length;

    // formatVersion--> Read 2bytes for 1 hexword
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 2);
    String asciValue = CommonDecoderUtils.hexToAscii(tempStr);
    offset+=tempStr.length;
    
    // read 4 bcd bytes
    tempStr = CommonDecoderUtils.readBytes(headerData, offset, 4);
    CommonDecoderUtils.getBcdBytes(tempStr);
    formatVersion = asciValue + CommonDecoderUtils.getBcdBytes(tempStr);
    resultList.add(formatVersion); offset+=tempStr.length;

    return resultList;
  } // End of parseHeader
} // End of class
