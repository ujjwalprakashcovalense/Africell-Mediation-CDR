/*
 * Copyright (C) 2022 Covalensedigital 
 *
 * Licensed under the CBIT,Version 1.0,you may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at 
 * 
 * http://www.covalensedigital.com/
 *
 * Unless required by applicable law or agreed to in writing, software biftributed under the License
 * is biftributed on an "AS IS" BASIS,WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,either express or
 * implied.See the License for the specific language governing permissions and limitations under.
*/

package com.cds.cdrconversion;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cds.cdrconversion.records.BlockHeader;
import com.cds.cdrconversion.records.BlockTrailerRecord;
import com.cds.cdrconversion.records.CocRecord;
import com.cds.cdrconversion.records.CtcRecord;
import com.cds.cdrconversion.records.DocRecord;
import com.cds.cdrconversion.records.ForwRecord;
import com.cds.cdrconversion.records.HwRecord;
import com.cds.cdrconversion.records.IN4Record;
import com.cds.cdrconversion.records.INRecord;
import com.cds.cdrconversion.records.LocaRecord;
import com.cds.cdrconversion.records.MocRecord;
import com.cds.cdrconversion.records.MtcRecord;
import com.cds.cdrconversion.records.PbxoRecord;
import com.cds.cdrconversion.records.PbxtRecord;
import com.cds.cdrconversion.records.PocRecord;
import com.cds.cdrconversion.records.PtcRecord;
import com.cds.cdrconversion.records.RccRecord;
import com.cds.cdrconversion.records.RoamRecord;
import com.cds.cdrconversion.records.STCRecord;
import com.cds.cdrconversion.records.SmmfRecord;
import com.cds.cdrconversion.records.SmmoRecord;
import com.cds.cdrconversion.records.SmmtRecord;
import com.cds.cdrconversion.records.SocRecord;
import com.cds.cdrconversion.records.SuspRecord;
import com.cds.cdrconversion.util.BinaryFileReader;
import com.cds.cdrconversion.util.CommonDecoderUtils;
import com.cds.cdrconversion.util.ResponseBuilder;

public class ConversionService {

	private BinaryFileReader reader = new BinaryFileReader();
	private ResponseBuilder builder = new ResponseBuilder();
	private final static Logger logger = LoggerFactory.getLogger(ConversionProcessor.class.getName());

	/**
	 * Method to process binary file to respective decoding format and convert to
	 * decimal values and store to csv file.
	 * 
	 * @param bif
	 * @param subDir
	 * @param string
	 * 
	 * @return - success message.
	 * @throws IOException - ioexception
	 */
	public boolean parseCDR(BufferedInputStream bif, String fileName, String subDir) {

		final int headerLength;
		String[] head;
		String recordType = null;
		boolean fileEnd = false;
		boolean multiBlock = false;
		int position = 0;
		int i = 1;
		int initialRead = 3;
		boolean cdrFailed = false;
		String[] bytesArray = null;
		int recordLength = 0;
		List<String> resultList = new ArrayList<>();
		LinkedHashMap<String, List<String>> finalListMap = new LinkedHashMap<>();

		try {

			logger.info("File processing  started");

//      // reads initail recordLength and recordType
//      head = reader.bytesReader(3, bif);
//
//      position += 3;
//      // fetch Header Block- recordLength
//      headerLength = CommonDecoderUtils.getHexWordDecimal(head);
//
//      // find recordType from header block
//      recordType = CommonDecoderUtils.getBcdByte(head[2]);
//
//      if (!recordType.equals("00")) {
//       logger.error("File does not have Block header");
//        return cdrFailed = true;
//      }
//      // read header block 3rd byte to 41
//      String[] headerData = reader.bytesReader(headerLength - position, bif);
//      position = headerLength;
//      resultList.add(recordType);
//
//      // parse the header block data
//      List<String> headerBlockResult1 = BlockHeader.parseHeader(headerData, resultList);
//     // finalListMap.put("HeaderBlock", headerBlockResult);
//      logger.info("HeaderBlock record : " + headerBlockResult1);
//
//      /** -----------------End of header block process-------------- **/

			// process all record upto file end
			while (!fileEnd) {

				// read all byte for specific record length
				if (!multiBlock) {
					head = reader.bytesReader(initialRead, bif);
					// fetch recordLength
					recordLength = CommonDecoderUtils.getHexWordDecimal(head);
					// find recordType
					recordType = head[2];
				}
				int readLength = recordLength - initialRead;
				if (readLength > 0)
					bytesArray = reader.bytesReader(recordLength - initialRead, bif);

				switch (recordType) {

				case "00": { // header record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the header block data
					if (bytesArray.length != 38) {
						fileEnd = true;
						logger.info(recordType);
						cdrFailed = true;
						logger.info("Header length is greater than the required length.");
						break;
					}
					List<String> headerBlockResult = BlockHeader.parseHeader(bytesArray, resultList1);
					// finalListMap.put("HeaderBlock-"+ headerBlockResult.get(7),
					// headerBlockResult);
					// logger.info("HeaderBlock record-"+i + ":"+ headerBlockResult);
					multiBlock = false;
					i++; // totalblock
				}
					break;

				case "01": { // MOC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the MOC record
					List<String> mocResult = MocRecord.parseMOC(bytesArray, resultList1);
					finalListMap.put("MOC-" + mocResult.get(1), mocResult);
				}
					break;
				case "02": { // MTC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the MTC record
					List<String> mtcResult = MtcRecord.parseMTC(bytesArray, resultList1);
					finalListMap.put("MTC-" + mtcResult.get(1), mtcResult);
				}
					break;
				case "03": { // FORW record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the FORW record
					List<String> forwResult = ForwRecord.parseFORW(bytesArray, resultList1);
					finalListMap.put("FORW-" + forwResult.get(1), forwResult);

				}
					break;
				case "04": { // ROAM record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the ROAM record
					List<String> roamResult = RoamRecord.parseROAM(bytesArray, resultList1);
					finalListMap.put("ROAM-" + roamResult.get(1), roamResult);
				}
					break;
				case "05": { // SUSP record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the SUSP record
					List<String> suspResult = SuspRecord.parseSUSP(bytesArray, resultList1);
					finalListMap.put("SUSP-" + suspResult.get(1), suspResult);
				}
					break;
				case "06": { // HLR interrogation record //TODO

					// parse the HLR record
					finalListMap.put("nondecoded HLR-", Arrays.asList(bytesArray));
				}
					break;
				case "07": { // LOCA record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the LOCA record
					List<String> loca = LocaRecord.parseLOCA(bytesArray, resultList1);
					finalListMap.put("LOCA-" + loca.get(1), loca);
				}
					break;
				case "08": { // SMMO record
								// read SMMO 3rd byte to 169
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the SMMO record
					List<String> smmoResult = SmmoRecord.parseSMMO(bytesArray, resultList1);
					finalListMap.put("SMMO-" + smmoResult.get(1), smmoResult);
				}
					break;
				case "09": { // SMMT record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the SMMT record
					List<String> smmtResult = SmmtRecord.parseSMMT(bytesArray, resultList1);
					finalListMap.put("SMMT-" + smmtResult.get(1), smmtResult);
				}
					break;
				case "10": { // BlockTrailer record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the BlockTrailer record
					List<String> trailerResult = BlockTrailerRecord.parseBlockTrailer(bytesArray, resultList1);
					// finalListMap.put("BlockTrailer-" + bytesArray[0], trailerResult);
					// logger.info("BlockTrailer record : " + trailerResult );

					// find for next header block
					if (bif.available() > 0) {
						for (int j = 0; j < bif.available(); j++) {
							// find header block
							String[] h = reader.bytesReader(1, bif);
							if (h[0].equals("29")) { // record length for header

								// logger.info("find next header block");
								// bif.reset();
								head = reader.bytesReader(initialRead - 1, bif);
								// fetch recordLength
								recordLength = CommonDecoderUtils.getDecimal(h[0]);
								// find recordType
								recordType = head[1];
								multiBlock = true;
								fileEnd = false;
								break;
							} else {
								fileEnd = true;
							}
						} // end of for loop
					} else {

						fileEnd = true;
						logger.info("fileEnd = true");
					} // end of else

				} // end of case block
					break;
				case "11": { // POC record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the POC record
					List<String> pocResult = PocRecord.parsePOC(bytesArray, resultList1);
					finalListMap.put("POC-" + pocResult.get(1), pocResult);
				}
					break;
				case "12": { // PTC record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the PTC record
					List<String> ptc = PtcRecord.parsePTC(bytesArray, resultList1);
					finalListMap.put("PTC-" + ptc.get(1), ptc);
				}
					break;
				case "13": { // PBXO record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the PBXO record
					List<String> pbxo = PbxoRecord.parsePBXO(bytesArray, resultList1);
					finalListMap.put("PBXO-" + pbxo.get(1), pbxo);
				}
					break;
				case "14": { // PBXT record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the PBXT record
					List<String> pbxt = PbxtRecord.parsePBXT(bytesArray, resultList1);
					finalListMap.put("PBXT-" + pbxt.get(1), pbxt);
				}
					break;
				case "15": { // HW record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the HW record
					List<String> hwResult = HwRecord.parseHW(bytesArray, resultList1);
					finalListMap.put("HW-" + hwResult.get(1), hwResult);
				}
					break;
				case "16": { // IN1 record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN1 record
					List<String> in = INRecord.parseIN(bytesArray, resultList1);
					finalListMap.put("IN1-" + in.get(1), in);

				}
					break;
				case "18": { // IN2 record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN2 record
					List<String> inResult = INRecord.parseIN(bytesArray, resultList1);
					finalListMap.put("IN2-" + inResult.get(1), inResult);
				}
					break;
				case "19": { // IN3 record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN3 record
					List<String> inResult = INRecord.parseIN(bytesArray, resultList1);
					finalListMap.put("IN3-" + inResult.get(1), inResult);
				}
					break;
				case "20": { // DOC record

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the DOC record
					List<String> inResult = DocRecord.parseDOC(bytesArray, resultList1);
					finalListMap.put("DOC-" + inResult.get(1), inResult);
				}
					break;
				case "22": { // RCC record //TODO UT is pending, dat not available

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the RCC record
					List<String> inResult = RccRecord.parseRCC(bytesArray, resultList1);
					finalListMap.put("RCC-" + inResult.get(1), inResult);
				}
					break;
				case "23": { // SMMF record //TODO UT is pending dat not available

					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the smmf record
					List<String> inResult = SmmfRecord.parseSMMF(bytesArray, resultList1);
					finalListMap.put("SMMF-" + inResult.get(1), inResult);
				}
					break;
				case "24": { // COC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the COC record
					List<String> cocresultList1 = CocRecord.parseCOC(bytesArray, resultList1);
					finalListMap.put("COC-" + cocresultList1.get(1), cocresultList1);
				}
					break;
				case "25": { // CTC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the CTC record
					List<String> ctcResult = CtcRecord.parseCTC(bytesArray, resultList1);
					finalListMap.put("CTC-" + ctcResult.get(1), ctcResult);
				}
					break;
				case "26": { // IN4 record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN4 record
					List<String> inResult = IN4Record.parseIN4(bytesArray, resultList1);
					finalListMap.put("IN4-" + inResult.get(1), inResult);

				}
					break;
				case "28": { // IN5 record //TODO

					// parse the IN5 record
					finalListMap.put("nondecoded IN5-", Arrays.asList(bytesArray));
				}
					break;
				case "30": { // SOC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN4 record
					List<String> socResult = SocRecord.parseSOC(bytesArray, resultList1);
					finalListMap.put("SOC-" + socResult.get(1), socResult);
				}
					break;
				case "31": { // STC record
					List<String> resultList1 = new ArrayList<String>();
					resultList1.add(recordType);
					// parse the IN4 record
					List<String> stcResult = STCRecord.parseSTC(bytesArray, resultList1);
					finalListMap.put("STC-" + stcResult.get(1), stcResult);
				}
					break;

				default:
					fileEnd = true;
				} // end of switch
			} // end of while

			logger.info("Total no of block = " + i);
			// writing output finalListMap to specified file
			builder.fileWriter(finalListMap, fileName, subDir);

		} catch (Exception e) {
			cdrFailed = true;
			e.printStackTrace();
			logger.error("Internal error while processing file" + e.getMessage());
			return cdrFailed;
		}

		logger.info("File processing ended");
		return cdrFailed;
	} // End of parseCDR

} // End of class
